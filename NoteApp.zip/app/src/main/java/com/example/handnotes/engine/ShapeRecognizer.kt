package com.example.handnotes.engine

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * "Draw and hold": turns a rough stroke into a clean line, triangle, rectangle, circle or ellipse.
 * Returns null when the stroke does not look like any of them.
 */
object ShapeRecognizer {
    private const val MIN_SIZE = 40f
    private const val CLOSED_GAP = 0.2f
    private const val LINE_TOLERANCE = 0.06f
    private const val RDP_EPSILON = 0.07f
    private const val STRAIGHT_ANGLE = 160f
    private const val AXIS_TOLERANCE_DEG = 12.0

    fun recognize(pts: List<Pt>): List<Pt>? {
        if (pts.size < 8) return null
        val b = Bounds.of(pts)
        val diag = b.diagonal
        if (diag < MIN_SIZE) return null
        val first = pts.first()
        val last = pts.last()
        val gap = hypot(last.x - first.x, last.y - first.y)
        return if (gap < diag * CLOSED_GAP) {
            recognizePolygon(pts, diag, b) ?: recognizeEllipse(pts, b)
        } else {
            recognizeLine(pts, first, last, diag, gap)
        }
    }

    private fun recognizeLine(pts: List<Pt>, first: Pt, last: Pt, diag: Float, len: Float): List<Pt>? {
        if (len < diag * 0.85f) return null
        var maxDev = 0f
        for (p in pts) maxDev = maxOf(maxDev, Geometry.distToSegment(p.x, p.y, first, last))
        return if (maxDev <= len * LINE_TOLERANCE) listOf(first, last) else null
    }

    private fun recognizePolygon(pts: List<Pt>, diag: Float, b: Bounds): List<Pt>? {
        val ring = rdp(pts, diag * RDP_EPSILON).dropLast(1).toMutableList()
        var changed = true
        while (changed && ring.size > 3) {
            changed = false
            val n = ring.size
            for (i in 0 until n) {
                if (interiorAngle(ring[(i - 1 + n) % n], ring[i], ring[(i + 1) % n]) > STRAIGHT_ANGLE) {
                    ring.removeAt(i)
                    changed = true
                    break
                }
            }
        }
        val t0 = pts.first().t
        return when (ring.size) {
            3 -> ring.map { Pt(it.x, it.y, t0, 1f) } + Pt(ring[0].x, ring[0].y, t0, 1f)
            4 -> {
                val n = 4
                for (i in 0 until n) {
                    val ang = interiorAngle(ring[(i - 1 + n) % n], ring[i], ring[(i + 1) % n])
                    if (ang < 65f || ang > 115f) return null
                }
                if (isAxisAligned(ring)) {
                    val rb = Bounds.of(ring)
                    listOf(
                        Pt(rb.left, rb.top, t0, 1f), Pt(rb.right, rb.top, t0, 1f),
                        Pt(rb.right, rb.bottom, t0, 1f), Pt(rb.left, rb.bottom, t0, 1f),
                        Pt(rb.left, rb.top, t0, 1f),
                    )
                } else {
                    ring.map { Pt(it.x, it.y, t0, 1f) } + Pt(ring[0].x, ring[0].y, t0, 1f)
                }
            }
            else -> null
        }
    }

    private fun recognizeEllipse(pts: List<Pt>, b: Bounds): List<Pt>? {
        val a0 = b.width / 2f
        val b0 = b.height / 2f
        if (a0 < 10f || b0 < 10f) return null
        val cx = (b.left + b.right) / 2f
        val cy = (b.top + b.bottom) / 2f
        var sum = 0f
        var worst = 0f
        for (p in pts) {
            val d = abs(hypot((p.x - cx) / a0, (p.y - cy) / b0) - 1f)
            sum += d
            worst = maxOf(worst, d)
        }
        if (sum / pts.size > 0.12f || worst > 0.35f) return null
        val circle = abs(a0 - b0) < 0.12f * maxOf(a0, b0)
        val ra = if (circle) (a0 + b0) / 2f else a0
        val rb = if (circle) (a0 + b0) / 2f else b0
        val t0 = pts.first().t
        return (0..72).map { i ->
            val th = (2.0 * PI * i / 72.0).toFloat()
            Pt(cx + ra * cos(th), cy + rb * sin(th), t0, 1f)
        }
    }

    private fun isAxisAligned(ring: List<Pt>): Boolean {
        for (i in ring.indices) {
            val a = ring[i]
            val c = ring[(i + 1) % ring.size]
            val ang = abs(Math.toDegrees(atan2((c.y - a.y).toDouble(), (c.x - a.x).toDouble()))) % 90.0
            if (min(ang, 90.0 - ang) > AXIS_TOLERANCE_DEG) return false
        }
        return true
    }

    private fun interiorAngle(a: Pt, c: Pt, d: Pt): Float {
        val ux = a.x - c.x
        val uy = a.y - c.y
        val vx = d.x - c.x
        val vy = d.y - c.y
        val lu = hypot(ux, uy)
        val lv = hypot(vx, vy)
        if (lu == 0f || lv == 0f) return 180f
        val cosv = ((ux * vx + uy * vy) / (lu * lv)).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(cosv).toDouble()).toFloat()
    }

    /** Ramer-Douglas-Peucker polyline simplification. */
    private fun rdp(p: List<Pt>, eps: Float): List<Pt> {
        if (p.size < 3) return p
        var maxD = 0f
        var idx = 0
        for (i in 1 until p.size - 1) {
            val d = Geometry.distToSegment(p[i].x, p[i].y, p.first(), p.last())
            if (d > maxD) { maxD = d; idx = i }
        }
        if (maxD <= eps) return listOf(p.first(), p.last())
        val l = rdp(p.subList(0, idx + 1), eps)
        val r = rdp(p.subList(idx, p.size), eps)
        return l.dropLast(1) + r
    }
}
