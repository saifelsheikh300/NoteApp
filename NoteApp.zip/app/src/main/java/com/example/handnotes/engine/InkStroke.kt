package com.example.handnotes.engine

import java.util.UUID

enum class ToolType { PEN, HIGHLIGHTER, ERASER_STROKE, ERASER_SEGMENT, LASSO, LASSO_RECT }

/**
 * A handwriting stroke stored as vector data (never as a bitmap).
 * [color] is ARGB. [opacity] is 0..1.
 */
data class InkStroke(
    val id: String = UUID.randomUUID().toString(),
    val points: List<Pt>,
    val color: Int,
    val width: Float,
    val tool: ToolType = ToolType.PEN,
    val opacity: Float = 1f,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val bounds: Bounds by lazy(LazyThreadSafetyMode.NONE) { Bounds.of(points) }
}
