package com.example.handnotes.engine

/** Logical page size. Strokes are stored in these units, so zooming never changes the data. */
object PageSpec {
    const val WIDTH = 1200f
    const val HEIGHT = 1700f
}
