package com.example.handnotes.data

import com.example.handnotes.engine.ImageObject
import com.example.handnotes.engine.InkStroke
import com.example.handnotes.engine.PageContent
import com.example.handnotes.engine.Pt
import com.example.handnotes.engine.ToolType
import org.json.JSONArray
import org.json.JSONObject

/**
 * Versioned on-disk format (formatVersion = 1).
 * Each page is its own file, so a big notebook is never loaded all at once.
 * To change the format later: bump VERSION and branch on the stored formatVersion when reading.
 */
object NoteFormat {
    const val VERSION = 1

    private fun r2(v: Float): Double = Math.round(v * 100f) / 100.0

    fun pageToJson(pageId: String, content: PageContent): String {
        val strokes = content.strokes
        val arr = JSONArray()
        for (s in strokes) {
            val pts = JSONArray()
            for (p in s.points) {
                pts.put(r2(p.x)); pts.put(r2(p.y)); pts.put(p.t); pts.put(r2(p.p))
            }
            arr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("color", s.color)
                    .put("width", r2(s.width))
                    .put("tool", s.tool.name)
                    .put("opacity", r2(s.opacity))
                    .put("createdAt", s.createdAt)
                    .put("pts", pts),
            )
        }
        val imgs = JSONArray()
        for (i in content.images) {
            imgs.put(
                JSONObject()
                    .put("id", i.id).put("file", i.file)
                    .put("cx", r2(i.cx)).put("cy", r2(i.cy)).put("w", r2(i.w)).put("h", r2(i.h))
                    .put("rot", r2(i.rotationDeg)),
            )
        }
        return JSONObject().put("formatVersion", VERSION).put("pageId", pageId).put("strokes", arr).put("images", imgs).toString()
    }

    fun pageFromJson(text: String): PageContent {
        val obj = JSONObject(text)
        return PageContent(strokesFrom(obj), imagesFrom(obj))
    }

    private fun imagesFrom(obj: JSONObject): List<ImageObject> {
        val arr = obj.optJSONArray("images") ?: return emptyList()
        val out = ArrayList<ImageObject>(arr.length())
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            out.add(
                ImageObject(
                    id = o.getString("id"),
                    file = o.getString("file"),
                    cx = o.getDouble("cx").toFloat(),
                    cy = o.getDouble("cy").toFloat(),
                    w = o.getDouble("w").toFloat(),
                    h = o.getDouble("h").toFloat(),
                    rotationDeg = o.optDouble("rot", 0.0).toFloat(),
                ),
            )
        }
        return out
    }

    private fun strokesFrom(obj: JSONObject): List<InkStroke> {
        val arr = obj.optJSONArray("strokes") ?: return emptyList()
        val out = ArrayList<InkStroke>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val a = o.getJSONArray("pts")
            val pts = ArrayList<Pt>(a.length() / 4)
            var k = 0
            while (k + 3 < a.length()) {
                pts.add(Pt(a.getDouble(k).toFloat(), a.getDouble(k + 1).toFloat(), a.getLong(k + 2), a.getDouble(k + 3).toFloat()))
                k += 4
            }
            val tool = try { ToolType.valueOf(o.optString("tool", "PEN")) } catch (e: IllegalArgumentException) { ToolType.PEN }
            out.add(
                InkStroke(
                    id = o.getString("id"),
                    points = pts,
                    color = o.getInt("color"),
                    width = o.getDouble("width").toFloat(),
                    tool = tool,
                    opacity = o.optDouble("opacity", 1.0).toFloat(),
                    createdAt = o.optLong("createdAt", 0L),
                ),
            )
        }
        return out
    }
}

object LibraryFormat {
    fun nodesToJson(nodes: List<LibraryNode>): String {
        val arr = JSONArray()
        for (n in nodes) {
            val o = JSONObject()
                .put("id", n.id)
                .put("name", n.name)
                .put("type", n.type.name)
                .put("createdAt", n.createdAt)
                .put("modifiedAt", n.modifiedAt)
                .put("favorite", n.favorite)
                .put("trashed", n.trashed)
            if (n.parentId != null) o.put("parentId", n.parentId)
            arr.put(o)
        }
        return JSONObject().put("formatVersion", NoteFormat.VERSION).put("nodes", arr).toString()
    }

    fun nodesFromJson(text: String): List<LibraryNode> {
        val arr = JSONObject(text).optJSONArray("nodes") ?: return emptyList()
        val out = ArrayList<LibraryNode>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val parent = o.optString("parentId", "")
            out.add(
                LibraryNode(
                    id = o.getString("id"),
                    parentId = if (parent.isEmpty()) null else parent,
                    name = o.optString("name", ""),
                    type = try { NodeType.valueOf(o.optString("type", "NOTEBOOK")) } catch (e: IllegalArgumentException) { NodeType.NOTEBOOK },
                    createdAt = o.optLong("createdAt", 0L),
                    modifiedAt = o.optLong("modifiedAt", 0L),
                    favorite = o.optBoolean("favorite", false),
                    trashed = o.optBoolean("trashed", false),
                ),
            )
        }
        return out
    }

    fun metaToJson(m: NotebookMeta): String {
        val pages = JSONArray()
        for (p in m.pages) {
            val o = JSONObject().put("id", p.id).put("title", p.title)
            if (p.pdfPage >= 0) o.put("pdfPage", p.pdfPage).put("pdfW", p.pdfW.toDouble()).put("pdfH", p.pdfH.toDouble())
            pages.put(o)
        }
        return JSONObject()
            .put("formatVersion", NoteFormat.VERSION)
            .put("id", m.id)
            .put("paper", m.paper.name)
            .put("pages", pages)
            .toString()
    }

    fun metaFromJson(text: String): NotebookMeta {
        val o = JSONObject(text)
        val arr = o.getJSONArray("pages")
        val pages = ArrayList<PageInfo>(arr.length())
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            pages.add(
                PageInfo(
                    p.getString("id"),
                    p.optString("title", ""),
                    p.optInt("pdfPage", -1),
                    p.optDouble("pdfW", 0.0).toFloat(),
                    p.optDouble("pdfH", 0.0).toFloat(),
                ),
            )
        }
        val paper = try { PaperType.valueOf(o.optString("paper", "RULED")) } catch (e: IllegalArgumentException) { PaperType.RULED }
        return NotebookMeta(o.getString("id"), pages, paper)
    }
}
