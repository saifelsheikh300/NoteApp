package com.example.handnotes.data

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/**
 * Crash-safe text files.
 *
 * Layout on disk: first line = SHA-256 of the rest, then the content.
 * Write: content -> file.tmp (fsync) -> keep old file as file.bak -> atomic rename tmp -> file.
 * Read: the first copy whose checksum matches wins (tmp, then file, then bak),
 * so a crash at any moment leaves a valid copy behind.
 */
object SafeFile {
    private fun sha(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun tmpOf(f: File) = File(f.path + ".tmp")
    private fun bakOf(f: File) = File(f.path + ".bak")

    @Throws(IOException::class)
    fun write(file: File, content: String) {
        file.parentFile?.mkdirs()
        val tmp = tmpOf(file)
        val data = (sha(content) + "\n" + content).toByteArray(Charsets.UTF_8)
        FileOutputStream(tmp).use { out ->
            out.write(data)
            out.flush()
            out.fd.sync()
        }
        if (file.exists()) file.copyTo(bakOf(file), overwrite = true)
        try {
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (e: Exception) {
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    /** Returns the newest valid content, or null if nothing valid exists. */
    fun read(file: File): String? {
        for (f in listOf(tmpOf(file), file, bakOf(file))) {
            val s = readVerified(f)
            if (s != null) return s
        }
        return null
    }

    fun exists(file: File): Boolean = file.exists() || tmpOf(file).exists() || bakOf(file).exists()

    private fun readVerified(f: File): String? {
        if (!f.isFile) return null
        val text = try { f.readText(Charsets.UTF_8) } catch (e: IOException) { return null }
        if (text.length < 65 || text[64] != '\n') return null
        val body = text.substring(65)
        return if (sha(body) == text.substring(0, 64)) body else null
    }
}
