package com.example.handnotes.engine

import java.util.UUID
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** A picture placed on a page. [file] is a name in the shared image store. Position is the centre, in page units. */
data class ImageObject(
    val id: String = UUID.randomUUID().toString(),
    val file: String,
    val cx: Float,
    val cy: Float,
    val w: Float,
    val h: Float,
    val rotationDeg: Float = 0f,
) {
    private val rad: Double get() = Math.toRadians(rotationDeg.toDouble())

    /** Axis-aligned box around the (possibly rotated) picture. */
    fun bounds(): Bounds {
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (sx in floatArrayOf(-1f, 1f)) {
            for (sy in floatArrayOf(-1f, 1f)) {
                val dx = sx * w / 2f
                val dy = sy * h / 2f
                val x = cx + dx * c - dy * s
                val y = cy + dx * s + dy * c
                l = minOf(l, x); r = maxOf(r, x); t = minOf(t, y); b = maxOf(b, y)
            }
        }
        return Bounds(l, t, r, b)
    }

    fun contains(x: Float, y: Float): Boolean {
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val dx = x - cx
        val dy = y - cy
        val lx = dx * c + dy * s
        val ly = -dx * s + dy * c
        return abs(lx) <= w / 2f && abs(ly) <= h / 2f
    }
}

/** What one page holds: ink and pictures. */
data class PageContent(val strokes: List<InkStroke>, val images: List<ImageObject> = emptyList())

object ImageTransform {
    fun translate(i: ImageObject, dx: Float, dy: Float): ImageObject = i.copy(cx = i.cx + dx, cy = i.cy + dy)

    fun scale(i: ImageObject, f: Float, ox: Float, oy: Float): ImageObject =
        i.copy(cx = ox + (i.cx - ox) * f, cy = oy + (i.cy - oy) * f, w = i.w * f, h = i.h * f)

    fun rotate(i: ImageObject, radians: Float, ox: Float, oy: Float): ImageObject {
        val c = cos(radians)
        val s = sin(radians)
        val x = i.cx - ox
        val y = i.cy - oy
        return i.copy(
            cx = ox + x * c - y * s,
            cy = oy + x * s + y * c,
            rotationDeg = i.rotationDeg + Math.toDegrees(radians.toDouble()).toFloat(),
        )
    }

    fun clone(images: List<ImageObject>, dx: Float, dy: Float): List<ImageObject> =
        images.map { translate(it, dx, dy).copy(id = UUID.randomUUID().toString()) }
}
