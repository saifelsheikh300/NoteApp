package com.example.handnotes.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class Ic {
    HOME, FOLDER, STAR, STAR_FILLED, TRASH, SEARCH, GEAR, PLUS, UNDO, REDO, PEN, HIGHLIGHTER, ERASER, LASSO,
    IMAGE, SIDEBAR, SHARE, MORE, PAGE_ADD, CLOSE, CHECK, CHEVRON, CAMERA, BACK, NOTE, LOCK, HAND,
}

/** Simple line icons drawn in code (24 x 24 grid), so the app needs no icon files or copied artwork. */
@Composable
fun GIcon(kind: Ic, tint: Color, modifier: Modifier = Modifier, box: Dp = 24.dp) {
    Canvas(modifier.size(box)) {
        val u = this.size.minDimension / 24f
        val st = Stroke(width = 2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun poly(vararg p: Float, close: Boolean = false) {
            val path = Path()
            path.moveTo(p[0] * u, p[1] * u)
            var i = 2
            while (i + 1 < p.size) { path.lineTo(p[i] * u, p[i + 1] * u); i += 2 }
            if (close) path.close()
            drawPath(path, tint, style = st)
        }
        fun o(x: Float, y: Float) = Offset(x * u, y * u)
        when (kind) {
            Ic.HOME -> { poly(3f, 11f, 12f, 3f, 21f, 11f); poly(5f, 9.5f, 5f, 20f, 19f, 20f, 19f, 9.5f) }
            Ic.FOLDER -> poly(3f, 6f, 10f, 6f, 12f, 8.5f, 21f, 8.5f, 21f, 19f, 3f, 19f, close = true)
            Ic.STAR, Ic.STAR_FILLED -> {
                val path = Path()
                for (k in 0..9) {
                    val r = if (k % 2 == 0) 9.5f else 4f
                    val a = (-90.0 + k * 36.0) * PI / 180.0
                    val x = (12f + r * cos(a).toFloat()) * u
                    val y = (12.5f + r * sin(a).toFloat()) * u
                    if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                if (kind == Ic.STAR_FILLED) drawPath(path, tint) else drawPath(path, tint, style = st)
            }
            Ic.TRASH -> {
                poly(4f, 7f, 20f, 7f); poly(9f, 7f, 9f, 4f, 15f, 4f, 15f, 7f)
                poly(6f, 7f, 7f, 20f, 17f, 20f, 18f, 7f); poly(10f, 11f, 10f, 16f); poly(14f, 11f, 14f, 16f)
            }
            Ic.SEARCH -> { drawCircle(tint, 6f * u, o(10f, 10f), style = st); poly(14.5f, 14.5f, 20f, 20f) }
            Ic.GEAR -> {
                drawCircle(tint, 3.2f * u, o(12f, 12f), style = st)
                drawCircle(tint, 6.4f * u, o(12f, 12f), style = st)
                for (k in 0 until 8) {
                    val a = k * PI / 4.0
                    poly(12f + 6.4f * cos(a).toFloat(), 12f + 6.4f * sin(a).toFloat(), 12f + 9f * cos(a).toFloat(), 12f + 9f * sin(a).toFloat())
                }
            }
            Ic.PLUS -> { poly(12f, 5f, 12f, 19f); poly(5f, 12f, 19f, 12f) }
            Ic.UNDO -> { poly(9f, 6f, 4f, 11f, 9f, 16f); poly(4f, 11f, 14f, 11f, 18f, 12.5f, 19.5f, 16f, 19.5f, 19f) }
            Ic.REDO -> { poly(15f, 6f, 20f, 11f, 15f, 16f); poly(20f, 11f, 10f, 11f, 6f, 12.5f, 4.5f, 16f, 4.5f, 19f) }
            Ic.PEN -> poly(4f, 20f, 5f, 15f, 16f, 4f, 20f, 8f, 9f, 19f, 4f, 20f)
            Ic.HIGHLIGHTER -> { poly(7f, 15f, 15f, 5f, 20f, 9f, 12f, 19f); poly(7f, 15f, 6f, 19f, 12f, 19f); poly(4f, 21f, 20f, 21f) }
            Ic.ERASER -> { poly(5f, 14f, 13f, 5f, 19f, 10f, 11f, 19f, close = true); poly(8f, 10f, 15f, 16f); poly(11f, 19f, 20f, 19f) }
            Ic.LASSO -> {
                val dash = PathEffect.dashPathEffect(floatArrayOf(3f * u, 3f * u))
                drawOval(tint, o(3f, 4f), Size(18f * u, 12f * u), style = Stroke(width = 2f * u, cap = StrokeCap.Round, pathEffect = dash))
                poly(10f, 16f, 9f, 21f)
            }
            Ic.IMAGE -> {
                drawRoundRect(tint, o(3f, 4f), Size(18f * u, 16f * u), CornerRadius(2f * u), style = st)
                drawCircle(tint, 1.8f * u, o(9f, 10f)); poly(4f, 18f, 10f, 13f, 14f, 16f, 17f, 13f, 20f, 16f)
            }
            Ic.SIDEBAR -> { drawRoundRect(tint, o(3f, 4f), Size(18f * u, 16f * u), CornerRadius(2f * u), style = st); poly(9f, 4f, 9f, 20f) }
            Ic.SHARE -> { poly(12f, 15f, 12f, 3.5f); poly(8f, 7f, 12f, 3.5f, 16f, 7f); poly(7f, 10f, 5f, 10f, 5f, 21f, 19f, 21f, 19f, 10f, 17f, 10f) }
            Ic.MORE -> { drawCircle(tint, 1.7f * u, o(5f, 12f)); drawCircle(tint, 1.7f * u, o(12f, 12f)); drawCircle(tint, 1.7f * u, o(19f, 12f)) }
            Ic.PAGE_ADD -> { poly(13f, 3f, 5f, 3f, 5f, 21f, 19f, 21f, 19f, 11f); poly(17f, 3f, 17f, 9f); poly(14f, 6f, 20f, 6f) }
            Ic.CLOSE -> { poly(6f, 6f, 18f, 18f); poly(18f, 6f, 6f, 18f) }
            Ic.CHECK -> poly(5f, 12.5f, 10f, 17.5f, 19f, 7f)
            Ic.CHEVRON -> poly(6f, 9f, 12f, 15f, 18f, 9f)
            Ic.CAMERA -> {
                drawRoundRect(tint, o(3f, 7f), Size(18f * u, 13f * u), CornerRadius(2f * u), style = st)
                drawCircle(tint, 3.5f * u, o(12f, 13.5f), style = st); poly(8f, 7f, 9.5f, 4f, 14.5f, 4f, 16f, 7f)
            }
            Ic.BACK -> poly(15f, 5f, 8f, 12f, 15f, 19f)
            Ic.NOTE -> { poly(5f, 3f, 19f, 3f, 19f, 21f, 5f, 21f, close = true); poly(8f, 8f, 16f, 8f); poly(8f, 12f, 16f, 12f); poly(8f, 16f, 13f, 16f) }
            Ic.LOCK -> { drawRoundRect(tint, o(5f, 11f), Size(14f * u, 10f * u), CornerRadius(2f * u), style = st); poly(8f, 11f, 8f, 8f, 10f, 5f, 14f, 5f, 16f, 8f, 16f, 11f) }
            Ic.HAND -> {
                poly(6f, 12f, 6f, 6f); poly(10f, 11f, 10f, 4f); poly(14f, 11f, 14f, 4f); poly(18f, 12f, 18f, 7f)
                poly(6f, 12f, 6f, 17f, 10f, 21f, 16f, 21f, 19f, 17f, 19f, 12f)
            }
        }
    }
}
