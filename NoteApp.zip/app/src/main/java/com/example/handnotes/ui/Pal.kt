package com.example.handnotes.ui

import androidx.compose.ui.graphics.Color

/** App colours. One place, so screens stay consistent. */
object Pal {
    val libBg = Color(0xFF000000)
    val sidebar = Color(0xFF1B1B1B)
    val tile = Color(0xFF2A2A2A)
    val selected = Color(0xFF2A2A2A)
    val accent = Color(0xFF22B5D6)
    val folderSel = Color(0xFFE07050)
    val dim = Color(0xFFA9A9A9)
    val pill = Color(0xFF2E2E2E)
    val dialog = Color(0xFF1F1F1F)
    val teal = Color(0xFF3FB6D6)
    val star = Color(0xFFFFC53D)
    val bar = Color(0xFF2B2B2B)
    val floating = Color(0xFF262626)
    val tabBar = Color(0xFF1F3466)
    val toolBar = Color(0xFF274882)
    val canvasBg = Color(0xFF000000)
}
