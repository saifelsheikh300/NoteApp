package com.example.handnotes.ui

import androidx.compose.ui.graphics.Color

/** App colours. One place, so screens stay consistent. */
object Pal {
    val libBg = Color(0xFF1C1B1A)
    val sidebar = Color(0xFF2B2A29)
    val selected = Color(0xFF1E3A78)
    val accent = Color(0xFF1A8CFF)
    val dim = Color(0xFFA9A9A9)
    val pill = Color(0xFF3A3A3A)
    val dialog = Color(0xFF262626)
    val teal = Color(0xFF3FB6D6)
    val star = Color(0xFFFFC53D)
    val tabBar = Color(0xFF1F3466)
    val toolBar = Color(0xFF274882)
    val floating = Color(0xFF1C1C1C)
    val canvasBg = Color(0xFF1E1E1E)
}
