package com.example.handnotes.engine

/** Light smoothing for finished strokes. [amount] is 0 (none) .. 1 (strong). */
object Smoothing {
    fun smooth(points: List<Pt>, amount: Float): List<Pt> {
        if (points.size < 3 || amount <= 0f) return points
        val a = amount.coerceIn(0f, 0.9f)
        var cur = points
        repeat(2) {
            val next = ArrayList<Pt>(cur.size)
            next.add(cur.first())
            for (i in 1 until cur.size - 1) {
                val p = cur[i]
                val mx = (cur[i - 1].x + cur[i + 1].x) / 2f
                val my = (cur[i - 1].y + cur[i + 1].y) / 2f
                next.add(p.copy(x = p.x * (1f - a) + mx * a, y = p.y * (1f - a) + my * a))
            }
            next.add(cur.last())
            cur = next
        }
        return cur
    }
}
