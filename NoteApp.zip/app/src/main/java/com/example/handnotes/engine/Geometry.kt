package com.example.handnotes.engine

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** One sampled point of a stroke. [p] is pressure; devices without pressure report a constant 1. */
data class Pt(val x: Float, val y: Float, val t: Long = 0L, val p: Float = 1f)

/** Axis-aligned bounding box. */
data class Bounds(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val diagonal: Float get() = hypot(width, height)

    fun inflate(r: Float) = Bounds(left - r, top - r, right + r, bottom + r)
    fun contains(x: Float, y: Float) = x >= left && x <= right && y >= top && y <= bottom
    fun intersects(o: Bounds) = left <= o.right && right >= o.left && top <= o.bottom && bottom >= o.top

    companion object {
        fun of(points: List<Pt>): Bounds {
            if (points.isEmpty()) return Bounds(0f, 0f, 0f, 0f)
            var l = points[0].x
            var r = l
            var t = points[0].y
            var b = t
            for (p in points) {
                l = min(l, p.x); r = max(r, p.x)
                t = min(t, p.y); b = max(b, p.y)
            }
            return Bounds(l, t, r, b)
        }
    }
}

object Geometry {
    fun distToSegment(px: Float, py: Float, a: Pt, b: Pt): Float {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val len2 = dx * dx + dy * dy
        if (len2 == 0f) return hypot(px - a.x, py - a.y)
        val t = (((px - a.x) * dx + (py - a.y) * dy) / len2).coerceIn(0f, 1f)
        return hypot(px - (a.x + t * dx), py - (a.y + t * dy))
    }

    private fun orient(a: Pt, b: Pt, c: Pt): Float =
        (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)

    /** True only for proper crossings (touching endpoints do not count). */
    fun segmentsIntersect(a: Pt, b: Pt, c: Pt, d: Pt): Boolean {
        val o1 = orient(a, b, c)
        val o2 = orient(a, b, d)
        val o3 = orient(c, d, a)
        val o4 = orient(c, d, b)
        return o1 * o2 < 0f && o3 * o4 < 0f
    }

    /** Inserts points so that no two neighbours are further apart than [maxGap]. */
    fun densify(points: List<Pt>, maxGap: Float): List<Pt> {
        if (points.size < 2 || maxGap <= 0f) return points
        val out = ArrayList<Pt>(points.size)
        out.add(points[0])
        for (i in 1 until points.size) {
            val a = points[i - 1]
            val b = points[i]
            val d = hypot(b.x - a.x, b.y - a.y)
            val steps = (d / maxGap).toInt()
            for (s in 1..steps) {
                val f = s / (steps + 1f)
                out.add(Pt(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f, a.t, a.p))
            }
            out.add(b)
        }
        return out
    }
}
