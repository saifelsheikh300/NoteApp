package com.example.handnotes.data

import com.example.handnotes.engine.PageContent
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Runs disk writes in order on a background thread (or inline when [exec] is null, for tests). */
class IoQueue(private val exec: ExecutorService?) {
    @Volatile var lastError: Throwable? = null

    fun post(block: () -> Unit) {
        if (exec == null) {
            block()
        } else {
            exec.execute {
                try { block() } catch (e: Throwable) { lastError = e }
            }
        }
    }

    /** Blocks until every queued write has finished. */
    fun awaitIdle() {
        exec?.submit(Runnable { })?.get()
    }

    companion object {
        fun background(): IoQueue = IoQueue(
            Executors.newSingleThreadExecutor { r -> Thread(r, "notes-io").apply { isDaemon = true } },
        )
    }
}

/**
 * Library tree + notebook storage. No limits on notebooks, folders or pages.
 * Folder layout: index.json, notebooks/<id>/meta.json, notebooks/<id>/page_<pageId>.json.
 * Pure JVM code so it is unit-tested without a device.
 */
class LibraryRepository(private val root: File, private val io: IoQueue = IoQueue.background()) {
    private val indexFile = File(root, "index.json")

    @Volatile private var nodes: List<LibraryNode> = loadIndex()

    // Data queued for writing but not yet on disk, so reads never see stale content.
    private val pendingPages = ConcurrentHashMap<String, PageContent>()
    private val pendingMeta = ConcurrentHashMap<String, NotebookMeta>()

    private fun loadIndex(): List<LibraryNode> {
        val text = SafeFile.read(File(root, "index.json")) ?: return emptyList()
        return try { LibraryFormat.nodesFromJson(text) } catch (e: Exception) { emptyList() }
    }

    private fun newId() = UUID.randomUUID().toString()
    fun newNotebookId(): String = newId()
    private fun now() = System.currentTimeMillis()
    private fun nbDir(id: String) = File(root, "notebooks/$id")
    private fun metaFile(id: String) = File(nbDir(id), "meta.json")
    private fun pageFile(nb: String, page: String) = File(nbDir(nb), "page_$page.json")

    private fun persistIndex() {
        val text = LibraryFormat.nodesToJson(nodes)
        io.post { SafeFile.write(indexFile, text) }
    }

    private fun update(f: (List<LibraryNode>) -> List<LibraryNode>) {
        nodes = f(nodes)
        persistIndex()
    }

    // ---------- queries ----------

    fun all(): List<LibraryNode> = nodes
    fun get(id: String): LibraryNode? = nodes.firstOrNull { it.id == id }

    fun isLive(n: LibraryNode): Boolean {
        var cur: LibraryNode? = n
        var guard = 0
        while (cur != null && guard++ < 10_000) {
            if (cur.trashed) return false
            val p = cur.parentId ?: return true
            cur = get(p)
        }
        return cur == null
    }

    fun children(parent: String?): List<LibraryNode> = nodes.filter { it.parentId == parent && !it.trashed }
    fun liveNodes(): List<LibraryNode> = nodes.filter { isLive(it) }

    fun trashedRoots(): List<LibraryNode> =
        nodes.filter { it.trashed && (it.parentId == null || get(it.parentId)?.trashed != true) }

    fun descendantIds(id: String): Set<String> {
        val out = HashSet<String>()
        val queue = ArrayDeque<String>()
        queue.add(id)
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            for (n in nodes) if (n.parentId == cur && out.add(n.id)) queue.add(n.id)
        }
        return out
    }

    fun pathName(id: String?): String {
        val names = ArrayList<String>()
        var cur = id?.let { get(it) }
        var guard = 0
        while (cur != null && guard++ < 10_000) {
            names.add(cur.name)
            cur = cur.parentId?.let { get(it) }
        }
        return names.reversed().joinToString(" / ")
    }

    // ---------- library changes ----------

    fun createFolder(parent: String?, name: String): LibraryNode {
        val n = LibraryNode(newId(), parent, name.trim().ifEmpty { "Folder" }, NodeType.FOLDER, now(), now())
        update { it + n }
        return n
    }

    fun createNotebook(parent: String?, name: String, paper: PaperType = PaperType.RULED): LibraryNode {
        val n = LibraryNode(newId(), parent, name.trim().ifEmpty { "Notebook" }, NodeType.NOTEBOOK, now(), now())
        val first = PageInfo(newId())
        saveMeta(NotebookMeta(n.id, listOf(first), paper))
        savePage(n.id, first.id, PageContent(emptyList()))
        update { it + n }
        return n
    }

    fun pdfFile(nb: String): File = File(nbDir(nb), "source.pdf")

    /** Registers a notebook whose source.pdf was already copied to [pdfFile]. The PDF itself is never modified. */
    fun registerPdfNotebook(id: String, parent: String?, name: String, pages: List<PageInfo>): LibraryNode {
        val n = LibraryNode(id, parent, name.trim().ifEmpty { "PDF" }, NodeType.NOTEBOOK, now(), now())
        saveMeta(NotebookMeta(id, pages, PaperType.BLANK))
        update { it + n }
        return n
    }

    fun rename(id: String, name: String) {
        update { l -> l.map { n -> if (n.id == id) n.copy(name = name.trim().ifEmpty { n.name }, modifiedAt = now()) else n } }
    }

    fun touch(id: String) {
        update { l -> l.map { n -> if (n.id == id) n.copy(modifiedAt = now()) else n } }
    }

    fun setFavorite(id: String, favorite: Boolean) {
        update { l -> l.map { n -> if (n.id == id) n.copy(favorite = favorite) else n } }
    }

    /** Returns false if the move would put a folder inside itself. */
    fun move(id: String, newParent: String?): Boolean {
        if (newParent != null) {
            val target = get(newParent) ?: return false
            if (target.type != NodeType.FOLDER || newParent == id || newParent in descendantIds(id)) return false
        }
        update { l -> l.map { n -> if (n.id == id) n.copy(parentId = newParent, modifiedAt = now()) else n } }
        return true
    }

    fun trash(id: String) {
        update { l -> l.map { n -> if (n.id == id) n.copy(trashed = true) else n } }
    }

    fun restore(id: String) {
        val node = get(id) ?: return
        val parentOk = node.parentId == null || get(node.parentId)?.let { isLive(it) } == true
        update { l ->
            l.map { n ->
                if (n.id == id) n.copy(trashed = false, parentId = if (parentOk) n.parentId else null) else n
            }
        }
    }

    fun deleteForever(id: String) {
        val ids = descendantIds(id) + id
        val notebookIds = nodes.filter { it.id in ids && it.type == NodeType.NOTEBOOK }.map { it.id }
        update { l -> l.filter { it.id !in ids } }
        for (nb in notebookIds) {
            pendingMeta.remove(nb)
            pendingPages.keys.filter { it.startsWith("$nb/") }.forEach { pendingPages.remove(it) }
            io.post { nbDir(nb).deleteRecursively() }
        }
    }

    fun emptyTrash() {
        for (n in trashedRoots()) deleteForever(n.id)
    }

    /** Copies a notebook, or a whole folder with everything in it. */
    fun duplicate(id: String): LibraryNode? {
        val src = get(id) ?: return null
        io.awaitIdle()
        val copy = duplicateInto(src, src.parentId, src.name + " (copy)")
        persistIndex()
        return copy
    }

    private fun duplicateInto(src: LibraryNode, parent: String?, name: String): LibraryNode {
        val n = src.copy(id = newId(), parentId = parent, name = name, createdAt = now(), modifiedAt = now(), favorite = false, trashed = false)
        if (src.type == NodeType.NOTEBOOK) {
            val from = nbDir(src.id)
            if (from.exists()) from.copyRecursively(nbDir(n.id), overwrite = true)
            saveMeta(loadMeta(src.id).copy(id = n.id))
        }
        nodes = nodes + n
        if (src.type == NodeType.FOLDER) {
            val kids = nodes.filter { it.parentId == src.id && !it.trashed }
            for (k in kids) duplicateInto(k, n.id, k.name)
        }
        return n
    }

    // ---------- notebooks and pages ----------

    fun loadMeta(nb: String): NotebookMeta {
        pendingMeta[nb]?.let { return it }
        val text = SafeFile.read(metaFile(nb))
        if (text != null) {
            try { return LibraryFormat.metaFromJson(text) } catch (e: Exception) { /* fall through to default */ }
        }
        return NotebookMeta(nb, listOf(PageInfo(newId())))
    }

    fun saveMeta(meta: NotebookMeta) {
        pendingMeta[meta.id] = meta
        val text = LibraryFormat.metaToJson(meta)
        io.post {
            try { SafeFile.write(metaFile(meta.id), text) } finally { pendingMeta.remove(meta.id, meta) }
        }
    }

    fun loadPage(nb: String, page: String): PageContent {
        pendingPages["$nb/$page"]?.let { return it }
        val text = SafeFile.read(pageFile(nb, page)) ?: return PageContent(emptyList())
        return try { NoteFormat.pageFromJson(text) } catch (e: Exception) { PageContent(emptyList()) }
    }

    fun savePage(nb: String, page: String, content: PageContent) {
        val key = "$nb/$page"
        val snap = content
        pendingPages[key] = snap
        io.post {
            try { SafeFile.write(pageFile(nb, page), NoteFormat.pageToJson(page, snap)) } finally { pendingPages.remove(key, snap) }
        }
    }

    fun deletePage(nb: String, page: String) {
        pendingPages.remove("$nb/$page")
        io.post {
            val f = pageFile(nb, page)
            f.delete(); File(f.path + ".tmp").delete(); File(f.path + ".bak").delete()
        }
    }

    fun awaitIdle() = io.awaitIdle()
}
