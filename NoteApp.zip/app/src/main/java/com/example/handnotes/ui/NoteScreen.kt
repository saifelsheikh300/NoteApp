package com.example.handnotes.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.handnotes.R
import com.example.handnotes.engine.ToolType

private val palette = listOf(
    0xFF000000.toInt(), 0xFF1565C0.toInt(), 0xFFC62828.toInt(),
    0xFF2E7D32.toInt(), 0xFFF9A825.toInt(),
)

@Composable
private fun ToolChip(state: NoteState, type: ToolType, label: Int) {
    FilterChip(
        selected = state.tool == type,
        onClick = { state.selectTool(type) },
        label = { Text(stringResource(label)) },
    )
}

@Composable
internal fun Toolbar(state: NoteState) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ToolChip(state, ToolType.PEN, R.string.tool_pen)
            ToolChip(state, ToolType.HIGHLIGHTER, R.string.tool_highlighter)
            ToolChip(state, ToolType.ERASER_SEGMENT, R.string.tool_eraser_segment)
            ToolChip(state, ToolType.ERASER_STROKE, R.string.tool_eraser_stroke)
            ToolChip(state, ToolType.LASSO, R.string.tool_lasso)
            ToolChip(state, ToolType.LASSO_RECT, R.string.tool_lasso_rect)
            FilterChip(
                selected = state.scribbleEnabled,
                onClick = { state.scribbleEnabled = !state.scribbleEnabled },
                label = { Text(stringResource(R.string.scribble_erase)) },
            )
            FilterChip(
                selected = state.shapeSnap,
                onClick = { state.shapeSnap = !state.shapeSnap },
                label = { Text(stringResource(R.string.shape_snap)) },
            )
            palette.forEach { c ->
                Surface(
                    modifier = Modifier
                        .size(32.dp)
                        .border(if (state.color == c) 3.dp else 1.dp, Color.Gray, CircleShape)
                        .clickable { state.color = c },
                    shape = CircleShape,
                    color = Color(c),
                ) {}
            }
            Slider(
                value = state.width,
                onValueChange = { state.width = it },
                valueRange = 1f..24f,
                modifier = Modifier.width(140.dp),
            )
            OutlinedButton(onClick = { state.undo() }, enabled = state.canUndo) { Text(stringResource(R.string.undo)) }
            OutlinedButton(onClick = { state.redo() }, enabled = state.canRedo) { Text(stringResource(R.string.redo)) }
            OutlinedButton(onClick = { state.clearPage() }) { Text(stringResource(R.string.clear_page)) }
        }
    }
}

@Composable
internal fun SelectionBar(state: NoteState) {
    val has = state.hasSelection
    Surface(tonalElevation = 1.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            OutlinedButton(onClick = { state.deleteSelection() }, enabled = has) { Text(stringResource(R.string.sel_delete)) }
            OutlinedButton(onClick = { state.copySelection() }, enabled = has) { Text(stringResource(R.string.sel_copy)) }
            OutlinedButton(onClick = { state.cutSelection() }, enabled = has) { Text(stringResource(R.string.sel_cut)) }
            OutlinedButton(onClick = { state.pasteClipboard() }, enabled = state.clipboardSize > 0) { Text(stringResource(R.string.sel_paste)) }
            OutlinedButton(onClick = { state.duplicateSelection() }, enabled = has) { Text(stringResource(R.string.sel_duplicate)) }
            OutlinedButton(onClick = { state.scaleSelection(1.2f) }, enabled = has) { Text(stringResource(R.string.sel_bigger)) }
            OutlinedButton(onClick = { state.scaleSelection(1f / 1.2f) }, enabled = has) { Text(stringResource(R.string.sel_smaller)) }
            OutlinedButton(onClick = { state.rotateSelection(-15f) }, enabled = has) { Text(stringResource(R.string.sel_rotate_left)) }
            OutlinedButton(onClick = { state.rotateSelection(15f) }, enabled = has) { Text(stringResource(R.string.sel_rotate_right)) }
            OutlinedButton(onClick = { state.clearSelection() }, enabled = has) { Text(stringResource(R.string.sel_clear)) }
        }
    }
}
