package com.example.handnotes.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.data.NotebookMeta
import com.example.handnotes.data.PageInfo
import com.example.handnotes.data.PaperColor
import com.example.handnotes.data.dims
import com.example.handnotes.engine.PageSpec
import com.example.handnotes.engine.ToolType
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

private val presetColors = listOf(0xFF000000.toInt(), 0xFF0A84FF.toInt(), 0xFFD32F2F.toInt(), 0xFF2E7D32.toInt(), 0xFFFFFFFF.toInt())
private val swatches = listOf(
    0xFF000000, 0xFF424242, 0xFF9E9E9E, 0xFFFFFFFF, 0xFFD32F2F, 0xFFFF6D00, 0xFFFFC107, 0xFF2E7D32,
    0xFF00ACC1, 0xFF0A84FF, 0xFF283593, 0xFF7B1FA2, 0xFFE91E63, 0xFF6D4C41, 0xFF00C853, 0xFFFF80AB,
).map { it.toInt() }
private val widthPresets = listOf(3f, 6f, 12f)
private val eraserSizes = listOf(10f, 18f, 34f)
private val red = Color(0xFFFF6B6B)
private val barTeal = Color(0xFF2E6C7A)

@Composable
fun EditorScreen(app: AppModel) {
    val meta = app.meta ?: return
    val ed = app.editor
    var showPalm by remember { mutableStateOf(false) }
    var goTo by remember { mutableStateOf(false) }
    var template by remember { mutableStateOf(false) }
    var addColor by remember { mutableStateOf(false) }
    val name = app.openNotebookId?.let { app.repo.get(it)?.name } ?: ""

    val exportAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) app.exportPdf(uri, wholeNotebook = true)
    }
    val exportOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) app.exportPdf(uri, wholeNotebook = false)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) app.insertImage(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) app.insertCameraPicture()
    }

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Column(Modifier.fillMaxSize().background(Pal.canvasBg)) {
            TabBar(name) { app.closeNotebook() }
            TopToolbar(
                app = app,
                pageCount = meta.pages.size,
                onGallery = { pickImage.launch(arrayOf("image/*")) },
                onCamera = { try { takePhoto.launch(app.prepareCameraUri()) } catch (e: Exception) { /* no camera app */ } },
                onExportAll = { exportAll.launch("$name.pdf") },
                onExportOne = { exportOne.launch("$name-${app.pageIndex + 1}.pdf") },
                onTemplate = { template = true },
                onGoTo = { goTo = true },
                onPalm = { showPalm = true },
            )
            Row(Modifier.weight(1f).fillMaxWidth()) {
                if (app.pagesOpen) PagesPanel(app, meta)
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    DrawingSurface(ed, Modifier.fillMaxSize())
                    UndoRedoPill(ed, Modifier.align(Alignment.TopStart).padding(12.dp))
                    Column(
                        Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FloatingBar(app) { addColor = true }
                        if (ed.isLassoTool) SelectionBar(ed)
                    }
                    Box(
                        Modifier.align(Alignment.BottomStart).padding(16.dp).clip(RoundedCornerShape(16.dp))
                            .background(Color(0xCC4A4A4A)).clickable { goTo = true }.padding(horizontal = 14.dp, vertical = 8.dp),
                    ) { Text(stringResource(R.string.page_of, app.pageIndex + 1, meta.pages.size)) }
                }
            }
        }
    }

    if (showPalm) PalmSettingsDialog(app) { showPalm = false }
    if (goTo) GoToPageDialog(app, meta.pages.size) { goTo = false }
    if (template) TemplateDialog(app, meta) { template = false }
    if (addColor) ColorDialog({ ed.color = it }) { addColor = false }
}

@Composable
private fun TabBar(name: String, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(44.dp).background(Pal.tabBar), verticalAlignment = Alignment.CenterVertically) {
        IconBtn(Ic.HOME, box = 40, onClick = onClose)
        Row(
            Modifier.fillMaxHeight().padding(top = 6.dp)
                .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)).background(Pal.toolBar)
                .padding(start = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 260.dp))
            IconBtn(Ic.CLOSE, box = 36, onClick = onClose)
        }
    }
}

@Composable
private fun ToolBtn(icon: Ic, selected: Boolean = false, chevron: Boolean = false, onClick: () -> Unit) {
    val tint = if (selected) Color(0xFF1B2A4A) else Color.White
    Row(
        Modifier.height(44.dp).clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0xFFCFE0F5) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GIcon(icon, tint)
        if (chevron) GIcon(Ic.CHEVRON, tint, box = 14.dp)
    }
}

@Composable
private fun TopToolbar(
    app: AppModel,
    pageCount: Int,
    onGallery: () -> Unit,
    onCamera: () -> Unit,
    onExportAll: () -> Unit,
    onExportOne: () -> Unit,
    onTemplate: () -> Unit,
    onGoTo: () -> Unit,
    onPalm: () -> Unit,
) {
    val ed = app.editor
    var lassoMenu by remember { mutableStateOf(false) }
    var imageMenu by remember { mutableStateOf(false) }
    var shareMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    val isEraser = ed.tool == ToolType.ERASER_SEGMENT || ed.tool == ToolType.ERASER_STROKE
    Row(
        Modifier.fillMaxWidth().height(56.dp).background(Pal.toolBar).padding(horizontal = 8.dp).horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ToolBtn(Ic.SIDEBAR, app.pagesOpen) { app.pagesOpen = !app.pagesOpen }
        Spacer(Modifier.width(24.dp))
        Box {
            ToolBtn(Ic.LASSO, ed.isLassoTool, chevron = true) { if (ed.isLassoTool) lassoMenu = true else ed.selectTool(ToolType.LASSO) }
            DropdownMenu(expanded = lassoMenu, onDismissRequest = { lassoMenu = false }) {
                DropdownMenuItem(text = { Text(stringResource(R.string.tool_lasso)) }, onClick = { ed.selectTool(ToolType.LASSO); lassoMenu = false })
                DropdownMenuItem(text = { Text(stringResource(R.string.tool_lasso_rect)) }, onClick = { ed.selectTool(ToolType.LASSO_RECT); lassoMenu = false })
            }
        }
        ToolBtn(Ic.PEN, ed.tool == ToolType.PEN || ed.tool == ToolType.HIGHLIGHTER) {
            ed.selectTool(if (ed.tool == ToolType.HIGHLIGHTER) ToolType.HIGHLIGHTER else ToolType.PEN)
        }
        ToolBtn(Ic.ERASER, isEraser) { if (!isEraser) ed.selectTool(ToolType.ERASER_SEGMENT) }
        Box {
            ToolBtn(Ic.IMAGE, chevron = true) { imageMenu = true }
            DropdownMenu(expanded = imageMenu, onDismissRequest = { imageMenu = false }) {
                DropdownMenuItem(text = { Text(stringResource(R.string.image_gallery)) }, onClick = { imageMenu = false; onGallery() })
                DropdownMenuItem(text = { Text(stringResource(R.string.camera)) }, onClick = { imageMenu = false; onCamera() })
            }
        }
        Spacer(Modifier.width(24.dp))
        ToolBtn(Ic.LOCK, ed.palmConfig.writingLock) { ed.toggleWritingLock(); app.savePrefs() }
        ToolBtn(Ic.HAND, ed.tempNavActive) { ed.allowTouchNavigation() }
        ToolBtn(Ic.PAGE_ADD) { app.addPage() }
        Box {
            ToolBtn(Ic.SHARE) { shareMenu = true }
            DropdownMenu(expanded = shareMenu, onDismissRequest = { shareMenu = false }) {
                DropdownMenuItem(text = { Text(stringResource(R.string.pdf_export)) }, onClick = { shareMenu = false; onExportAll() })
                DropdownMenuItem(text = { Text(stringResource(R.string.pdf_export_page)) }, onClick = { shareMenu = false; onExportOne() })
            }
        }
        Box {
            ToolBtn(Ic.MORE) { moreMenu = true }
            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                Text(stringResource(R.string.menu_page, app.pageIndex + 1), color = Pal.dim, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                DropdownMenuItem(text = { Text(stringResource(R.string.duplicate_page)) }, onClick = { moreMenu = false; app.duplicatePage() })
                DropdownMenuItem(text = { Text(stringResource(R.string.change_template)) }, onClick = { moreMenu = false; onTemplate() })
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.go_to_page)) },
                    trailingIcon = { Text("${app.pageIndex + 1} / $pageCount", color = Pal.dim) },
                    onClick = { moreMenu = false; onGoTo() },
                )
                DropdownMenuItem(text = { Text(stringResource(R.string.fit_width)) }, onClick = { moreMenu = false; ed.fitWidth() })
                DropdownMenuItem(text = { Text(stringResource(R.string.fit_page)) }, onClick = { moreMenu = false; ed.fitPage() })
                DropdownMenuItem(text = { Text(stringResource(R.string.palm_title)) }, onClick = { moreMenu = false; onPalm() })
                DropdownMenuItem(text = { Text(stringResource(R.string.clear_page), color = red) }, onClick = { moreMenu = false; ed.clearPage() })
                DropdownMenuItem(text = { Text(stringResource(R.string.page_delete), color = red) }, onClick = { moreMenu = false; app.deletePage() })
            }
        }
    }
}

@Composable
private fun UndoRedoPill(ed: NoteState, modifier: Modifier) {
    Row(modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xCC4A4A4A)).padding(horizontal = 4.dp)) {
        IconBtn(Ic.UNDO, enabled = ed.canUndo) { ed.undo() }
        IconBtn(Ic.REDO, enabled = ed.canRedo) { ed.redo() }
    }
}

@Composable
private fun BarTool(icon: Ic, selected: Boolean, chevron: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(12.dp)).background(if (selected) barTeal else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GIcon(icon, Color.White)
        if (chevron) GIcon(Ic.CHEVRON, Color.White, box = 12.dp)
    }
}

@Composable
private fun VDivider() {
    Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(26.dp).background(Color(0x33FFFFFF)))
}

@Composable
private fun FloatingBar(app: AppModel, onAddColor: () -> Unit) {
    val ed = app.editor
    val pen = ed.tool == ToolType.PEN || ed.tool == ToolType.HIGHLIGHTER
    val eraser = ed.tool == ToolType.ERASER_SEGMENT || ed.tool == ToolType.ERASER_STROKE
    if (!pen && !eraser) return
    var popover by remember { mutableStateOf(false) }
    Surface(shape = RoundedCornerShape(22.dp), color = Pal.floating, shadowElevation = 8.dp) {
        Row(Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (pen) {
                Box {
                    BarTool(Ic.PEN, ed.tool == ToolType.PEN, chevron = ed.tool == ToolType.PEN) {
                        if (ed.tool == ToolType.PEN) popover = true else ed.selectTool(ToolType.PEN)
                    }
                    PenPopover(app, popover) { popover = false }
                }
                BarTool(Ic.HIGHLIGHTER, ed.tool == ToolType.HIGHLIGHTER) { ed.selectTool(ToolType.HIGHLIGHTER) }
                BarTool(Ic.ERASER, false) { ed.selectTool(ToolType.ERASER_SEGMENT) }
                BarTool(Ic.LASSO, false) { ed.selectTool(ToolType.LASSO) }
                VDivider()
                for (w in widthPresets) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(if (abs(ed.width - w) < 0.5f) Color(0xFF383838) else Color.Transparent)
                            .clickable { ed.width = w },
                        contentAlignment = Alignment.Center,
                    ) { Box(Modifier.width(22.dp).height((w / 2f).coerceAtLeast(2f).dp).clip(RoundedCornerShape(50)).background(Color.White)) }
                }
                VDivider()
                for (c in presetColors) {
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                            .border(if (ed.color == c) 3.dp else 1.dp, if (ed.color == c) Color.White else Color(0x66FFFFFF), CircleShape)
                            .clickable { ed.color = c },
                    )
                }
                Box(Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onAddColor), contentAlignment = Alignment.Center) {
                    GIcon(Ic.PLUS, Color.White, box = 20.dp)
                }
            } else {
                var typeMenu by remember { mutableStateOf(false) }
                Box {
                    Row(
                        Modifier.clip(RoundedCornerShape(12.dp)).clickable { typeMenu = true }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        GIcon(Ic.ERASER, Color.White)
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(if (ed.tool == ToolType.ERASER_STROKE) R.string.eraser_stroke else R.string.eraser_standard))
                        GIcon(Ic.CHEVRON, Color.White, box = 14.dp)
                    }
                    DropdownMenu(expanded = typeMenu, onDismissRequest = { typeMenu = false }) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.eraser_standard)) }, onClick = { ed.selectTool(ToolType.ERASER_SEGMENT); typeMenu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.eraser_stroke)) }, onClick = { ed.selectTool(ToolType.ERASER_STROKE); typeMenu = false })
                    }
                }
                VDivider()
                for (r in eraserSizes) {
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(if (abs(ed.eraserRadius - r) < 0.5f) Color(0xFF383838) else Color.Transparent)
                            .clickable { ed.eraserRadius = r },
                        contentAlignment = Alignment.Center,
                    ) { Box(Modifier.size((r / 2f + 8f).dp).clip(CircleShape).background(Color(0xFFDDDDDD))) }
                }
            }
        }
    }
}

@Composable
private fun PenPopover(app: AppModel, open: Boolean, onClose: () -> Unit) {
    val ed = app.editor
    var gestures by remember { mutableStateOf(false) }
    DropdownMenu(
        expanded = open,
        onDismissRequest = { gestures = false; onClose() },
        modifier = Modifier.width(320.dp).background(Pal.floating),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!gestures) {
                Text(stringResource(R.string.pen_title), fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                InkPreview(ed)
                Text(stringResource(R.string.stabilization) + " " + (ed.smoothing / 0.9f * 100f).roundToInt() + "%", color = Pal.dim)
                Slider(
                    value = ed.smoothing,
                    onValueChange = { ed.smoothing = it },
                    onValueChangeFinished = { app.savePrefs() },
                    valueRange = 0f..0.9f,
                )
                SwitchRow(stringResource(R.string.draw_and_hold), null, ed.shapeSnap) { ed.shapeSnap = it; app.savePrefs() }
                Row(Modifier.fillMaxWidth().clickable { gestures = true }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.pen_gestures), Modifier.weight(1f))
                    GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
                }
            } else {
                Row(Modifier.clickable { gestures = false }, verticalAlignment = Alignment.CenterVertically) {
                    GIcon(Ic.BACK, Color.White, box = 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.pen_gestures), fontWeight = FontWeight.SemiBold)
                }
                SwitchRow(stringResource(R.string.scribble_erase), null, ed.scribbleEnabled) { ed.scribbleEnabled = it; app.savePrefs() }
                SwitchRow(stringResource(R.string.erase_shapes), stringResource(R.string.erase_shapes_desc), ed.scribbleErasesHighlighter) {
                    ed.scribbleErasesHighlighter = it; app.savePrefs()
                }
            }
        }
    }
}

@Composable
private fun InkPreview(ed: NoteState) {
    Canvas(Modifier.fillMaxWidth().height(70.dp)) {
        val path = Path()
        val w = size.width
        val h = size.height
        var x = w * 0.08f
        path.moveTo(x, h / 2f)
        while (x <= w * 0.92f) {
            val t = (x - w * 0.08f) / (w * 0.84f)
            path.lineTo(x, h / 2f - sin(t * 6.2f) * h * 0.3f)
            x += 4f
        }
        drawPath(path, Color(ed.color), style = Stroke(width = ed.width, cap = StrokeCap.Round))
    }
}

@Composable
private fun SelectionBar(ed: NoteState) {
    val has = ed.hasSelection
    val colors = ButtonDefaults.textButtonColors(contentColor = Color.White, disabledContentColor = Color(0x55FFFFFF))
    Surface(shape = RoundedCornerShape(18.dp), color = Pal.floating, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 6.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { ed.deleteSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_delete)) }
            TextButton(onClick = { ed.copySelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_copy)) }
            TextButton(onClick = { ed.cutSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_cut)) }
            TextButton(onClick = { ed.pasteClipboard() }, enabled = ed.clipboardSize > 0, colors = colors) { Text(stringResource(R.string.sel_paste)) }
            TextButton(onClick = { ed.duplicateSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_duplicate)) }
            TextButton(onClick = { ed.scaleSelection(1.2f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_bigger)) }
            TextButton(onClick = { ed.scaleSelection(1f / 1.2f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_smaller)) }
            TextButton(onClick = { ed.rotateSelection(-15f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_rotate_left)) }
            TextButton(onClick = { ed.rotateSelection(15f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_rotate_right)) }
            TextButton(onClick = { ed.clearSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_clear)) }
        }
    }
}

// ---------------------------------------------------------------- pages panel

@Composable
private fun PagesPanel(app: AppModel, meta: NotebookMeta) {
    Column(Modifier.width(210.dp).fillMaxHeight().background(Pal.sidebar).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.pages_title), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconBtn(Ic.CLOSE, box = 36) { app.pagesOpen = false }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(meta.pages, key = { _, p -> p.id }) { i, p ->
                Column(Modifier.fillMaxWidth().clickable { app.goToPage(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    PageThumbCard(app, meta, p, selected = i == app.pageIndex)
                    Text("${i + 1}", fontSize = 13.sp, color = if (i == app.pageIndex) Pal.accent else Pal.dim)
                }
            }
        }
        Button(onClick = { app.addPage() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.page_add)) }
    }
}

@Composable
private fun PageThumbCard(app: AppModel, meta: NotebookMeta, info: PageInfo, selected: Boolean) {
    val ed = app.editor
    val fromPdf = info.pdfPage >= 0 && info.pdfW > 0f
    val (pw, ph) = if (fromPdf) Pair(PageSpec.WIDTH, PageSpec.WIDTH * info.pdfH / info.pdfW) else meta.size.dims(meta.landscape)
    val content = if (selected) remember(ed.revision) { ed.snapshot() } else remember(info.id) { app.repo.loadPage(meta.id, info.id) }
    val bg = if (fromPdf) Color.White else Color(meta.paperColor.bg)
    Canvas(
        Modifier.fillMaxWidth().aspectRatio(pw / ph)
            .border(if (selected) 3.dp else 1.dp, if (selected) Pal.accent else Color(0x44FFFFFF), RoundedCornerShape(4.dp)),
    ) {
        drawRect(bg)
        val sc = size.width / pw
        scale(sc, sc, Offset.Zero) {
            for (st in content.strokes) {
                drawPath(
                    strokePath(st.points),
                    color = Color(st.color).copy(alpha = st.opacity),
                    style = Stroke(width = st.width, cap = StrokeCap.Round),
                )
            }
        }
    }
}

// ---------------------------------------------------------------- dialogs

@Composable
private fun GoToPageDialog(app: AppModel, total: Int, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf((app.pageIndex + 1).toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.go_to_page)) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = {
            TextButton(onClick = {
                text.toIntOrNull()?.let { app.goToPage((it - 1).coerceIn(0, total - 1)) }
                onDismiss()
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun TemplateDialog(app: AppModel, meta: NotebookMeta, onDismiss: () -> Unit) {
    var paper by remember { mutableStateOf(app.editor.paper) }
    var color by remember { mutableStateOf(app.editor.paperColor) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.change_template)) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in PaperColor.entries) {
                        TextButton(onClick = { color = c }) { Text(colorLabel(c), color = if (color == c) Pal.accent else Color.White) }
                    }
                }
                Box(Modifier.height(380.dp).width(480.dp)) { PaperChoices(paper, color, meta.size, meta.landscape) { paper = it } }
            }
        },
        confirmButton = { TextButton(onClick = { app.setTemplate(paper, color); onDismiss() }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun ColorDialog(onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    var hex by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_color)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (row in swatches.chunked(8)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (c in row) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                                    .border(1.dp, Color(0x55FFFFFF), CircleShape)
                                    .clickable { onPick(c); onDismiss() },
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = hex,
                    onValueChange = { hex = it.take(7) },
                    singleLine = true,
                    label = { Text(stringResource(R.string.hex_hint)) },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = hex.trim().removePrefix("#").takeIf { it.length == 6 }?.toLongOrNull(16)
                if (v != null) { onPick((0xFF000000L or v).toInt()); onDismiss() }
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
