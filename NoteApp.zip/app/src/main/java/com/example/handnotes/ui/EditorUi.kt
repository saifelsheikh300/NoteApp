package com.example.handnotes.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.data.NotebookMeta
import com.example.handnotes.data.PageInfo
import com.example.handnotes.data.PaperColor
import com.example.handnotes.data.dims
import com.example.handnotes.engine.PageSpec
import com.example.handnotes.engine.ToolType
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.layout.fillMaxHeight
import com.example.handnotes.engine.ShapeKind


private val presetColors = listOf(0xFF000000.toInt(), 0xFF0A84FF.toInt(), 0xFFD32F2F.toInt())
private val swatches = listOf(
    0xFF000000, 0xFF424242, 0xFF9E9E9E, 0xFFFFFFFF, 0xFFD32F2F, 0xFFFF6D00, 0xFFFFC107, 0xFF2E7D32,
    0xFF00ACC1, 0xFF0A84FF, 0xFF283593, 0xFF7B1FA2, 0xFFE91E63, 0xFF6D4C41, 0xFF00C853, 0xFFFF80AB,
).map { it.toInt() }
private val widthPresets = listOf(4f, 8f, 16f)
private val eraserSizes = listOf(10f, 18f, 34f)
private val red = Color(0xFFFF6B6B)
private val barTeal = Color(0xFF2E6C7A)

@Composable
fun EditorScreen(app: AppModel) {
    val meta = app.meta ?: return
    val ed = app.editor
    var showPalm by remember { mutableStateOf(false) }
    var goTo by remember { mutableStateOf(false) }
    var template by remember { mutableStateOf(false) }
    var addColor by remember { mutableStateOf(false) }
    var saveTpl by remember { mutableStateOf(false) }
    var insertTpl by remember { mutableStateOf(false) }
    val name = app.openNotebookId?.let { app.repo.get(it)?.name } ?: ""

    val exportAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) app.exportPdf(uri, wholeNotebook = true)
    }
    val exportOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) app.exportPdf(uri, wholeNotebook = false)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) app.insertImage(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) app.insertCameraPicture()
    }

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Pal.canvasBg)) {
            val areaW = with(LocalDensity.current) { maxWidth.toPx() }
            val areaH = with(LocalDensity.current) { maxHeight.toPx() }
            DrawingSurface(ed, Modifier.fillMaxSize())

            if (app.focusMode) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(12.dp).size(44.dp).clip(CircleShape)
                        .background(Color(0x88000000)).clickable { app.focusMode = false },
                    contentAlignment = Alignment.Center,
                ) { GIcon(Ic.GRID, Color.White, box = 22.dp) }
            } else {
                BarPill(Modifier.align(Alignment.TopStart).padding(12.dp)) {
                    IconBtn(Ic.BACK) { app.closeNotebook() }
                    IconBtn(Ic.GRID, tint = if (app.pagesOpen) Pal.accent else Color.White) { app.pagesOpen = !app.pagesOpen }
                    IconBtn(Ic.UNDO, enabled = ed.canUndo) { ed.undo() }
                    IconBtn(Ic.REDO, enabled = ed.canRedo) { ed.redo() }
                }
                ToolsPill(
                    app,
                    Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
                    onGallery = { pickImage.launch(arrayOf("image/*")) },
                    onCamera = { try { takePhoto.launch(app.prepareCameraUri()) } catch (e: Exception) { /* no camera app */ } },
                )
                var moreMenu by remember { mutableStateOf(false) }
                BarPill(Modifier.align(Alignment.TopEnd).padding(12.dp)) {
                    IconBtn(Ic.PLUS) { app.addPage() }
                    IconBtn(Ic.NO_FINGER, tint = if (ed.palmConfig.stylusOnly) Pal.accent else Color.White) {
                        ed.palmConfig = ed.palmConfig.copy(stylusOnly = !ed.palmConfig.stylusOnly)
                        app.savePrefs()
                    }
                    Box {
                        IconBtn(Ic.MORE) { moreMenu = true }
                        MoreMenu(
                            app, meta.pages.size, moreMenu, { moreMenu = false },
                            onTemplate = { template = true },
                            onGoTo = { goTo = true },
                            onPalm = { showPalm = true },
                            onSaveTpl = { saveTpl = true },
                            onInsertTpl = { insertTpl = true },
                            onExportAll = { exportAll.launch("$name.pdf") },
                            onExportOne = { exportOne.launch("$name-${app.pageIndex + 1}.pdf") },
                        )
                    }
                }
                Palette(app, areaW, areaH, Modifier.align(Alignment.TopStart)) { addColor = true }
                if (ed.isLassoTool) SelectionBar(ed, Modifier.align(Alignment.BottomCenter).padding(bottom = 64.dp))
                Box(
                    Modifier.align(Alignment.BottomStart).padding(16.dp).clip(RoundedCornerShape(16.dp))
                        .background(Color(0xCC4A4A4A)).clickable { goTo = true }.padding(horizontal = 14.dp, vertical = 8.dp),
                ) { Text(stringResource(R.string.page_of, app.pageIndex + 1, meta.pages.size)) }
                ZoomPill(ed, Modifier.align(Alignment.BottomEnd).padding(16.dp))
                if (ed.palmHintVisible) PalmHint(app, Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp))
                if (app.pagesOpen) {
                    Box(Modifier.align(Alignment.CenterStart).padding(start = 12.dp, top = 76.dp, bottom = 12.dp).fillMaxHeight()) {
                        PagesPanel(app, meta)
                    }
                }
            }
        }
    }

    if (showPalm) PalmSettingsDialog(app) { showPalm = false }
    if (goTo) GoToPageDialog(app, meta.pages.size) { goTo = false }
    if (template) TemplateDialog(app, meta) { template = false }
    if (addColor) ColorDialog({ ed.color = it; app.savePrefs() }) { addColor = false }
    if (saveTpl) {
        NameDialog(
            title = stringResource(R.string.save_as_template),
            initial = name,
            onConfirm = { app.saveCurrentPageAsTemplate(it); saveTpl = false },
            onDismiss = { saveTpl = false },
        )
    }
    if (insertTpl) InsertTemplateDialog(app) { insertTpl = false }
}

@Composable
private fun BarPill(modifier: Modifier, content: @Composable RowScope.() -> Unit) {
    Surface(modifier, shape = RoundedCornerShape(12.dp), color = Pal.bar, shadowElevation = 6.dp) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, content = content)
    }
}

@Composable
private fun CenterTool(icon: Ic, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 2.dp).size(44.dp).clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0xFF4A4A4A) else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { GIcon(icon, Color.White) }
}

@Composable
private fun shapeLabel(k: ShapeKind): String = stringResource(
    when (k) {
        ShapeKind.LINE -> R.string.shape_line
        ShapeKind.ARROW -> R.string.shape_arrow
        ShapeKind.RECT -> R.string.shape_rect
        ShapeKind.ELLIPSE -> R.string.shape_ellipse
        ShapeKind.TRIANGLE -> R.string.shape_triangle
        ShapeKind.STAR -> R.string.shape_star
    },
)

/** The tool strip. Scrolls sideways with the arrows when it does not fit. */
@Composable
private fun ToolsPill(app: AppModel, modifier: Modifier, onGallery: () -> Unit, onCamera: () -> Unit) {
    val ed = app.editor
    val scroll = rememberScrollState()
    var scrollDir by remember { mutableIntStateOf(1) }
    var scrollTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(scrollTick) { if (scrollTick > 0) scroll.animateScrollBy(300f * scrollDir) }
    var penOptions by remember { mutableStateOf(false) }
    var lassoMenu by remember { mutableStateOf(false) }
    var shapeMenu by remember { mutableStateOf(false) }
    var imageMenu by remember { mutableStateOf(false) }
    BarPill(modifier) {
        IconBtn(Ic.BACK, tint = Pal.dim, box = 36) { scrollDir = -1; scrollTick++ }
        Row(Modifier.widthIn(max = 380.dp).horizontalScroll(scroll), verticalAlignment = Alignment.CenterVertically) {
            Box {
                CenterTool(Ic.PEN, ed.tool == ToolType.PEN) { if (ed.tool == ToolType.PEN) penOptions = true else ed.selectTool(ToolType.PEN) }
                PenPopover(app, penOptions) { penOptions = false }
            }
            CenterTool(Ic.HIGHLIGHTER, ed.tool == ToolType.HIGHLIGHTER) { ed.selectTool(ToolType.HIGHLIGHTER) }
            CenterTool(Ic.ERASER, ed.isEraserTool) { if (!ed.isEraserTool) ed.selectTool(ToolType.ERASER_SEGMENT) }
            Box {
                CenterTool(Ic.LASSO, ed.isLassoTool) { if (ed.isLassoTool) lassoMenu = true else ed.selectTool(ToolType.LASSO) }
                DropdownMenu(expanded = lassoMenu, onDismissRequest = { lassoMenu = false }) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.tool_lasso)) }, onClick = { ed.selectTool(ToolType.LASSO); lassoMenu = false })
                    DropdownMenuItem(text = { Text(stringResource(R.string.tool_lasso_rect)) }, onClick = { ed.selectTool(ToolType.LASSO_RECT); lassoMenu = false })
                }
            }
            Box {
                CenterTool(Ic.SHAPES, ed.tool == ToolType.SHAPE) { if (ed.tool == ToolType.SHAPE) shapeMenu = true else ed.selectTool(ToolType.SHAPE) }
                DropdownMenu(expanded = shapeMenu, onDismissRequest = { shapeMenu = false }) {
                    for (k in ShapeKind.entries) {
                        DropdownMenuItem(
                            text = { Text(shapeLabel(k)) },
                            trailingIcon = { if (ed.shapeKind == k) GIcon(Ic.CHECK, LocalContentColor.current, box = 18.dp) },
                            onClick = { ed.shapeKind = k; ed.selectTool(ToolType.SHAPE); shapeMenu = false },
                        )
                    }
                }
            }
            Box {
                CenterTool(Ic.IMAGE, false) { imageMenu = true }
                DropdownMenu(expanded = imageMenu, onDismissRequest = { imageMenu = false }) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.image_gallery)) }, onClick = { imageMenu = false; onGallery() })
                    DropdownMenuItem(text = { Text(stringResource(R.string.camera)) }, onClick = { imageMenu = false; onCamera() })
                }
            }
            CenterTool(Ic.LASER, ed.tool == ToolType.LASER) { ed.selectTool(ToolType.LASER) }
        }
        IconBtn(Ic.BACK, Modifier.rotate(180f), tint = Pal.dim, box = 36) { scrollDir = 1; scrollTick++ }
    }
}

@Composable
private fun MoreMenu(
    app: AppModel,
    pageCount: Int,
    expanded: Boolean,
    onDismiss: () -> Unit,
    onTemplate: () -> Unit,
    onGoTo: () -> Unit,
    onPalm: () -> Unit,
    onSaveTpl: () -> Unit,
    onInsertTpl: () -> Unit,
    onExportAll: () -> Unit,
    onExportOne: () -> Unit,
) {
    val ed = app.editor
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        Text(stringResource(R.string.menu_page, app.pageIndex + 1), color = Pal.dim, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        DropdownMenuItem(text = { Text(stringResource(R.string.duplicate_page)) }, onClick = { onDismiss(); app.duplicatePage() })
        DropdownMenuItem(text = { Text(stringResource(R.string.change_template)) }, onClick = { onDismiss(); onTemplate() })
        DropdownMenuItem(text = { Text(stringResource(R.string.save_as_template)) }, onClick = { onDismiss(); onSaveTpl() })
        DropdownMenuItem(text = { Text(stringResource(R.string.insert_template)) }, onClick = { onDismiss(); onInsertTpl() })
        DropdownMenuItem(
            text = { Text(stringResource(R.string.go_to_page)) },
            trailingIcon = { Text("${app.pageIndex + 1} / $pageCount", color = Pal.dim) },
            onClick = { onDismiss(); onGoTo() },
        )
        DropdownMenuItem(text = { Text(stringResource(R.string.fit_width)) }, onClick = { onDismiss(); ed.fitWidth() })
        DropdownMenuItem(text = { Text(stringResource(R.string.fit_page)) }, onClick = { onDismiss(); ed.fitPage() })
        DropdownMenuItem(text = { Text(stringResource(R.string.pdf_export)) }, onClick = { onDismiss(); onExportAll() })
        DropdownMenuItem(text = { Text(stringResource(R.string.pdf_export_page)) }, onClick = { onDismiss(); onExportOne() })
        DropdownMenuItem(text = { Text(stringResource(R.string.focus_mode)) }, onClick = { onDismiss(); app.focusMode = true })
        DropdownMenuItem(
            text = { Text(stringResource(R.string.palm_lock)) },
            trailingIcon = { if (ed.palmConfig.writingLock) GIcon(Ic.CHECK, LocalContentColor.current, box = 18.dp) },
            onClick = { ed.toggleWritingLock(); app.savePrefs() },
        )
        DropdownMenuItem(text = { Text(stringResource(R.string.palm_nav_temp)) }, onClick = { onDismiss(); ed.allowTouchNavigation() })
        DropdownMenuItem(text = { Text(stringResource(R.string.palm_title)) }, onClick = { onDismiss(); onPalm() })
        DropdownMenuItem(text = { Text(stringResource(R.string.clear_page), color = red) }, onClick = { onDismiss(); ed.clearPage() })
        DropdownMenuItem(text = { Text(stringResource(R.string.page_delete), color = red) }, onClick = { onDismiss(); app.deletePage() })
    }
}

@Composable
private fun BarTool(icon: Ic, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(if (selected) barTeal else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { GIcon(icon, Color.White) }
}

@Composable
private fun ColorDot(c: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(2.dp).size(38.dp).clip(CircleShape).background(Color(c))
            .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color(0x66FFFFFF), CircleShape)
            .clickable(onClick = onClick),
    )
}

private fun snapPalette(ed: NoteState, size: IntSize, areaW: Float, areaH: Float) {
    val cx = ed.barX + size.width / 2f
    val cy = ed.barY + size.height / 2f
    val l = cx
    val r = areaW - cx
    val t = cy
    val b = areaH - cy
    when {
        l <= r && l <= t && l <= b -> { ed.barDock = BarDock.LEFT; ed.barX = -1f }
        r <= t && r <= b -> { ed.barDock = BarDock.RIGHT; ed.barX = -1f }
        t <= b -> { ed.barDock = BarDock.TOP; ed.barY = -1f }
        else -> { ed.barDock = BarDock.BOTTOM; ed.barY = -1f }
    }
}

/**
 * Colours and thicknesses (or the eraser sizes) next to the page.
 * Press and hold anywhere on it, then drag: it follows your finger and clings to the nearest edge when you let go.
 */
@Composable
private fun Palette(app: AppModel, areaW: Float, areaH: Float, modifier: Modifier, onAddColor: () -> Unit) {
    val ed = app.editor
    val colors = ed.tool == ToolType.PEN || ed.tool == ToolType.HIGHLIGHTER || ed.tool == ToolType.SHAPE
    if (!colors && !ed.isEraserTool) return
    var size by remember { mutableStateOf(IntSize.Zero) }
    var wasVertical by remember { mutableStateOf(true) }
    val dock = ed.barDock
    LaunchedEffect(dock) { if (dock != BarDock.FREE) wasVertical = dock == BarDock.LEFT || dock == BarDock.RIGHT }
    val vertical = when (dock) {
        BarDock.LEFT, BarDock.RIGHT -> true
        BarDock.TOP, BarDock.BOTTOM -> false
        BarDock.FREE -> wasVertical
    }
    val density = LocalDensity.current
    val margin = with(density) { 12.dp.toPx() }
    val topSafe = with(density) { 76.dp.toPx() }
    val bottomSafe = with(density) { 72.dp.toPx() }
    val bw = size.width.toFloat()
    val bh = size.height.toFloat()
    val x = when (dock) {
        BarDock.LEFT -> margin
        BarDock.RIGHT -> areaW - bw - margin
        BarDock.TOP, BarDock.BOTTOM -> if (ed.barX >= 0f) ed.barX else (areaW - bw) / 2f
        BarDock.FREE -> ed.barX
    }.coerceIn(0f, maxOf(0f, areaW - bw))
    val y = when (dock) {
        BarDock.TOP -> topSafe
        BarDock.BOTTOM -> areaH - bh - bottomSafe
        BarDock.LEFT, BarDock.RIGHT -> if (ed.barY >= 0f) ed.barY else (areaH - bh) / 2f
        BarDock.FREE -> ed.barY
    }.coerceIn(0f, maxOf(0f, areaH - bh))
    val curX by rememberUpdatedState(x)
    val curY by rememberUpdatedState(y)
    val curW by rememberUpdatedState(areaW)
    val curH by rememberUpdatedState(areaH)

    Surface(
        modifier.offset { IntOffset(x.roundToInt(), y.roundToInt()) }.onSizeChanged { size = it }
            .pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { ed.barX = curX; ed.barY = curY; ed.barDock = BarDock.FREE },
                    onDragEnd = { snapPalette(ed, size, curW, curH); app.savePrefs() },
                    onDragCancel = { snapPalette(ed, size, curW, curH); app.savePrefs() },
                ) { change, drag ->
                    change.consume()
                    ed.barX += drag.x
                    ed.barY += drag.y
                }
            },
        shape = RoundedCornerShape(26.dp),
        color = Pal.bar,
        shadowElevation = 8.dp,
    ) {
        Box(Modifier.padding(6.dp)) {
            BarLayout(vertical) {
                if (colors) {
                    for (c in presetColors) ColorDot(c, ed.color == c) { ed.color = c; app.savePrefs() }
                    if (ed.color !in presetColors) ColorDot(ed.color, true) { }
                    Box(Modifier.size(38.dp).clip(CircleShape).border(1.dp, Color(0x88FFFFFF), CircleShape).clickable(onClick = onAddColor), contentAlignment = Alignment.Center) {
                        GIcon(Ic.PLUS, Color.White, box = 20.dp)
                    }
                    BarDivider()
                    for (w in widthPresets) {
                        val on = abs(ed.width - w) < 0.5f
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(if (on) Color(0xFF3A3A3A) else Color.Transparent)
                                .border(if (on) 2.dp else 0.dp, if (on) Pal.accent else Color.Transparent, CircleShape)
                                .clickable { ed.width = w; app.savePrefs() },
                            contentAlignment = Alignment.Center,
                        ) { Box(Modifier.width(28.dp).height((w * 0.9f).coerceIn(3f, 22f).dp).clip(RoundedCornerShape(50)).background(Color.White)) }
                    }
                } else {
                    for ((tool, res) in listOf(ToolType.ERASER_SEGMENT to R.string.eraser_standard, ToolType.ERASER_STROKE to R.string.eraser_stroke)) {
                        Box(
                            Modifier.clip(RoundedCornerShape(12.dp)).background(if (ed.tool == tool) barTeal else Color.Transparent)
                                .clickable { ed.selectTool(tool) }.padding(horizontal = 10.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(stringResource(res), fontSize = 12.sp) }
                    }
                    BarTool(Ic.HIGHLIGHTER, ed.eraseHighlighterOnly) { ed.eraseHighlighterOnly = !ed.eraseHighlighterOnly; app.savePrefs() }
                    BarDivider()
                    for (r in eraserSizes) {
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(if (abs(ed.eraserRadius - r) < 0.5f) Color(0xFF3A3A3A) else Color.Transparent)
                                .clickable { ed.eraserRadius = r; app.savePrefs() },
                            contentAlignment = Alignment.Center,
                        ) { Box(Modifier.size((r / 2f + 8f).dp).clip(CircleShape).background(Color(0xFFDDDDDD))) }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsertTemplateDialog(app: AppModel, onDismiss: () -> Unit) {
    val list = app.templateList()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.insert_template)) },
        text = {
            if (list.isEmpty()) {
                Text(stringResource(R.string.templates_empty))
            } else {
                LazyColumn {
                    items(list, key = { it.id }) { t ->
                        TextButton(onClick = { app.insertTemplatePage(t); onDismiss() }) { Text(t.name) }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

private val LocalBarVertical = compositionLocalOf { false }

@Composable
private fun BarDivider() {
    if (LocalBarVertical.current) Box(Modifier.padding(vertical = 4.dp).width(26.dp).height(1.dp).background(Color(0x33FFFFFF)))
    else Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(26.dp).background(Color(0x33FFFFFF)))
}

@Composable
private fun BarLayout(vertical: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalBarVertical provides vertical) {
        if (vertical) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) { content() }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) { content() }
        }
    }
}

@Composable
private fun NavRow(label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
    }
}

@Composable
private fun BackRow(label: String, onClick: () -> Unit) {
    Row(Modifier.clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        GIcon(Ic.BACK, Color.White, box = 20.dp)
        Spacer(Modifier.width(8.dp))
        Text(label, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PenPopover(app: AppModel, open: Boolean, onClose: () -> Unit) {
    val ed = app.editor
    var page by remember { mutableIntStateOf(0) }
    DropdownMenu(
        expanded = open,
        onDismissRequest = { page = 0; onClose() },
        modifier = Modifier.width(320.dp).background(Pal.floating),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (page) {
                0 -> {
                    Text(stringResource(R.string.pen_title), fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    InkPreview(ed)
                    Text(stringResource(R.string.thickness) + " " + ed.width.roundToInt(), color = Pal.dim)
                    Slider(
                        value = ed.width,
                        onValueChange = { ed.width = it },
                        onValueChangeFinished = { app.savePrefs() },
                        valueRange = 1f..40f,
                    )
                    Text(stringResource(R.string.stabilization) + " " + (ed.smoothing / 0.9f * 100f).roundToInt() + "%", color = Pal.dim)
                    Slider(
                        value = ed.smoothing,
                        onValueChange = { ed.smoothing = it },
                        onValueChangeFinished = { app.savePrefs() },
                        valueRange = 0f..0.9f,
                    )
                    SwitchRow(stringResource(R.string.draw_and_hold), null, ed.shapeSnap) { ed.shapeSnap = it; app.savePrefs() }
                    NavRow(stringResource(R.string.pen_gestures)) { page = 1 }
                    NavRow(stringResource(R.string.pen_feel)) { page = 2 }
                }
                1 -> {
                    BackRow(stringResource(R.string.pen_gestures)) { page = 0 }
                    SwitchRow(stringResource(R.string.scribble_erase), null, ed.scribbleEnabled) { ed.scribbleEnabled = it; app.savePrefs() }
                    SwitchRow(stringResource(R.string.erase_shapes), stringResource(R.string.erase_shapes_desc), ed.scribbleErasesHighlighter) {
                        ed.scribbleErasesHighlighter = it; app.savePrefs()
                    }
                }
                else -> {
                    BackRow(stringResource(R.string.pen_feel)) { page = 0 }
                    Text(stringResource(R.string.ink_offset_desc), color = Pal.dim, fontSize = 12.sp)
                    Text(stringResource(R.string.ink_offset_x) + " " + ed.inkOffsetX.roundToInt() + " px", color = Pal.dim)
                    Slider(value = ed.inkOffsetX, onValueChange = { ed.inkOffsetX = it }, onValueChangeFinished = { app.savePrefs() }, valueRange = -40f..40f)
                    Text(stringResource(R.string.ink_offset_y) + " " + ed.inkOffsetY.roundToInt() + " px", color = Pal.dim)
                    Slider(value = ed.inkOffsetY, onValueChange = { ed.inkOffsetY = it }, onValueChangeFinished = { app.savePrefs() }, valueRange = -40f..40f)
                    SwitchRow(stringResource(R.string.prediction), stringResource(R.string.prediction_desc), ed.prediction) { ed.prediction = it; app.savePrefs() }
                    TextButton(onClick = { ed.inkOffsetX = 0f; ed.inkOffsetY = 0f; app.savePrefs() }) { Text(stringResource(R.string.reset_offsets)) }
                }
            }
        }
    }
}

@Composable
private fun ZoomPill(ed: NoteState, modifier: Modifier) {
    Row(modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xCC4A4A4A)), verticalAlignment = Alignment.CenterVertically) {
        IconBtn(Ic.MINUS, box = 40) { ed.zoomBy(0.8f) }
        Text("${ed.zoomPercent}%", Modifier.clickable { ed.fitWidth() }.padding(horizontal = 6.dp))
        IconBtn(Ic.PLUS, box = 40) { ed.zoomBy(1.25f) }
    }
}

@Composable
private fun PalmHint(app: AppModel, modifier: Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xEE4A4A4A)).padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(stringResource(R.string.palm_hint))
        TextButton(onClick = {
            app.editor.palmConfig = app.editor.palmConfig.copy(enabled = false)
            app.editor.palmHintVisible = false
            app.savePrefs()
        }) { Text(stringResource(R.string.palm_hint_off)) }
    }
}

@Composable
private fun InkPreview(ed: NoteState) {
    Canvas(Modifier.fillMaxWidth().height(70.dp)) {
        val path = Path()
        val w = size.width
        val h = size.height
        var x = w * 0.08f
        path.moveTo(x, h / 2f)
        while (x <= w * 0.92f) {
            val t = (x - w * 0.08f) / (w * 0.84f)
            path.lineTo(x, h / 2f - sin(t * 6.2f) * h * 0.3f)
            x += 4f
        }
        drawPath(path, Color(ed.color), style = Stroke(width = ed.width, cap = StrokeCap.Round))
    }
}

@Composable
private fun SelectionBar(ed: NoteState, modifier: Modifier = Modifier) {
    val has = ed.hasSelection
    val colors = ButtonDefaults.textButtonColors(contentColor = Color.White, disabledContentColor = Color(0x55FFFFFF))
    Surface(modifier, shape = RoundedCornerShape(18.dp), color = Pal.floating, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 6.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { ed.deleteSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_delete)) }
            TextButton(onClick = { ed.copySelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_copy)) }
            TextButton(onClick = { ed.cutSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_cut)) }
            TextButton(onClick = { ed.pasteClipboard() }, enabled = ed.clipboardSize > 0, colors = colors) { Text(stringResource(R.string.sel_paste)) }
            TextButton(onClick = { ed.duplicateSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_duplicate)) }
            TextButton(onClick = { ed.scaleSelection(1.2f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_bigger)) }
            TextButton(onClick = { ed.scaleSelection(1f / 1.2f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_smaller)) }
            TextButton(onClick = { ed.rotateSelection(-15f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_rotate_left)) }
            TextButton(onClick = { ed.rotateSelection(15f) }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_rotate_right)) }
            TextButton(onClick = { ed.clearSelection() }, enabled = has, colors = colors) { Text(stringResource(R.string.sel_clear)) }
        }
    }
}

// ---------------------------------------------------------------- pages panel

@Composable
private fun PagesPanel(app: AppModel, meta: NotebookMeta) {
    Column(Modifier.width(210.dp).fillMaxHeight().background(Pal.sidebar).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.pages_title), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconBtn(Ic.CLOSE, box = 36) { app.pagesOpen = false }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(meta.pages, key = { _, p -> p.id }) { i, p ->
                Column(Modifier.fillMaxWidth().clickable { app.goToPage(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    PageThumbCard(app, meta, p, selected = i == app.pageIndex)
                    Text("${i + 1}", fontSize = 13.sp, color = if (i == app.pageIndex) Pal.accent else Pal.dim)
                }
            }
        }
        Button(onClick = { app.addPage() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.page_add)) }
    }
}

@Composable
private fun PageThumbCard(app: AppModel, meta: NotebookMeta, info: PageInfo, selected: Boolean) {
    val ed = app.editor
    val fromPdf = info.pdfPage >= 0 && info.pdfW > 0f
    val (pw, ph) = if (fromPdf) Pair(PageSpec.WIDTH, PageSpec.WIDTH * info.pdfH / info.pdfW) else meta.size.dims(meta.landscape)
    val content = if (selected) remember(ed.revision) { ed.snapshot() } else remember(info.id) { app.repo.loadPage(meta.id, info.id) }
    val bg = if (fromPdf) Color.White else Color(meta.paperColor.bg)
    Canvas(
        Modifier.fillMaxWidth().aspectRatio(pw / ph)
            .border(if (selected) 3.dp else 1.dp, if (selected) Pal.accent else Color(0x44FFFFFF), RoundedCornerShape(4.dp)),
    ) {
        drawRect(bg)
        val sc = size.width / pw
        scale(sc, sc, Offset.Zero) {
            for (st in content.strokes) {
                drawPath(
                    strokePath(st.points),
                    color = Color(st.color).copy(alpha = st.opacity),
                    style = Stroke(width = st.width, cap = StrokeCap.Round),
                )
            }
        }
    }
}

// ---------------------------------------------------------------- dialogs

@Composable
private fun GoToPageDialog(app: AppModel, total: Int, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf((app.pageIndex + 1).toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.go_to_page)) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = {
            TextButton(onClick = {
                text.toIntOrNull()?.let { app.goToPage((it - 1).coerceIn(0, total - 1)) }
                onDismiss()
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun TemplateDialog(app: AppModel, meta: NotebookMeta, onDismiss: () -> Unit) {
    var paper by remember { mutableStateOf(app.editor.paper) }
    var color by remember { mutableStateOf(app.editor.paperColor) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.change_template)) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in PaperColor.entries) {
                        TextButton(onClick = { color = c }) { Text(colorLabel(c), color = if (color == c) Pal.accent else Color.White) }
                    }
                }
                Box(Modifier.height(380.dp).width(480.dp)) { PaperChoices(paper, color, meta.size, meta.landscape) { paper = it } }
            }
        },
        confirmButton = { TextButton(onClick = { app.setTemplate(paper, color); onDismiss() }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun ColorDialog(onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    var hex by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_color)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (row in swatches.chunked(8)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (c in row) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                                    .border(1.dp, Color(0x55FFFFFF), CircleShape)
                                    .clickable { onPick(c); onDismiss() },
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = hex,
                    onValueChange = { hex = it.take(7) },
                    singleLine = true,
                    label = { Text(stringResource(R.string.hex_hint)) },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = hex.trim().removePrefix("#").takeIf { it.length == 6 }?.toLongOrNull(16)
                if (v != null) { onPick((0xFF000000L or v).toInt()); onDismiss() }
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
