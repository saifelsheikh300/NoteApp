package com.example.handnotes.data

import com.example.handnotes.engine.PageContent
import java.io.File
import java.util.UUID
import org.json.JSONObject

/**
 * A personal template made from a page: its paper style and its content (ink, pictures).
 * Saved one file per template, with the same crash-safe writes as notebooks.
 */
data class PageTemplate(
    val id: String,
    val name: String,
    val paper: PaperType,
    val paperColor: PaperColor,
    val size: PageSize,
    val landscape: Boolean,
    val rtl: Boolean,
    val content: PageContent,
)

class TemplateStore(private val dir: File) {
    private fun file(id: String) = File(dir, "$id.json")

    private fun toJson(t: PageTemplate): String = JSONObject()
        .put("formatVersion", NoteFormat.VERSION)
        .put("id", t.id)
        .put("name", t.name)
        .put("paper", t.paper.name)
        .put("paperColor", t.paperColor.name)
        .put("size", t.size.name)
        .put("landscape", t.landscape)
        .put("rtl", t.rtl)
        .put("page", NoteFormat.pageToJson(t.id, t.content))
        .toString()

    private fun fromJson(text: String): PageTemplate {
        val o = JSONObject(text)
        return PageTemplate(
            id = o.getString("id"),
            name = o.optString("name", ""),
            paper = try { PaperType.valueOf(o.optString("paper", "RULED")) } catch (e: IllegalArgumentException) { PaperType.RULED },
            paperColor = try { PaperColor.valueOf(o.optString("paperColor", "WHITE")) } catch (e: IllegalArgumentException) { PaperColor.WHITE },
            size = try { PageSize.valueOf(o.optString("size", "A4")) } catch (e: IllegalArgumentException) { PageSize.A4 },
            landscape = o.optBoolean("landscape", false),
            rtl = o.optBoolean("rtl", false),
            content = NoteFormat.pageFromJson(o.getString("page")),
        )
    }

    fun list(): List<PageTemplate> {
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") } ?: return emptyList()
        return files.mapNotNull { f ->
            val text = SafeFile.read(f) ?: return@mapNotNull null
            try { fromJson(text) } catch (e: Exception) { null }
        }.sortedBy { it.name.lowercase() }
    }

    fun get(id: String): PageTemplate? =
        SafeFile.read(file(id))?.let { try { fromJson(it) } catch (e: Exception) { null } }

    fun save(t: PageTemplate) { SafeFile.write(file(t.id), toJson(t)) }

    fun create(name: String, base: PageTemplate): PageTemplate {
        val t = base.copy(id = UUID.randomUUID().toString(), name = name.trim().ifEmpty { "Template" })
        save(t)
        return t
    }

    fun rename(id: String, name: String) {
        val t = get(id) ?: return
        save(t.copy(name = name.trim().ifEmpty { t.name }))
    }

    fun duplicate(id: String): PageTemplate? {
        val t = get(id) ?: return null
        return create(t.name + " (copy)", t)
    }

    fun delete(id: String) {
        val f = file(id)
        f.delete(); File(f.path + ".tmp").delete(); File(f.path + ".bak").delete()
    }
}
