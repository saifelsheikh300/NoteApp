package com.example.handnotes.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import com.example.handnotes.R

/** One notebook cover. [band] covers have the coloured band near the right edge, the others have a binding strip on the left. */
data class CoverStyle(
    val id: String,
    val label: Int,
    val body: Color,
    val strip: Color,
    val band: Boolean = false,
    val dark: Boolean = false,
)

object Covers {
    val simple = listOf(
        CoverStyle("simple", R.string.cover_simple, Color(0xFFB3A38B), Color(0xFFF4F4F2)),
        CoverStyle("simple_yellow", R.string.cover_simple_yellow, Color(0xFFB3A38B), Color(0xFFF2EC4E)),
        CoverStyle("simple_dark", R.string.cover_simple_dark, Color(0xFF363C48), Color(0xFF0F0F10), dark = true),
        CoverStyle("simple_blue", R.string.cover_simple_blue, Color(0xFFB3A38B), Color(0xFF74A9F5)),
    )
    val solid = listOf(
        CoverStyle("solid_blue", R.string.cover_solid_blue, Color(0xFFA2C8F1), Color(0xFF1B7BFF), band = true),
        CoverStyle("solid_navy", R.string.cover_solid_navy, Color(0xFF223B70), Color(0xFF4D86E8), band = true, dark = true),
        CoverStyle("solid_green", R.string.cover_solid_green, Color(0xFF8FC6AA), Color(0xFFE4586B), band = true),
        CoverStyle("solid_pink", R.string.cover_solid_pink, Color(0xFFF1B7C0), Color(0xFFD94A64), band = true),
        CoverStyle("solid_red", R.string.cover_solid_red, Color(0xFFD9606F), Color(0xFF5B5B5B), band = true),
    )
    val all = simple + solid
    fun byId(id: String): CoverStyle? = all.firstOrNull { it.id == id }
}

/** Notebook cover drawn in code. An unknown id or "none" draws a plain page. */
@Composable
fun CoverArt(coverId: String, modifier: Modifier = Modifier, paper: Color = Color.White) {
    val st = Covers.byId(coverId)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (st == null) {
            drawRoundRect(paper, cornerRadius = CornerRadius(6.dp.toPx()))
            var y = h * 0.18f
            while (y < h * 0.95f) {
                drawLine(Color(0x22000000), Offset(w * 0.08f, y), Offset(w * 0.92f, y), 1.dp.toPx())
                y += h * 0.09f
            }
            return@Canvas
        }
        drawRoundRect(st.body, cornerRadius = CornerRadius(10.dp.toPx()))
        if (st.band) drawRect(st.strip, Offset(w * 0.80f, 0f), Size(w * 0.07f, h))
        else drawRect(st.strip, Offset.Zero, Size(w * 0.075f, h))
        val ink = if (st.dark) Color(0x66FFFFFF) else Color(0x66000000)
        drawLine(ink, Offset(w * 0.18f, h * 0.27f), Offset(w * (if (st.band) 0.70f else 0.86f), h * 0.27f), 1.2.dp.toPx())
        for (k in 0..2) {
            val y = h * (0.80f + k * 0.04f)
            drawLine(ink, Offset(w * 0.60f, y), Offset(w * 0.78f, y), 1.dp.toPx())
        }
    }
}

@Composable
fun FolderArt(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val back = Path().apply {
            moveTo(0f, h * 0.16f); lineTo(w * 0.38f, h * 0.16f); lineTo(w * 0.47f, h * 0.30f)
            lineTo(w, h * 0.30f); lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(back, Color(0xFF2FA3C4))
        drawRoundRect(Pal.teal, Offset(0f, h * 0.38f), Size(w, h * 0.62f), CornerRadius(8.dp.toPx()))
    }
}
