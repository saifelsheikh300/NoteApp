package com.example.handnotes.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.example.handnotes.data.PaperType
import com.example.handnotes.engine.Pt
import com.example.handnotes.engine.ToolType
import kotlin.math.roundToInt

private const val HOLD_MS = 600L
private const val HOLD_SLOP_PX = 12f

/** Screen position -> page coordinates. Pressure falls back to 1 for fingers and capacitive styluses. */
private fun NoteState.toPagePt(c: PointerInputChange): Pt =
    Pt((c.position.x - offsetX) / scale, (c.position.y - offsetY) / scale, c.uptimeMillis, if (c.pressure > 0f) c.pressure else 1f)

@Composable
fun DrawingSurface(state: NoteState, modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .background(Color(0xFFCFD8DC))
            .clipToBounds()
            .onSizeChanged { state.onViewport(it.width.toFloat(), it.height.toFloat()) }
            .pointerInput(state) {
                // One pointer writes (stylus, capacitive stylus or finger are treated the same).
                // A second pointer cancels the stroke and switches to pan + pinch-zoom until all fingers lift.
                // Holding still for a moment snaps the stroke to a clean shape.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startPt = state.toPagePt(down)
                    state.beginLive(startPt)
                    state.startDragIfHit(startPt)
                    var multi = false
                    var holdDone = false
                    var anchor = down.position
                    var anchorTime = down.uptimeMillis
                    var lastTime = down.uptimeMillis
                    while (true) {
                        val event = if (state.canSnap && !holdDone && !multi) {
                            withTimeoutOrNull((HOLD_MS - (lastTime - anchorTime)).coerceAtLeast(1L)) { awaitPointerEvent() }
                        } else {
                            awaitPointerEvent()
                        }
                        if (event == null) {
                            holdDone = true
                            state.snapToShape()
                            continue
                        }
                        val pressed = event.changes.count { it.pressed }
                        if (pressed == 0) break
                        if (pressed > 1 || multi) {
                            if (!multi) { multi = true; state.cancelLive() }
                            if (pressed > 1) {
                                state.transform(event.calculateCentroid(useCurrent = false), event.calculatePan(), event.calculateZoom())
                            }
                            event.changes.forEach { it.consume() }
                            continue
                        }
                        val change = event.changes.first { it.pressed }
                        lastTime = change.uptimeMillis
                        if (state.dragging) {
                            state.dragTo(state.toPagePt(change))
                            change.consume()
                            continue
                        }
                        if (!state.isSnapped) {
                            if ((change.position - anchor).getDistance() > HOLD_SLOP_PX) {
                                anchor = change.position
                                anchorTime = change.uptimeMillis
                                holdDone = false
                            } else if (!holdDone && state.canSnap && lastTime - anchorTime >= HOLD_MS) {
                                holdDone = true
                                state.snapToShape()
                            }
                            if (!state.isSnapped) state.extendLive(state.toPagePt(change))
                        }
                        change.consume()
                    }
                    if (!multi) state.finishLive()
                }
            },
    ) {
        @Suppress("UNUSED_VARIABLE")
        val redrawTrigger = state.revision + state.liveTick

        val s = state.scale
        val ox = state.offsetX
        val oy = state.offsetY
        withTransform({
            translate(ox, oy)
            scale(s, s, Offset.Zero)
        }) {
            val pw = state.pageW
            val ph = state.pageH
            drawRect(Color.White, size = Size(pw, ph))
            clipRect(0f, 0f, pw, ph) {
                val img = state.pdfImage
                if (img != null) {
                    drawImage(
                        img,
                        srcOffset = IntOffset.Zero,
                        srcSize = IntSize(img.width, img.height),
                        dstOffset = IntOffset.Zero,
                        dstSize = IntSize(pw.toInt(), ph.toInt()),
                        filterQuality = FilterQuality.Medium,
                    )
                } else if (!state.pdfPage) {
                    drawPaper(state.paper, pw, ph)
                }
                for (im in state.page.images) {
                    val bmp = state.imageCache[im.file] ?: continue
                    rotate(im.rotationDeg, Offset(im.cx, im.cy)) {
                        drawImage(
                            bmp,
                            srcOffset = IntOffset.Zero,
                            srcSize = IntSize(bmp.width, bmp.height),
                            dstOffset = IntOffset((im.cx - im.w / 2f).roundToInt(), (im.cy - im.h / 2f).roundToInt()),
                            dstSize = IntSize(im.w.roundToInt(), im.h.roundToInt()),
                            filterQuality = FilterQuality.Medium,
                        )
                    }
                }
                for (st in state.page.strokes) {
                    drawPath(
                        strokePath(st.points),
                        color = Color(st.color).copy(alpha = st.opacity),
                        style = Stroke(width = st.width, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                }
                drawLive(state)
            }
            drawSelection(state, s)
        }
    }
}

private val selectionColor = Color(0xFF1976D2)

private fun DrawScope.drawSelection(state: NoteState, viewScale: Float) {
    val b = state.selectionBounds() ?: return
    val dash = PathEffect.dashPathEffect(floatArrayOf(12f / viewScale, 8f / viewScale))
    drawRect(
        selectionColor,
        topLeft = Offset(b.left - 6f, b.top - 6f),
        size = Size(b.width + 12f, b.height + 12f),
        style = Stroke(width = 2f / viewScale, pathEffect = dash),
    )
}

private fun DrawScope.drawLive(state: NoteState) {
    if (state.live.isEmpty()) return
    if (state.isLassoTool) {
        val dash = PathEffect.dashPathEffect(floatArrayOf(12f / state.scale, 8f / state.scale))
        val style = Stroke(width = 2f / state.scale, pathEffect = dash)
        if (state.tool == ToolType.LASSO_RECT) {
            val a = state.live.first()
            val e = state.live.last()
            drawRect(
                selectionColor,
                topLeft = Offset(minOf(a.x, e.x), minOf(a.y, e.y)),
                size = Size(kotlin.math.abs(e.x - a.x), kotlin.math.abs(e.y - a.y)),
                style = style,
            )
        } else {
            drawPath(strokePath(state.live), color = selectionColor, style = style)
        }
        return
    }
    val isEraser = state.tool == ToolType.ERASER_STROKE || state.tool == ToolType.ERASER_SEGMENT
    val highlighter = state.tool == ToolType.HIGHLIGHTER
    val color = if (isEraser) Color.Gray.copy(alpha = 0.4f)
    else Color(state.color).copy(alpha = if (highlighter) 0.35f else 1f)
    val w = when {
        isEraser -> state.eraserRadius * 2f
        highlighter -> state.width * 3f
        else -> state.width
    }
    drawPath(
        strokePath(state.live),
        color = color,
        style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
}

/** Smooth path through the points using midpoint quadratic curves. */
private fun strokePath(p: List<Pt>): Path {
    val path = Path()
    if (p.isEmpty()) return path
    path.moveTo(p[0].x, p[0].y)
    if (p.size == 1) {
        path.lineTo(p[0].x + 0.01f, p[0].y)
        return path
    }
    for (i in 1 until p.size) {
        val a = p[i - 1]
        val b = p[i]
        path.quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
    }
    path.lineTo(p.last().x, p.last().y)
    return path
}

private const val PAPER_GAP = 44f
private val paperLineColor = Color(0xFFB0BEC5)

/** Page template drawn behind the ink (in page units). Not part of the strokes, so erasing never touches it. */
private fun DrawScope.drawPaper(type: PaperType, w: Float, h: Float) {
    if (type == PaperType.RULED || type == PaperType.GRID) {
        var y = PAPER_GAP
        while (y < h) {
            drawLine(paperLineColor, Offset(0f, y), Offset(w, y), 1f)
            y += PAPER_GAP
        }
    }
    if (type == PaperType.GRID) {
        var x = PAPER_GAP
        while (x < w) {
            drawLine(paperLineColor, Offset(x, 0f), Offset(x, h), 1f)
            x += PAPER_GAP
        }
    }
    if (type == PaperType.DOTTED) {
        var y = PAPER_GAP
        while (y < h) {
            var x = PAPER_GAP
            while (x < w) {
                drawCircle(paperLineColor, 2f, Offset(x, y))
                x += PAPER_GAP
            }
            y += PAPER_GAP
        }
    }
}
