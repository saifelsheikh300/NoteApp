package com.example.handnotes.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.example.handnotes.data.PaperColor
import com.example.handnotes.data.PaperPattern
import com.example.handnotes.engine.Pt
import com.example.handnotes.engine.ToolType
import kotlin.math.roundToInt

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun DrawingSurface(state: NoteState, modifier: Modifier = Modifier) {
    val controller = remember(state) { TouchController(state) }
    controller.density = LocalDensity.current.density
    controller.xdpi = LocalContext.current.resources.displayMetrics.xdpi
    val geo = remember(state.paper, state.pageW, state.pageH) { PaperPattern.build(state.paper, state.pageW, state.pageH) }
    val dots = remember(geo) { geo.dots.map { Offset(it.first, it.second) } }

    Canvas(
        modifier = modifier
            .background(Color(0xFF1E1E1E))
            .clipToBounds()
            .onSizeChanged { state.onViewport(it.width.toFloat(), it.height.toFloat()) }
            // Raw touch events: tool type, touch size and every batched sample, for palm rejection and faithful ink.
            .pointerInteropFilter { controller.onTouch(it) },
    ) {
        @Suppress("UNUSED_VARIABLE")
        val redrawTrigger = state.revision + state.liveTick

        val s = state.scale
        val ox = state.offsetX
        val oy = state.offsetY
        withTransform({
            translate(ox, oy)
            scale(s, s, Offset.Zero)
        }) {
            val pw = state.pageW
            val ph = state.pageH
            drawRect(if (state.pdfPage) Color.White else Color(state.paperColor.bg), size = Size(pw, ph))
            clipRect(0f, 0f, pw, ph) {
                val img = state.pdfImage
                if (img != null) {
                    drawImage(
                        img,
                        srcOffset = IntOffset.Zero,
                        srcSize = IntSize(img.width, img.height),
                        dstOffset = IntOffset.Zero,
                        dstSize = IntSize(pw.toInt(), ph.toInt()),
                        filterQuality = FilterQuality.Medium,
                    )
                } else if (!state.pdfPage) {
                    drawPaperShape(geo, dots, state.paperColor)
                }
                for (im in state.page.images) {
                    val bmp = state.imageCache[im.file] ?: continue
                    rotate(im.rotationDeg, Offset(im.cx, im.cy)) {
                        drawImage(
                            bmp,
                            srcOffset = IntOffset.Zero,
                            srcSize = IntSize(bmp.width, bmp.height),
                            dstOffset = IntOffset((im.cx - im.w / 2f).roundToInt(), (im.cy - im.h / 2f).roundToInt()),
                            dstSize = IntSize(im.w.roundToInt(), im.h.roundToInt()),
                            filterQuality = FilterQuality.Medium,
                        )
                    }
                }
                for (st in state.page.strokes) {
                    drawPath(
                        strokePath(st.points),
                        color = Color(st.color).copy(alpha = st.opacity),
                        style = Stroke(width = st.width, cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                }
                drawLive(state)
            }
            drawSelection(state, s)
        }
    }
}

private val selectionColor = Color(0xFF1976D2)

private fun DrawScope.drawSelection(state: NoteState, viewScale: Float) {
    val b = state.selectionBounds() ?: return
    val dash = PathEffect.dashPathEffect(floatArrayOf(12f / viewScale, 8f / viewScale))
    drawRect(
        selectionColor,
        topLeft = Offset(b.left - 6f, b.top - 6f),
        size = Size(b.width + 12f, b.height + 12f),
        style = Stroke(width = 2f / viewScale, pathEffect = dash),
    )
}

private fun DrawScope.drawLive(state: NoteState) {
    if (state.live.isEmpty()) return
    if (state.isLassoTool) {
        val dash = PathEffect.dashPathEffect(floatArrayOf(12f / state.scale, 8f / state.scale))
        val style = Stroke(width = 2f / state.scale, pathEffect = dash)
        if (state.tool == ToolType.LASSO_RECT) {
            val a = state.live.first()
            val e = state.live.last()
            drawRect(
                selectionColor,
                topLeft = Offset(minOf(a.x, e.x), minOf(a.y, e.y)),
                size = Size(kotlin.math.abs(e.x - a.x), kotlin.math.abs(e.y - a.y)),
                style = style,
            )
        } else {
            drawPath(strokePath(state.live), color = selectionColor, style = style)
        }
        return
    }
    val isEraser = state.tool == ToolType.ERASER_STROKE || state.tool == ToolType.ERASER_SEGMENT
    val highlighter = state.tool == ToolType.HIGHLIGHTER
    val color = if (isEraser) Color.Gray.copy(alpha = 0.4f)
    else Color(state.color).copy(alpha = if (highlighter) 0.35f else 1f)
    val w = when {
        isEraser -> state.eraserRadius * 2f
        highlighter -> state.width * 3f
        else -> state.width
    }
    drawPath(
        strokePath(state.live),
        color = color,
        style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
}

/** Smooth path through the points using midpoint quadratic curves. */
internal fun strokePath(p: List<Pt>): Path {
    val path = Path()
    if (p.isEmpty()) return path
    path.moveTo(p[0].x, p[0].y)
    if (p.size == 1) {
        path.lineTo(p[0].x + 0.01f, p[0].y)
        return path
    }
    for (i in 1 until p.size) {
        val a = p[i - 1]
        val b = p[i]
        path.quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
    }
    path.lineTo(p.last().x, p.last().y)
    return path
}

/** Page template in page units. Not part of the strokes, so erasing never touches it. */
private fun DrawScope.drawPaperShape(shape: PaperPattern.Shape, dots: List<Offset>, c: PaperColor) {
    val line = Color(c.line)
    val strong = Color(c.strong)
    for (s in shape.segments) {
        drawLine(if (s.strong) strong else line, Offset(s.x1, s.y1), Offset(s.x2, s.y2), if (s.strong) 2f else 1.5f)
    }
    if (dots.isNotEmpty()) drawPoints(dots, PointMode.Points, strong, 5f, StrokeCap.Round)
}
