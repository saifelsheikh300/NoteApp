package com.example.handnotes.data

enum class NodeType { FOLDER, NOTEBOOK }
enum class PaperType { BLANK, RULED, GRID, DOTTED }

/** A folder or a notebook in the library tree. Unlimited depth, unlimited count. */
data class LibraryNode(
    val id: String,
    val parentId: String?,
    val name: String,
    val type: NodeType,
    val createdAt: Long,
    val modifiedAt: Long,
    val favorite: Boolean = false,
    val trashed: Boolean = false,
)

/** [pdfPage] >= 0 means this page shows page N of the notebook's source.pdf (size in PDF points). */
data class PageInfo(
    val id: String,
    val title: String = "",
    val pdfPage: Int = -1,
    val pdfW: Float = 0f,
    val pdfH: Float = 0f,
)

data class NotebookMeta(val id: String, val pages: List<PageInfo>, val paper: PaperType = PaperType.RULED)
