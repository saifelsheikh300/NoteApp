package com.example.handnotes.data

import com.example.handnotes.engine.PageSpec

enum class NodeType { FOLDER, NOTEBOOK }

enum class PaperType { BLANK, DOTTED, RULED_NARROW, RULED, GRID, CORNELL, LEGAL }

/** Paper colour with the colours of its guide lines (ARGB). */
enum class PaperColor(val bg: Int, val line: Int, val strong: Int) {
    WHITE(0xFFFFFFFF.toInt(), 0xFFD0D7DC.toInt(), 0xFF93A1AB.toInt()),
    YELLOW(0xFFF8F5E8.toInt(), 0xFFD6D9D2.toInt(), 0xFF9BA39B.toInt()),
    DARK(0xFF1F1F1F.toInt(), 0xFF3B3B3B.toInt(), 0xFF5E5E5E.toInt()),
}

/** Page shape. [ratio] is height / width in portrait. */
enum class PageSize(val ratio: Float) { STANDARD(4f / 3f), A4(1.4142f), LETTER(1.2941f) }

/** Page size in page units (width is 1200 in portrait). */
fun PageSize.dims(landscape: Boolean): Pair<Float, Float> {
    val a = PageSpec.WIDTH
    val b = a * ratio
    return if (landscape) Pair(b, a) else Pair(a, b)
}

/** A folder or a notebook in the library tree. Unlimited depth, unlimited count. */
data class LibraryNode(
    val id: String,
    val parentId: String?,
    val name: String,
    val type: NodeType,
    val createdAt: Long,
    val modifiedAt: Long,
    val favorite: Boolean = false,
    val trashed: Boolean = false,
    val cover: String = "simple",
)

/** [pdfPage] >= 0 means this page shows page N of the notebook's source.pdf (size in PDF points). */
data class PageInfo(
    val id: String,
    val title: String = "",
    val pdfPage: Int = -1,
    val pdfW: Float = 0f,
    val pdfH: Float = 0f,
)

data class NotebookMeta(
    val id: String,
    val pages: List<PageInfo>,
    val paper: PaperType = PaperType.RULED,
    val paperColor: PaperColor = PaperColor.WHITE,
    val size: PageSize = PageSize.A4,
    val landscape: Boolean = false,
)
