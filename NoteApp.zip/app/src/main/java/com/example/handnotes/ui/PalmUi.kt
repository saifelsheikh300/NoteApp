package com.example.handnotes.ui

import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.engine.Calibration
import com.example.handnotes.engine.CalibrationQuality
import com.example.handnotes.engine.Contact
import com.example.handnotes.engine.PalmCalibrator
import com.example.handnotes.engine.PalmMath
import com.example.handnotes.engine.ToolKind
import com.example.handnotes.engine.TouchClass

private fun qualityRes(q: CalibrationQuality): Int = when (q) {
    CalibrationQuality.TOOL_TYPE -> R.string.palm_q_tooltype
    CalibrationQuality.GOOD -> R.string.palm_q_good
    CalibrationQuality.STYLUS_FINGER_SIMILAR -> R.string.palm_q_stylus_similar
    CalibrationQuality.PALM_FINGER_SIMILAR -> R.string.palm_q_palm_similar
    CalibrationQuality.INCOMPLETE -> R.string.palm_q_incomplete
    CalibrationQuality.NO_SIZE_DATA -> R.string.palm_q_no_data
}

private fun kindRes(k: ToolKind): Int = when (k) {
    ToolKind.STYLUS -> R.string.kind_stylus
    ToolKind.ERASER -> R.string.kind_eraser
    ToolKind.FINGER -> R.string.kind_finger
    ToolKind.MOUSE -> R.string.kind_mouse
    ToolKind.UNKNOWN -> R.string.kind_unknown
}

private fun classRes(c: TouchClass): Int = when (c) {
    TouchClass.PEN -> R.string.tc_pen
    TouchClass.FINGER -> R.string.tc_finger
    TouchClass.PALM -> R.string.tc_palm
    TouchClass.UNKNOWN -> R.string.tc_unknown
}

/** Palm rejection and writing mode settings. Everything here is saved on this device only. */
@Composable
fun PalmSettingsDialog(app: AppModel, onDismiss: () -> Unit) {
    var calibrating by remember { mutableStateOf(false) }
    if (calibrating) {
        PalmCalibrationDialog(app) { calibrating = false }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.palm_title)) },
        text = { PalmSettingsContent(app) { calibrating = true } },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.ok)) } },
    )
}

@Composable
fun PalmSettingsContent(app: AppModel, onCalibrate: () -> Unit) {
    val ed = app.editor
    val c = ed.palmConfig
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.palm_enable), Modifier.weight(1f))
            Switch(checked = c.enabled, onCheckedChange = { ed.palmConfig = c.copy(enabled = it); app.savePrefs() })
        }
        Text(stringResource(R.string.palm_sensitivity), style = MaterialTheme.typography.labelMedium)
        Slider(
            value = c.sensitivity,
            onValueChange = { ed.palmConfig = c.copy(sensitivity = it) },
            onValueChangeFinished = { app.savePrefs() },
            enabled = c.enabled,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.palm_lock))
                Text(stringResource(R.string.palm_lock_desc), style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = c.writingLock, onCheckedChange = { ed.palmConfig = c.copy(writingLock = it); app.savePrefs() })
        }
        OutlinedButton(onClick = { ed.allowTouchNavigation() }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.palm_nav_temp))
        }
        Button(onClick = onCalibrate, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.palm_calibrate)) }
        val cal = c.calibration
        Text(
            if (cal == null) stringResource(R.string.palm_not_calibrated) else stringResource(qualityRes(cal.quality)),
            style = MaterialTheme.typography.bodySmall,
        )
        Text(stringResource(R.string.palm_disclaimer), style = MaterialTheme.typography.bodySmall)
    }
}

/**
 * Three short tests (stylus tip, finger, resting palm), then a live test area.
 * It only measures what Android reports and says so when the stylus and a finger look the same.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun PalmCalibrationDialog(app: AppModel, onClose: () -> Unit) {
    val xdpi = LocalContext.current.resources.displayMetrics.xdpi
    var step by remember { mutableIntStateOf(0) }
    val lists = remember { listOf(mutableStateListOf<Contact>(), mutableStateListOf<Contact>(), mutableStateListOf<Contact>()) }
    var liveClass by remember { mutableStateOf<TouchClass?>(null) }
    var liveKind by remember { mutableStateOf<ToolKind?>(null) }

    val result: Calibration? = if (step == 3) PalmCalibrator.fit(lists[0].toList(), lists[1].toList(), lists[2].toList()) else null
    val testConfig = app.editor.palmConfig.copy(calibration = result)

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().padding(16.dp), shape = RoundedCornerShape(16.dp), tonalElevation = 6.dp) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.palm_title), style = MaterialTheme.typography.titleLarge)
                val (head, desc) = when (step) {
                    0 -> Pair(R.string.palm_step_stylus, R.string.palm_step_stylus_desc)
                    1 -> Pair(R.string.palm_step_finger, R.string.palm_step_finger_desc)
                    2 -> Pair(R.string.palm_step_palm, R.string.palm_step_palm_desc)
                    else -> Pair(R.string.palm_step_result, R.string.palm_live)
                }
                Text(stringResource(head), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(desc))

                Box(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Color(0xFF2B2B2B), RoundedCornerShape(12.dp))
                        .pointerInteropFilter { e ->
                            fun take(i: Int) {
                                val c = contactFrom(e, i)
                                liveKind = c.kind
                                if (step < 3) {
                                    val l = lists[step]
                                    if (l.size < MAX_SAMPLES) l.add(c)
                                } else {
                                    liveClass = PalmMath.classify(c, PalmMath.resolve(testConfig, xdpi))
                                }
                            }
                            when (e.actionMasked) {
                                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> take(e.actionIndex)
                                MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) take(i)
                            }
                            true
                        },
                )

                if (step < 3) {
                    val l = lists[step]
                    val st = PalmCalibrator.stats(l.map { it.major })
                    Text(stringResource(R.string.palm_samples, l.size))
                    if (st != null) Text(stringResource(R.string.palm_measure, st.median, st.max))
                    liveKind?.let { Text(stringResource(R.string.palm_reported, stringResource(kindRes(it)))) }
                } else {
                    liveClass?.let { Text(stringResource(R.string.palm_live_result, stringResource(classRes(it)))) }
                    result?.let { Text(stringResource(qualityRes(it.quality))) }
                    Text(stringResource(R.string.palm_disclaimer), style = MaterialTheme.typography.bodySmall)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onClose) { Text(stringResource(R.string.cancel)) }
                    if (step > 0) TextButton(onClick = { step -= 1 }) { Text(stringResource(R.string.palm_back)) }
                    if (step < 3) {
                        TextButton(onClick = { lists[step].clear() }) { Text(stringResource(R.string.palm_retry)) }
                        Button(onClick = { step += 1 }, enabled = lists[step].size >= MIN_SAMPLES) { Text(stringResource(R.string.palm_next)) }
                    } else {
                        Button(onClick = {
                            app.editor.palmConfig = app.editor.palmConfig.copy(calibration = result)
                            app.savePrefs()
                            onClose()
                        }) { Text(stringResource(R.string.palm_apply)) }
                    }
                }
            }
        }
    }
}

private const val MIN_SAMPLES = 5
private const val MAX_SAMPLES = 400
