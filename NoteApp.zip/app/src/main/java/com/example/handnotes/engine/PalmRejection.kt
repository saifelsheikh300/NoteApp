package com.example.handnotes.engine

import kotlin.math.hypot
import kotlin.math.max

/** What Android says made the contact. A generic capacitive stylus is usually reported as FINGER. */
enum class ToolKind { STYLUS, ERASER, FINGER, MOUSE, UNKNOWN }

/** Our best guess about a contact. It is a heuristic, never a guarantee. */
enum class TouchClass { PEN, FINGER, PALM, UNKNOWN }

/** Which Android value the thresholds are measured in. */
enum class SizeUnit { MAJOR_PX, SIZE_NORM }

enum class CalibrationQuality { TOOL_TYPE, GOOD, STYLUS_FINGER_SIMILAR, PALM_FINGER_SIMILAR, INCOMPLETE, NO_SIZE_DATA }

/** One finger/stylus/palm touching the screen. [major], [minor] (pixels) and [size] (0..1) are 0 if the device does not report them. */
data class Contact(
    val id: Int,
    val x: Float,
    val y: Float,
    val t: Long,
    val kind: ToolKind = ToolKind.FINGER,
    val major: Float = 0f,
    val minor: Float = 0f,
    val size: Float = 0f,
)

/** Result of the calibration screen. */
data class Calibration(
    val unit: SizeUnit,
    val narrowMax: Float,
    val palmMin: Float,
    val narrowReliable: Boolean,
    val palmReliable: Boolean,
    val stylusIsToolType: Boolean,
    val quality: CalibrationQuality,
)

data class PalmConfig(
    /** Off = no palm rejection at all (the old behaviour: a second finger means pan/zoom). */
    val enabled: Boolean = true,
    /** Manual writing lock: only one contact writes, touch gestures are off. */
    val writingLock: Boolean = false,
    /** 0 = tolerant, 1 = strict. Moves the size thresholds. */
    val sensitivity: Float = 0.5f,
    val calibration: Calibration? = null,
)

data class Thresholds(
    val unit: SizeUnit,
    val narrowMax: Float,
    val palmMin: Float,
    val narrowReliable: Boolean,
    val palmReliable: Boolean,
)

sealed interface GestureMode {
    data object None : GestureMode
    data class Draw(val id: Int) : GestureMode
    data class Navigate(val a: Int, val b: Int) : GestureMode
}

object PalmMath {
    private const val MM_PER_INCH = 25.4f

    /** Thresholds for [config]. Without calibration they come from typical sizes in millimetres. */
    fun resolve(config: PalmConfig, xdpi: Float): Thresholds {
        val s = config.sensitivity.coerceIn(0f, 1f)
        val cal = config.calibration
        if (cal == null || cal.quality == CalibrationQuality.NO_SIZE_DATA) {
            val pxPerMm = xdpi / MM_PER_INCH
            return Thresholds(SizeUnit.MAJOR_PX, (7f - 3f * s) * pxPerMm, (22f - 12f * s) * pxPerMm, true, true)
        }
        val f = 1.15f - 0.3f * s
        return Thresholds(cal.unit, cal.narrowMax * f, cal.palmMin * f, cal.narrowReliable, cal.palmReliable)
    }

    fun classify(c: Contact, th: Thresholds): TouchClass {
        if (c.kind == ToolKind.STYLUS || c.kind == ToolKind.ERASER || c.kind == ToolKind.MOUSE) return TouchClass.PEN
        val v = if (th.unit == SizeUnit.MAJOR_PX) c.major else c.size
        if (v <= 0f) return TouchClass.UNKNOWN
        if (th.palmReliable && v >= th.palmMin) return TouchClass.PALM
        if (th.narrowReliable && v <= th.narrowMax) return TouchClass.PEN
        return TouchClass.FINGER
    }
}

/**
 * Decides, for every touch event, who is writing, who is navigating and who is a resting hand.
 *
 * Rules, in order:
 * 1. A contact Android reports as stylus (or a narrow contact) writes, and always wins over other contacts.
 * 2. A very large contact is a palm and is ignored. This is decided by size only, never by duration or length,
 *    so tiny dots and short diacritics are never dropped.
 * 3. Two finger-sized contacts that land together (and have not started writing) are a pinch/pan,
 *    unless the writing lock is on.
 * 4. Otherwise the contact that is already writing keeps writing and the others are ignored.
 * Without size data the same rules run on timing alone.
 */
class PalmFilter(
    var config: PalmConfig = PalmConfig(),
    var xdpi: Float = 160f,
) {
    var commitPx: Float = 14f
    var tempNavUntil: Long = 0L

    var mode: GestureMode = GestureMode.None
        private set

    private class Track(val id: Int, var cls: TouchClass, val kind: ToolKind, val downT: Long, val downX: Float, val downY: Float) {
        var maxMajor = 0f
        var maxSize = 0f
        var displacement = 0f
        var ignored = false
        fun committed(px: Float) = displacement >= px
    }

    private val tracks = LinkedHashMap<Int, Track>()
    private var suppressUntilAllUp = false

    fun classOf(id: Int): TouchClass? = tracks[id]?.cls

    fun reset() {
        tracks.clear()
        suppressUntilAllUp = false
        mode = GestureMode.None
    }

    fun onDown(c: Contact): GestureMode {
        val cls = if (config.enabled) PalmMath.classify(c, PalmMath.resolve(config, xdpi)) else TouchClass.FINGER
        val t = Track(c.id, cls, c.kind, c.t, c.x, c.y)
        t.maxMajor = c.major
        t.maxSize = c.size
        tracks[c.id] = t
        return update(c.t)
    }

    fun onMove(c: Contact): GestureMode {
        val t = tracks[c.id] ?: return mode
        t.displacement = max(t.displacement, hypot(c.x - t.downX, c.y - t.downY))
        t.maxMajor = max(t.maxMajor, c.major)
        t.maxSize = max(t.maxSize, c.size)
        // A palm often lands narrow and spreads out in the first instants: look again for a short while.
        if (config.enabled && t.cls != TouchClass.PALM && c.t - t.downT <= SETTLE_MS) {
            val again = PalmMath.classify(
                Contact(c.id, c.x, c.y, c.t, t.kind, t.maxMajor, 0f, t.maxSize),
                PalmMath.resolve(config, xdpi),
            )
            if (again == TouchClass.PALM) t.cls = TouchClass.PALM
        }
        return update(c.t)
    }

    fun onUp(id: Int, t: Long): GestureMode {
        tracks.remove(id)
        if (tracks.isEmpty()) {
            suppressUntilAllUp = false
            mode = GestureMode.None
            return mode
        }
        return update(t)
    }

    private fun update(now: Long): GestureMode {
        val old = mode
        var next = decide(now)
        if (old is GestureMode.Navigate && next !is GestureMode.Navigate) suppressUntilAllUp = true
        if (suppressUntilAllUp) next = GestureMode.None
        if (next is GestureMode.Draw) {
            for (t in tracks.values) if (t.id != next.id && t.cls != TouchClass.PALM) t.ignored = true
        }
        mode = next
        return next
    }

    private fun decide(now: Long): GestureMode {
        val live = tracks.values.toList()
        if (!config.enabled) {
            if (config.writingLock) {
                val first = live.firstOrNull { !it.ignored } ?: return GestureMode.None
                return GestureMode.Draw(first.id)
            }
            return when {
                live.isEmpty() -> GestureMode.None
                live.size == 1 -> GestureMode.Draw(live[0].id)
                else -> GestureMode.Navigate(live[0].id, live[1].id)
            }
        }
        val cands = live.filter { it.cls != TouchClass.PALM && !it.ignored }
        if (cands.isEmpty()) return GestureMode.None

        val pens = cands.filter { it.cls == TouchClass.PEN }
        if (pens.isNotEmpty()) {
            val cur = (mode as? GestureMode.Draw)?.id
            return GestureMode.Draw((pens.firstOrNull { it.id == cur } ?: pens.first()).id)
        }
        if (cands.size == 1) return GestureMode.Draw(cands[0].id)

        val cur = mode
        if (cur is GestureMode.Navigate && cands.any { it.id == cur.a } && cands.any { it.id == cur.b }) return cur
        if (now <= tempNavUntil) return GestureMode.Navigate(cands[0].id, cands[1].id)

        val first = cands[0]
        val second = cands[1]
        val simultaneous = second.downT - first.downT <= SIMULTANEOUS_MS && !first.committed(commitPx)
        val drawing = (cur as? GestureMode.Draw)?.id?.takeIf { id -> cands.any { it.id == id } }
        if (simultaneous) {
            return if (config.writingLock) GestureMode.Draw(drawing ?: first.id) else GestureMode.Navigate(first.id, second.id)
        }
        // The first contact has already been writing: it keeps writing and later contacts are ignored.
        if (first.committed(commitPx)) return GestureMode.Draw(drawing ?: first.id)
        // The first contact has only been resting (not moved): treat it as a resting hand and write with the newest one.
        return GestureMode.Draw(cands.last().id)
    }

    companion object {
        const val SETTLE_MS = 80L
        const val SIMULTANEOUS_MS = 120L
    }
}

/** Turns the calibration screen's samples into thresholds. It never claims more than the data shows. */
object PalmCalibrator {
    data class Stats(val count: Int, val median: Float, val min: Float, val max: Float)

    fun stats(values: List<Float>): Stats? {
        val v = values.filter { it > 0f }.sorted()
        if (v.isEmpty()) return null
        return Stats(v.size, v[v.size / 2], v.first(), v.last())
    }

    fun fit(stylus: List<Contact>, finger: List<Contact>, palm: List<Contact>): Calibration {
        val all = stylus + finger + palm
        val useMajor = all.any { it.major > 0f }
        val useSize = !useMajor && all.any { it.size > 0f }
        val unit = if (useSize) SizeUnit.SIZE_NORM else SizeUnit.MAJOR_PX
        val toolType = stylus.isNotEmpty() &&
            stylus.count { it.kind == ToolKind.STYLUS || it.kind == ToolKind.ERASER } * 10 >= stylus.size * 7

        if (!useMajor && !useSize) {
            return Calibration(unit, 0f, 0f, false, false, toolType, if (toolType) CalibrationQuality.TOOL_TYPE else CalibrationQuality.NO_SIZE_DATA)
        }
        fun v(c: Contact) = if (unit == SizeUnit.MAJOR_PX) c.major else c.size
        val sSt = stats(stylus.map(::v))
        val sFi = stats(finger.map(::v))
        val sPa = stats(palm.map(::v))

        var narrowReliable = false
        var narrowMax = 0f
        if (sSt != null && sFi != null && sSt.max < sFi.median * 0.85f) {
            narrowReliable = true
            narrowMax = (sSt.max + sFi.median) / 2f
        }
        var palmReliable = false
        var palmMin = 0f
        if (sFi != null && sPa != null && sPa.median > sFi.max * 1.1f) {
            palmReliable = true
            palmMin = if (sPa.min > sFi.max) (sFi.max + sPa.min) / 2f else (sFi.max + sPa.median) / 2f
        }
        val quality = when {
            toolType -> CalibrationQuality.TOOL_TYPE
            stylus.isEmpty() || finger.isEmpty() || palm.isEmpty() -> CalibrationQuality.INCOMPLETE
            narrowReliable && palmReliable -> CalibrationQuality.GOOD
            !narrowReliable -> CalibrationQuality.STYLUS_FINGER_SIMILAR
            else -> CalibrationQuality.PALM_FINGER_SIMILAR
        }
        return Calibration(unit, narrowMax, palmMin, narrowReliable, palmReliable, toolType, quality)
    }
}
