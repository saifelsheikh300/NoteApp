package com.example.handnotes.ui

import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import androidx.compose.ui.geometry.Offset
import com.example.handnotes.engine.Contact
import com.example.handnotes.engine.GestureMode
import com.example.handnotes.engine.PalmFilter
import com.example.handnotes.engine.Pt
import com.example.handnotes.engine.ToolKind
import com.example.handnotes.engine.TouchClass
import kotlin.math.hypot

/** Raw Android contact -> engine contact. Size fields are 0 when the device does not report them. */
fun contactFrom(e: MotionEvent, i: Int): Contact = Contact(
    id = e.getPointerId(i),
    x = e.getX(i),
    y = e.getY(i),
    t = e.eventTime,
    kind = when (e.getToolType(i)) {
        MotionEvent.TOOL_TYPE_STYLUS -> ToolKind.STYLUS
        MotionEvent.TOOL_TYPE_ERASER -> ToolKind.ERASER
        MotionEvent.TOOL_TYPE_FINGER -> ToolKind.FINGER
        MotionEvent.TOOL_TYPE_MOUSE -> ToolKind.MOUSE
        else -> ToolKind.UNKNOWN
    },
    major = e.getTouchMajor(i),
    minor = e.getTouchMinor(i),
    size = e.getSize(i),
)

/**
 * Turns raw touch events into drawing, pan/zoom, or nothing, using [PalmFilter] to decide.
 * Works on MotionEvent directly so it can use touch size, tool type and every batched (historical) sample,
 * which keeps fast handwriting faithful.
 */
class TouchController(private val state: NoteState) {
    private val filter = PalmFilter()
    private val handler = Handler(Looper.getMainLooper())
    private var current: GestureMode = GestureMode.None

    var density = 1f
    var xdpi = 160f

    /** Lets us ask Android to deliver touch events without batching them to the frame rate (lower ink latency). */
    var view: View? = null

    private var anchorX = 0f
    private var anchorY = 0f
    private var holdDone = false
    private var prevCx = 0f
    private var prevCy = 0f
    private var prevDist = 0f
    private val holdRunnable = Runnable { onHoldTimeout() }

    /** Points of contacts that are not writing yet. If one of them turns out to be the pen, its first part is not lost. */
    private val buffers = HashMap<Int, ArrayList<Pt>>()

    fun onTouch(e: MotionEvent): Boolean {
        filter.config = state.palmConfig
        filter.xdpi = xdpi
        filter.commitPx = COMMIT_DP * density
        filter.tempNavUntil = state.tempNavUntilMs
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                try { view?.requestUnbufferedDispatch(e) } catch (ex: Exception) { /* not supported: ignore */ }
                filter.reset()
                buffers.clear()
                apply(GestureMode.None, e, null, cancel = true)  // drop anything left over from a lost event
                down(e)
            }
            MotionEvent.ACTION_POINTER_DOWN -> down(e)
            MotionEvent.ACTION_MOVE -> onMove(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(e)
            MotionEvent.ACTION_CANCEL -> {
                filter.reset()
                buffers.clear()
                apply(GestureMode.None, e, null, cancel = true)
            }
        }
        return true
    }

    private fun down(e: MotionEvent) {
        val c = contactFrom(e, e.actionIndex)
        val alone = filter.activeCount == 0
        val mode = filter.onDown(c)
        buffer(e, e.actionIndex, false)
        if (alone && state.palmConfig.enabled && filter.classOf(c.id) == TouchClass.PALM) state.notifyPalmRejected()
        apply(mode, e, null)
    }

    private fun buffer(e: MotionEvent, idx: Int, withHistory: Boolean) {
        val id = e.getPointerId(idx)
        if (id == (current as? GestureMode.Draw)?.id) return
        val list = buffers.getOrPut(id) { ArrayList() }
        if (list.size > MAX_BUFFER) return
        if (withHistory) {
            for (h in 0 until e.historySize) {
                list.add(
                    state.toPage(
                        e.getHistoricalX(idx, h) + state.inkOffsetX,
                        e.getHistoricalY(idx, h) + state.inkOffsetY,
                        e.getHistoricalEventTime(h),
                        e.getHistoricalPressure(idx, h),
                    ),
                )
            }
        }
        list.add(state.toPage(e.getX(idx) + state.inkOffsetX, e.getY(idx) + state.inkOffsetY, e.eventTime, e.getPressure(idx)))
    }

    private fun onMove(e: MotionEvent) {
        for (i in 0 until e.pointerCount) {
            filter.onMove(contactFrom(e, i))
            buffer(e, i, true)
        }
        val next = filter.mode
        val changed = next != current
        apply(next, e, null)
        if (changed) return
        when (val m = current) {
            is GestureMode.Draw -> {
                val idx = e.findPointerIndex(m.id)
                if (idx >= 0) addDrawSamples(e, idx)
            }
            is GestureMode.Navigate -> navMove(e, m)
            is GestureMode.Pan -> panMove(e, m)
            GestureMode.None -> Unit
        }
    }

    private fun onUp(e: MotionEvent) {
        val i = e.actionIndex
        val id = e.getPointerId(i)
        val cur = current
        if (cur is GestureMode.Draw && cur.id == id) addFinalSample(e, i)
        buffers.remove(id)
        apply(filter.onUp(id, e.eventTime), e, id)
    }

    private fun apply(next: GestureMode, e: MotionEvent, upId: Int?, cancel: Boolean = false) {
        val old = current
        if (next == old) return
        if (old is GestureMode.Draw) {
            handler.removeCallbacks(holdRunnable)
            if (!cancel && upId != null && upId == old.id) state.finishLive() else state.cancelLive()
        }
        if (old is GestureMode.Navigate || old is GestureMode.Pan) {
            if (cancel) state.beginViewGesture() else state.endViewGesture()
        }
        current = next
        when (next) {
            is GestureMode.Draw -> {
                val i = e.findPointerIndex(next.id)
                if (i >= 0) startDraw(e, i) else current = GestureMode.None
            }
            is GestureMode.Navigate -> startNav(e, next)
            is GestureMode.Pan -> startPan(e, next)
            GestureMode.None -> Unit
        }
    }

    // ---------- drawing ----------

    private fun pressure(e: MotionEvent, i: Int) = e.getPressure(i)

    private fun startDraw(e: MotionEvent, i: Int) {
        val x = e.getX(i) + state.inkOffsetX
        val y = e.getY(i) + state.inkOffsetY
        val buf = buffers.remove(e.getPointerId(i))
        if (buf != null && buf.size > 1) {
            // This contact was held back while we decided who writes: replay what it already did.
            state.beginLive(buf[0])
            state.startDragIfHit(buf[0])
            for (k in 1 until buf.size) if (state.dragging) state.dragTo(buf[k]) else state.extendLive(buf[k])
        } else {
            val p = state.toPage(x, y, e.eventTime, pressure(e, i))
            state.beginLive(p)
            state.startDragIfHit(p)
        }
        anchorX = x
        anchorY = y
        holdDone = false
        scheduleHold()
    }

    private fun addDrawSamples(e: MotionEvent, idx: Int) {
        val x = e.getX(idx) + state.inkOffsetX
        val y = e.getY(idx) + state.inkOffsetY
        if (state.dragging) {
            state.dragTo(state.toPage(x, y, e.eventTime, 1f))
            return
        }
        if (state.isSnapped) return
        for (h in 0 until e.historySize) {
            state.extendLive(
                state.toPage(
                    e.getHistoricalX(idx, h) + state.inkOffsetX,
                    e.getHistoricalY(idx, h) + state.inkOffsetY,
                    e.getHistoricalEventTime(h),
                    e.getHistoricalPressure(idx, h),
                ),
            )
        }
        state.extendLive(state.toPage(x, y, e.eventTime, pressure(e, idx)))
        if (hypot(x - anchorX, y - anchorY) > HOLD_SLOP_DP * density) {
            anchorX = x
            anchorY = y
            holdDone = false
            scheduleHold()
        }
    }

    private fun addFinalSample(e: MotionEvent, i: Int) {
        val p = state.toPage(e.getX(i) + state.inkOffsetX, e.getY(i) + state.inkOffsetY, e.eventTime, pressure(e, i))
        if (state.dragging) state.dragTo(p) else if (!state.isSnapped) state.extendLive(p)
    }

    private fun scheduleHold() {
        handler.removeCallbacks(holdRunnable)
        if (state.canSnap) handler.postDelayed(holdRunnable, HOLD_MS)
    }

    private fun onHoldTimeout() {
        if (current is GestureMode.Draw && !holdDone && !state.isSnapped) {
            holdDone = true
            state.snapToShape()
        }
    }

    // ---------- pan and zoom ----------

    private fun startPan(e: MotionEvent, m: GestureMode.Pan) {
        handler.removeCallbacks(holdRunnable)
        val i = e.findPointerIndex(m.id)
        if (i < 0) { current = GestureMode.None; return }
        prevCx = e.getX(i)
        prevCy = e.getY(i)
        state.beginViewGesture()
    }

    private fun panMove(e: MotionEvent, m: GestureMode.Pan) {
        val i = e.findPointerIndex(m.id)
        if (i < 0) return
        val x = e.getX(i)
        val y = e.getY(i)
        state.transform(Offset(prevCx, prevCy), Offset(x - prevCx, y - prevCy), 1f)
        prevCx = x
        prevCy = y
    }

    private fun startNav(e: MotionEvent, m: GestureMode.Navigate) {
        handler.removeCallbacks(holdRunnable)
        state.beginViewGesture()
        val a = e.findPointerIndex(m.a)
        val b = e.findPointerIndex(m.b)
        if (a < 0 || b < 0) { current = GestureMode.None; return }
        prevCx = (e.getX(a) + e.getX(b)) / 2f
        prevCy = (e.getY(a) + e.getY(b)) / 2f
        prevDist = hypot(e.getX(a) - e.getX(b), e.getY(a) - e.getY(b))
    }

    private fun navMove(e: MotionEvent, m: GestureMode.Navigate) {
        val a = e.findPointerIndex(m.a)
        val b = e.findPointerIndex(m.b)
        if (a < 0 || b < 0) return
        val cx = (e.getX(a) + e.getX(b)) / 2f
        val cy = (e.getY(a) + e.getY(b)) / 2f
        val dist = hypot(e.getX(a) - e.getX(b), e.getY(a) - e.getY(b))
        if (prevDist > 1f && dist > 1f) {
            state.transform(Offset(prevCx, prevCy), Offset(cx - prevCx, cy - prevCy), dist / prevDist)
        }
        prevCx = cx
        prevCy = cy
        prevDist = dist
    }

    private companion object {
        const val HOLD_MS = 600L
        const val HOLD_SLOP_DP = 5f
        const val COMMIT_DP = 14f
        const val MAX_BUFFER = 400
    }
}
