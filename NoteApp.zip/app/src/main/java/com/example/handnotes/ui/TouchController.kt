package com.example.handnotes.ui

import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import androidx.compose.ui.geometry.Offset
import com.example.handnotes.engine.Contact
import com.example.handnotes.engine.GestureMode
import com.example.handnotes.engine.PalmFilter
import com.example.handnotes.engine.ToolKind
import kotlin.math.hypot

/** Raw Android contact -> engine contact. Size fields are 0 when the device does not report them. */
fun contactFrom(e: MotionEvent, i: Int): Contact = Contact(
    id = e.getPointerId(i),
    x = e.getX(i),
    y = e.getY(i),
    t = e.eventTime,
    kind = when (e.getToolType(i)) {
        MotionEvent.TOOL_TYPE_STYLUS -> ToolKind.STYLUS
        MotionEvent.TOOL_TYPE_ERASER -> ToolKind.ERASER
        MotionEvent.TOOL_TYPE_FINGER -> ToolKind.FINGER
        MotionEvent.TOOL_TYPE_MOUSE -> ToolKind.MOUSE
        else -> ToolKind.UNKNOWN
    },
    major = e.getTouchMajor(i),
    minor = e.getTouchMinor(i),
    size = e.getSize(i),
)

/**
 * Turns raw touch events into drawing, pan/zoom, or nothing, using [PalmFilter] to decide.
 * Works on MotionEvent directly so it can use touch size, tool type and every batched (historical) sample,
 * which keeps fast handwriting faithful.
 */
class TouchController(private val state: NoteState) {
    private val filter = PalmFilter()
    private val handler = Handler(Looper.getMainLooper())
    private var current: GestureMode = GestureMode.None

    var density = 1f
    var xdpi = 160f

    private var anchorX = 0f
    private var anchorY = 0f
    private var holdDone = false
    private var prevCx = 0f
    private var prevCy = 0f
    private var prevDist = 0f
    private val holdRunnable = Runnable { onHoldTimeout() }

    fun onTouch(e: MotionEvent): Boolean {
        filter.config = state.palmConfig
        filter.xdpi = xdpi
        filter.commitPx = COMMIT_DP * density
        filter.tempNavUntil = state.tempNavUntilMs
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                filter.reset()
                apply(GestureMode.None, e, null, cancel = true)  // drop anything left over from a lost event
                apply(filter.onDown(contactFrom(e, e.actionIndex)), e, null)
            }
            MotionEvent.ACTION_POINTER_DOWN -> apply(filter.onDown(contactFrom(e, e.actionIndex)), e, null)
            MotionEvent.ACTION_MOVE -> onMove(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(e)
            MotionEvent.ACTION_CANCEL -> {
                filter.reset()
                apply(GestureMode.None, e, null, cancel = true)
            }
        }
        return true
    }

    private fun onMove(e: MotionEvent) {
        for (i in 0 until e.pointerCount) filter.onMove(contactFrom(e, i))
        val next = filter.mode
        val changed = next != current
        apply(next, e, null)
        if (changed) return
        when (val m = current) {
            is GestureMode.Draw -> {
                val idx = e.findPointerIndex(m.id)
                if (idx >= 0) addDrawSamples(e, idx)
            }
            is GestureMode.Navigate -> navMove(e, m)
            GestureMode.None -> Unit
        }
    }

    private fun onUp(e: MotionEvent) {
        val i = e.actionIndex
        val id = e.getPointerId(i)
        val cur = current
        if (cur is GestureMode.Draw && cur.id == id) addFinalSample(e, i)
        apply(filter.onUp(id, e.eventTime), e, id)
    }

    private fun apply(next: GestureMode, e: MotionEvent, upId: Int?, cancel: Boolean = false) {
        val old = current
        if (next == old) return
        if (old is GestureMode.Draw) {
            handler.removeCallbacks(holdRunnable)
            if (!cancel && upId != null && upId == old.id) state.finishLive() else state.cancelLive()
        }
        current = next
        when (next) {
            is GestureMode.Draw -> {
                val i = e.findPointerIndex(next.id)
                if (i >= 0) startDraw(e, i) else current = GestureMode.None
            }
            is GestureMode.Navigate -> startNav(e, next)
            GestureMode.None -> Unit
        }
    }

    // ---------- drawing ----------

    private fun pressure(e: MotionEvent, i: Int) = e.getPressure(i)

    private fun startDraw(e: MotionEvent, i: Int) {
        val x = e.getX(i)
        val y = e.getY(i)
        val p = state.toPage(x, y, e.eventTime, pressure(e, i))
        state.beginLive(p)
        state.startDragIfHit(p)
        anchorX = x
        anchorY = y
        holdDone = false
        scheduleHold()
    }

    private fun addDrawSamples(e: MotionEvent, idx: Int) {
        val x = e.getX(idx)
        val y = e.getY(idx)
        if (state.dragging) {
            state.dragTo(state.toPage(x, y, e.eventTime, 1f))
            return
        }
        if (state.isSnapped) return
        for (h in 0 until e.historySize) {
            state.extendLive(
                state.toPage(e.getHistoricalX(idx, h), e.getHistoricalY(idx, h), e.getHistoricalEventTime(h), e.getHistoricalPressure(idx, h)),
            )
        }
        state.extendLive(state.toPage(x, y, e.eventTime, pressure(e, idx)))
        if (hypot(x - anchorX, y - anchorY) > HOLD_SLOP_DP * density) {
            anchorX = x
            anchorY = y
            holdDone = false
            scheduleHold()
        }
    }

    private fun addFinalSample(e: MotionEvent, i: Int) {
        val p = state.toPage(e.getX(i), e.getY(i), e.eventTime, pressure(e, i))
        if (state.dragging) state.dragTo(p) else if (!state.isSnapped) state.extendLive(p)
    }

    private fun scheduleHold() {
        handler.removeCallbacks(holdRunnable)
        if (state.canSnap) handler.postDelayed(holdRunnable, HOLD_MS)
    }

    private fun onHoldTimeout() {
        if (current is GestureMode.Draw && !holdDone && !state.isSnapped) {
            holdDone = true
            state.snapToShape()
        }
    }

    // ---------- pan and zoom ----------

    private fun startNav(e: MotionEvent, m: GestureMode.Navigate) {
        handler.removeCallbacks(holdRunnable)
        val a = e.findPointerIndex(m.a)
        val b = e.findPointerIndex(m.b)
        if (a < 0 || b < 0) { current = GestureMode.None; return }
        prevCx = (e.getX(a) + e.getX(b)) / 2f
        prevCy = (e.getY(a) + e.getY(b)) / 2f
        prevDist = hypot(e.getX(a) - e.getX(b), e.getY(a) - e.getY(b))
    }

    private fun navMove(e: MotionEvent, m: GestureMode.Navigate) {
        val a = e.findPointerIndex(m.a)
        val b = e.findPointerIndex(m.b)
        if (a < 0 || b < 0) return
        val cx = (e.getX(a) + e.getX(b)) / 2f
        val cy = (e.getY(a) + e.getY(b)) / 2f
        val dist = hypot(e.getX(a) - e.getX(b), e.getY(a) - e.getY(b))
        if (prevDist > 1f && dist > 1f) {
            state.transform(Offset(prevCx, prevCy), Offset(cx - prevCx, cy - prevCy), dist / prevDist)
        }
        prevCx = cx
        prevCy = cy
        prevDist = dist
    }

    private companion object {
        const val HOLD_MS = 600L
        const val HOLD_SLOP_DP = 5f
        const val COMMIT_DP = 14f
    }
}
