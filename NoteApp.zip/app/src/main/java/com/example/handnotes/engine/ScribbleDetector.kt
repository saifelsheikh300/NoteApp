package com.example.handnotes.engine

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** All thresholds are configurable from Settings. */
data class ScribbleConfig(
    val enabled: Boolean = true,
    val minSizePx: Float = 40f,          // smaller gestures are ignored
    val maxSizePx: Float = 1500f,        // larger gestures are ignored
    val minReversals: Int = 4,           // "complexity": how many times the pen turns back
    val minDensity: Float = 6f,          // path length / bounding-box diagonal
    val minIntersections: Int = 0,       // hard gate on self-crossings (soft score always counts them)
    val minDurationMs: Long = 100L,
    val maxDurationMs: Long = 10_000L,
    val confidenceThreshold: Float = 0.7f,
    val coverageRequired: Float = 0.5f,  // share of a stroke's points that must lie under the scribble
    val eraseRadius: Float = 12f,        // padding around the scribble area
)

data class ScribbleResult(
    val isScribble: Boolean,
    val confidence: Float,
    val reversals: Int,
    val intersections: Int,
    val density: Float,
)

/**
 * Decides whether a finished stroke is an "erase scribble" and which strokes it covers.
 * Pure Kotlin (no Android classes) so it can be unit-tested on the JVM.
 *
 * Hard gates (all must pass): size range, duration range, enough direction reversals,
 * enough path density. Then a confidence score (reversals, density, self-crossings)
 * must reach the threshold. Normal handwriting has few reversals and low density.
 */
class ScribbleDetector(val config: ScribbleConfig = ScribbleConfig()) {

    fun analyze(points: List<Pt>): ScribbleResult {
        val no = ScribbleResult(false, 0f, 0, 0, 0f)
        if (!config.enabled || points.size < 8) return no

        val diag = Bounds.of(points).diagonal
        if (diag < config.minSizePx || diag > config.maxSizePx) return no

        val duration = points.last().t - points.first().t
        if (duration < config.minDurationMs || duration > config.maxDurationMs) return no

        val anchors = anchors(points, max(4f, diag * 0.06f))
        if (anchors.size < 6) return no

        var pathLen = 0f
        for (i in 1 until anchors.size) pathLen += hypot(anchors[i].x - anchors[i - 1].x, anchors[i].y - anchors[i - 1].y)
        val density = pathLen / diag
        val reversals = (totalTurning(anchors) / PI).roundToInt()
        val crossings = countCrossings(anchors)

        val rScore = min(1f, reversals / (config.minReversals * 1.5f))
        val dScore = min(1f, density / (config.minDensity * 1.5f))
        val xScore = min(1f, crossings / 6f)
        val confidence = 0.4f * rScore + 0.4f * dScore + 0.2f * xScore

        val passes = reversals >= config.minReversals &&
            density >= config.minDensity &&
            crossings >= config.minIntersections &&
            confidence >= config.confidenceThreshold
        return ScribbleResult(passes, confidence, reversals, crossings, density)
    }

    /** Strokes mostly covered by the scribble's (padded) bounding box. */
    fun findTargets(strokes: List<InkStroke>, scribble: List<Pt>): List<InkStroke> {
        if (scribble.isEmpty()) return emptyList()
        val area = Bounds.of(scribble).inflate(config.eraseRadius)
        return strokes.filter { s ->
            s.points.isNotEmpty() && s.bounds.intersects(area) &&
                s.points.count { area.contains(it.x, it.y) }.toFloat() / s.points.size >= config.coverageRequired
        }
    }

    private fun anchors(points: List<Pt>, step: Float): List<Pt> {
        val out = ArrayList<Pt>()
        out.add(points[0])
        for (p in points) {
            val last = out.last()
            if (hypot(p.x - last.x, p.y - last.y) >= step) out.add(p)
        }
        return out
    }

    /** Sum of absolute turning angles along the polyline, in radians. */
    private fun totalTurning(a: List<Pt>): Float {
        var total = 0f
        for (i in 1 until a.size - 1) {
            val d1x = a[i].x - a[i - 1].x
            val d1y = a[i].y - a[i - 1].y
            val d2x = a[i + 1].x - a[i].x
            val d2y = a[i + 1].y - a[i].y
            total += abs(atan2(d1x * d2y - d1y * d2x, d1x * d2x + d1y * d2y))
        }
        return total
    }

    private fun countCrossings(a: List<Pt>): Int {
        val pts = if (a.size > 300) a.filterIndexed { i, _ -> i % (a.size / 300 + 1) == 0 } else a
        var n = 0
        for (i in 0 until pts.size - 1) {
            for (j in i + 2 until pts.size - 1) {
                if (Geometry.segmentsIntersect(pts[i], pts[i + 1], pts[j], pts[j + 1])) n++
            }
        }
        return n
    }
}
