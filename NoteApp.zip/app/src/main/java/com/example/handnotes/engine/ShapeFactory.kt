package com.example.handnotes.engine

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

enum class ShapeKind { LINE, ARROW, RECT, ELLIPSE, TRIANGLE, STAR }

/** Builds exact shapes for the shape tool from the drag start [a] and end [b]. Pure geometry. */
object ShapeFactory {
    fun build(kind: ShapeKind, a: Pt, b: Pt): List<Pt> {
        val t = a.t
        fun p(x: Float, y: Float) = Pt(x, y, t, 1f)
        val l = minOf(a.x, b.x)
        val r = maxOf(a.x, b.x)
        val top = minOf(a.y, b.y)
        val bot = maxOf(a.y, b.y)
        val cx = (l + r) / 2f
        val cy = (top + bot) / 2f
        val rx = (r - l) / 2f
        val ry = (bot - top) / 2f
        return when (kind) {
            ShapeKind.LINE -> listOf(p(a.x, a.y), p(b.x, b.y))
            ShapeKind.ARROW -> {
                val dx = b.x - a.x
                val dy = b.y - a.y
                val len = hypot(dx, dy)
                if (len < 1f) return listOf(p(a.x, a.y), p(b.x, b.y))
                val head = minOf(len * 0.3f, 60f)
                val ang = atan2(dy, dx)
                val spread = (PI / 7.0).toFloat()
                listOf(
                    p(a.x, a.y), p(b.x, b.y),
                    p(b.x - head * cos(ang - spread), b.y - head * sin(ang - spread)),
                    p(b.x, b.y),
                    p(b.x - head * cos(ang + spread), b.y - head * sin(ang + spread)),
                )
            }
            ShapeKind.RECT -> listOf(p(l, top), p(r, top), p(r, bot), p(l, bot), p(l, top))
            ShapeKind.ELLIPSE -> (0..72).map { i ->
                val th = (2.0 * PI * i / 72.0).toFloat()
                p(cx + rx * cos(th), cy + ry * sin(th))
            }
            ShapeKind.TRIANGLE -> listOf(p(cx, top), p(r, bot), p(l, bot), p(cx, top))
            ShapeKind.STAR -> (0..10).map { k ->
                val ang = (-PI / 2.0 + k * PI / 5.0).toFloat()
                val rad = if (k % 2 == 0) 1f else 0.42f
                p(cx + rx * rad * cos(ang), cy + ry * rad * sin(ang))
            }
        }
    }
}
