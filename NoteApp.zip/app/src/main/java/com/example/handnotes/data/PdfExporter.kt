package com.example.handnotes.data

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.example.handnotes.engine.ImageObject
import com.example.handnotes.engine.InkStroke
import com.example.handnotes.engine.PageSpec
import java.io.OutputStream
import kotlin.math.roundToInt

/**
 * Writes pages as a new PDF: the original page (as an image, for PDF notebooks) with the ink on top as vector paths.
 * The source PDF is never touched. Annotations are flattened into the exported file.
 */
object PdfExporter {
    private const val SHORT_SIDE_PT = 595f
    private const val EXPORT_RENDER_WIDTH = 1700

    fun write(
        repo: LibraryRepository,
        meta: NotebookMeta,
        pdf: PdfSource?,
        images: ImageStore?,
        pageIndices: List<Int>,
        out: OutputStream,
    ) {
        val doc = PdfDocument()
        try {
            val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
            val (pw, ph) = meta.size.dims(meta.landscape)
            val shortSide = minOf(pw, ph)
            for ((n, idx) in pageIndices.withIndex()) {
                val info = meta.pages[idx]
                val fromPdf = info.pdfPage >= 0 && info.pdfW > 0f && pdf != null
                val logicalW = if (fromPdf) PageSpec.WIDTH else pw
                val wPt = if (fromPdf) info.pdfW else pw * SHORT_SIDE_PT / shortSide
                val hPt = if (fromPdf) info.pdfH else ph * SHORT_SIDE_PT / shortSide
                val page = doc.startPage(PdfDocument.PageInfo.Builder(wPt.roundToInt(), hPt.roundToInt(), n + 1).create())
                val canvas = page.canvas
                canvas.drawColor(if (fromPdf) 0xFFFFFFFF.toInt() else meta.paperColor.bg)
                if (fromPdf && pdf != null) {
                    val bmp = pdf.render(info.pdfPage, EXPORT_RENDER_WIDTH)
                    canvas.drawBitmap(bmp, null, RectF(0f, 0f, wPt, hPt), bitmapPaint)
                    bmp.recycle()
                }
                val k = wPt / logicalW
                val logicalH = hPt / k
                canvas.save()
                canvas.scale(k, k)
                if (!fromPdf) drawPaper(canvas, meta.paper, meta.paperColor, logicalW, logicalH)
                val content = repo.loadPage(meta.id, info.id)
                if (images != null) for (im in content.images) drawImage(canvas, images, im, bitmapPaint)
                for (s in content.strokes) drawStroke(canvas, s)
                canvas.restore()
                doc.finishPage(page)
            }
            doc.writeTo(out)
            out.flush()
        } finally {
            doc.close()
        }
    }

    private fun drawImage(canvas: Canvas, store: ImageStore, im: ImageObject, paint: Paint) {
        val bmp = store.load(im.file) ?: return
        canvas.save()
        canvas.rotate(im.rotationDeg, im.cx, im.cy)
        canvas.drawBitmap(bmp, null, RectF(im.cx - im.w / 2f, im.cy - im.h / 2f, im.cx + im.w / 2f, im.cy + im.h / 2f), paint)
        canvas.restore()
        bmp.recycle()
    }

    private fun drawStroke(canvas: Canvas, s: InkStroke) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = s.width
            color = s.color
            alpha = (s.opacity * 255f).roundToInt().coerceIn(0, 255)
        }
        val p = s.points
        if (p.isEmpty()) return
        val path = Path()
        path.moveTo(p[0].x, p[0].y)
        if (p.size == 1) {
            path.lineTo(p[0].x + 0.01f, p[0].y)
        } else {
            for (i in 1 until p.size) {
                path.quadTo(p[i - 1].x, p[i - 1].y, (p[i - 1].x + p[i].x) / 2f, (p[i - 1].y + p[i].y) / 2f)
            }
            path.lineTo(p.last().x, p.last().y)
        }
        canvas.drawPath(path, paint)
    }

    private fun drawPaper(canvas: Canvas, type: PaperType, color: PaperColor, w: Float, h: Float) {
        val shape = PaperPattern.build(type, w, h)
        val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color.line; strokeWidth = 1.5f; style = Paint.Style.STROKE }
        val strong = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color.strong; strokeWidth = 2f; style = Paint.Style.STROKE }
        for (s in shape.segments) canvas.drawLine(s.x1, s.y1, s.x2, s.y2, if (s.strong) strong else thin)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color.strong; style = Paint.Style.FILL }
        for (d in shape.dots) canvas.drawCircle(d.first, d.second, 2.5f, dot)
    }
}
