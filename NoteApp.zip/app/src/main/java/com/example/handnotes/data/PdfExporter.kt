package com.example.handnotes.data

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.example.handnotes.engine.ImageObject
import com.example.handnotes.engine.InkStroke
import com.example.handnotes.engine.PageSpec
import java.io.OutputStream
import kotlin.math.roundToInt

/**
 * Writes pages as a new PDF: the original page (as an image, for PDF notebooks) with the ink on top as vector paths.
 * The source PDF is never touched. Annotations are flattened into the exported file.
 */
object PdfExporter {
    private const val A4_WIDTH_PT = 595f
    private const val EXPORT_RENDER_WIDTH = 1700
    private const val PAPER_GAP = 44f
    private const val PAPER_LINE = 0xFFB0BEC5.toInt()

    fun write(
        repo: LibraryRepository,
        meta: NotebookMeta,
        pdf: PdfSource?,
        images: ImageStore?,
        pageIndices: List<Int>,
        out: OutputStream,
    ) {
        val doc = PdfDocument()
        try {
            val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
            for ((n, idx) in pageIndices.withIndex()) {
                val info = meta.pages[idx]
                val fromPdf = info.pdfPage >= 0 && info.pdfW > 0f && pdf != null
                val wPt = if (fromPdf) info.pdfW else A4_WIDTH_PT
                val hPt = if (fromPdf) info.pdfH else A4_WIDTH_PT * PageSpec.HEIGHT / PageSpec.WIDTH
                val page = doc.startPage(PdfDocument.PageInfo.Builder(wPt.roundToInt(), hPt.roundToInt(), n + 1).create())
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                if (fromPdf && pdf != null) {
                    val bmp = pdf.render(info.pdfPage, EXPORT_RENDER_WIDTH)
                    canvas.drawBitmap(bmp, null, RectF(0f, 0f, wPt, hPt), bitmapPaint)
                    bmp.recycle()
                }
                val k = wPt / PageSpec.WIDTH
                val logicalH = hPt / k
                canvas.save()
                canvas.scale(k, k)
                if (!fromPdf) drawPaper(canvas, meta.paper, PageSpec.WIDTH, logicalH)
                val content = repo.loadPage(meta.id, info.id)
                if (images != null) for (im in content.images) drawImage(canvas, images, im, bitmapPaint)
                for (s in content.strokes) drawStroke(canvas, s)
                canvas.restore()
                doc.finishPage(page)
            }
            doc.writeTo(out)
            out.flush()
        } finally {
            doc.close()
        }
    }

    private fun drawImage(canvas: Canvas, store: ImageStore, im: ImageObject, paint: Paint) {
        val bmp = store.load(im.file) ?: return
        canvas.save()
        canvas.rotate(im.rotationDeg, im.cx, im.cy)
        canvas.drawBitmap(bmp, null, RectF(im.cx - im.w / 2f, im.cy - im.h / 2f, im.cx + im.w / 2f, im.cy + im.h / 2f), paint)
        canvas.restore()
        bmp.recycle()
    }

    private fun drawStroke(canvas: Canvas, s: InkStroke) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = s.width
            color = s.color
            alpha = (s.opacity * 255f).roundToInt().coerceIn(0, 255)
        }
        val p = s.points
        if (p.isEmpty()) return
        val path = Path()
        path.moveTo(p[0].x, p[0].y)
        if (p.size == 1) {
            path.lineTo(p[0].x + 0.01f, p[0].y)
        } else {
            for (i in 1 until p.size) {
                path.quadTo(p[i - 1].x, p[i - 1].y, (p[i - 1].x + p[i].x) / 2f, (p[i - 1].y + p[i].y) / 2f)
            }
            path.lineTo(p.last().x, p.last().y)
        }
        canvas.drawPath(path, paint)
    }

    private fun drawPaper(canvas: Canvas, type: PaperType, w: Float, h: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PAPER_LINE; strokeWidth = 1f; style = Paint.Style.FILL }
        if (type == PaperType.RULED || type == PaperType.GRID) {
            var y = PAPER_GAP
            while (y < h) { canvas.drawLine(0f, y, w, y, paint); y += PAPER_GAP }
        }
        if (type == PaperType.GRID) {
            var x = PAPER_GAP
            while (x < w) { canvas.drawLine(x, 0f, x, h, paint); x += PAPER_GAP }
        }
        if (type == PaperType.DOTTED) {
            var y = PAPER_GAP
            while (y < h) {
                var x = PAPER_GAP
                while (x < w) { canvas.drawCircle(x, y, 2f, paint); x += PAPER_GAP }
                y += PAPER_GAP
            }
        }
    }
}
