package com.example.handnotes.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import com.example.handnotes.data.PaperType
import com.example.handnotes.engine.EditStrokesCommand
import com.example.handnotes.engine.EraseResult
import com.example.handnotes.engine.Eraser
import com.example.handnotes.engine.History
import com.example.handnotes.engine.Bounds
import com.example.handnotes.engine.Command
import com.example.handnotes.engine.CompositeCommand
import com.example.handnotes.engine.EditImagesCommand
import com.example.handnotes.engine.ImageObject
import com.example.handnotes.engine.ImageTransform
import com.example.handnotes.engine.PageContent
import com.example.handnotes.engine.ReplaceImagesCommand
import com.example.handnotes.engine.Lasso
import com.example.handnotes.engine.ReplaceStrokesCommand
import com.example.handnotes.engine.StrokeTransform
import com.example.handnotes.engine.InkStroke
import com.example.handnotes.engine.PageDoc
import com.example.handnotes.engine.PageSpec
import com.example.handnotes.engine.ShapeRecognizer
import com.example.handnotes.engine.Pt
import com.example.handnotes.engine.ScribbleConfig
import com.example.handnotes.engine.ScribbleDetector
import com.example.handnotes.engine.Smoothing
import com.example.handnotes.engine.ToolType
import kotlin.math.min
import kotlin.math.roundToInt

/** UI-facing holder for the page being edited. All drawing logic lives in the engine package. */
class NoteState {
    val page = PageDoc()
    private var history = History(page)
    private val detector = ScribbleDetector(ScribbleConfig())

    var tool by mutableStateOf(ToolType.PEN)
    var color by mutableIntStateOf(0xFF000000.toInt())
    var width by mutableFloatStateOf(5f)
    var smoothing by mutableFloatStateOf(0f)
    var eraserRadius by mutableFloatStateOf(18f)
    var scribbleEnabled by mutableStateOf(true)
    var paper by mutableStateOf(PaperType.RULED)
    var shapeSnap by mutableStateOf(false)

    // ---- page size and PDF background ----
    var pageW by mutableFloatStateOf(PageSpec.WIDTH)
        private set
    var pageH by mutableFloatStateOf(PageSpec.HEIGHT)
        private set

    /** True when the current page shows a PDF page (the paper template is then not drawn). */
    var pdfPage by mutableStateOf(false)
    var pdfImage by mutableStateOf<ImageBitmap?>(null)

    fun setPageSize(w: Float, h: Float) {
        pageW = w
        pageH = h
        clampOffset()
    }

    fun scrollToTop() {
        offsetY = 0f
        clampOffset()
    }

    // ---- view (zoom and pan). Pure presentation: strokes stay in page units. ----
    var scale by mutableFloatStateOf(1f)
        private set
    var offsetX by mutableFloatStateOf(0f)
        private set
    var offsetY by mutableFloatStateOf(0f)
        private set
    private var viewW = 0f
    private var viewH = 0f
    private var fitPending = true

    val zoomPercent: Int get() = (scale * 100f).roundToInt()

    fun onViewport(w: Float, h: Float) {
        viewW = w
        viewH = h
        if (fitPending && w > 0f) { fitWidth(); fitPending = false } else clampOffset()
    }

    /** Called when a notebook opens, so the page starts fitted to the screen width. */
    fun resetView() {
        fitPending = true
        if (viewW > 0f) { fitWidth(); fitPending = false }
    }

    fun fitWidth() {
        if (viewW <= 0f) return
        scale = (viewW / pageW).coerceIn(MIN_SCALE, MAX_SCALE)
        offsetX = 0f
        offsetY = 0f
        clampOffset()
    }

    fun fitPage() {
        if (viewW <= 0f || viewH <= 0f) return
        scale = min(viewW / pageW, viewH / pageH).coerceIn(MIN_SCALE, MAX_SCALE)
        offsetX = 0f
        offsetY = 0f
        clampOffset()
    }

    /** Zoom by [zoom] around [centroid], then pan by [pan] (screen pixels). */
    fun transform(centroid: Offset, pan: Offset, zoom: Float) {
        val s2 = (scale * zoom).coerceIn(MIN_SCALE, MAX_SCALE)
        val px = (centroid.x - offsetX) / scale
        val py = (centroid.y - offsetY) / scale
        scale = s2
        offsetX = centroid.x - px * s2 + pan.x
        offsetY = centroid.y - py * s2 + pan.y
        clampOffset()
    }

    fun zoomBy(factor: Float) = transform(Offset(viewW / 2f, viewH / 2f), Offset.Zero, factor)

    private fun clampOffset() {
        val pw = pageW * scale
        val ph = pageH * scale
        offsetX = if (pw <= viewW) (viewW - pw) / 2f else offsetX.coerceIn(viewW - pw, 0f)
        offsetY = if (ph <= viewH) (viewH - ph) / 2f else offsetY.coerceIn(viewH - ph, 0f)
    }

    // ---- draw and hold ----
    private var snapped = false
    val isSnapped: Boolean get() = snapped
    val canSnap: Boolean get() = shapeSnap && (tool == ToolType.PEN || tool == ToolType.HIGHLIGHTER)

    /** Replaces the live stroke with a perfect shape if it looks like one. */
    fun snapToShape(): Boolean {
        if (!canSnap || live.isEmpty()) return false
        val shape = ShapeRecognizer.recognize(live.toList()) ?: return false
        live.clear()
        live.addAll(shape)
        snapped = true
        liveTick++
        return true
    }

    /** Called after every change to the page (drawing, erasing, undo, redo). Used for autosave. */
    var onChanged: (() -> Unit)? = null

    /** Bumped whenever the page changes, so the canvas redraws. */
    var revision by mutableIntStateOf(0)
        private set

    /** Bumped while a stroke is being drawn. */
    var liveTick by mutableIntStateOf(0)
        private set

    val live = ArrayList<Pt>()

    val canUndo: Boolean get() = revision >= 0 && history.canUndo
    val canRedo: Boolean get() = revision >= 0 && history.canRedo

    // ---- lasso / selection (ink and pictures) ----
    var selection by mutableStateOf<Set<String>>(emptySet())
        private set
    private var clipStrokes: List<InkStroke> = emptyList()
    private var clipImages: List<ImageObject> = emptyList()
    var clipboardSize by mutableIntStateOf(0)
        private set
    private var dragStrokes: List<InkStroke>? = null
    private var dragImages: List<ImageObject> = emptyList()
    private var lastDragPt: Pt? = null
    private var dragMoved = false

    /** Decoded pictures for the current page. Filled by [imageLoader] in the background. */
    val imageCache = mutableStateMapOf<String, ImageBitmap>()
    var imageLoader: ((String) -> Unit)? = null

    val isLassoTool: Boolean get() = tool == ToolType.LASSO || tool == ToolType.LASSO_RECT
    val dragging: Boolean get() = dragStrokes != null

    fun selectTool(t: ToolType) {
        tool = t
        if (t != ToolType.LASSO && t != ToolType.LASSO_RECT) selection = emptySet()
    }

    fun selectedStrokes(): List<InkStroke> {
        if (revision < 0 || selection.isEmpty()) return emptyList()
        return page.strokes.filter { it.id in selection }
    }

    fun selectedImages(): List<ImageObject> {
        if (revision < 0 || selection.isEmpty()) return emptyList()
        return page.images.filter { it.id in selection }
    }

    fun selectionBounds(): Bounds? {
        val ss = selectedStrokes()
        val si = selectedImages()
        if (ss.isEmpty() && si.isEmpty()) return null
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE; var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (s in ss) {
            val pad = s.width / 2f
            l = min(l, s.bounds.left - pad); t = min(t, s.bounds.top - pad)
            r = maxOf(r, s.bounds.right + pad); b = maxOf(b, s.bounds.bottom + pad)
        }
        for (i in si) {
            val bb = i.bounds()
            l = min(l, bb.left); t = min(t, bb.top)
            r = maxOf(r, bb.right); b = maxOf(b, bb.bottom)
        }
        return Bounds(l, t, r, b)
    }

    val hasSelection: Boolean get() = selectedStrokes().isNotEmpty() || selectedImages().isNotEmpty()

    fun clearSelection() { selection = emptySet() }

    /** Starts moving the selection if a lasso-tool touch lands on it. */
    fun startDragIfHit(p: Pt): Boolean {
        if (!isLassoTool) return false
        val b = selectionBounds()?.inflate(HIT_PAD) ?: return false
        if (!b.contains(p.x, p.y)) return false
        dragStrokes = selectedStrokes()
        dragImages = selectedImages()
        lastDragPt = p
        dragMoved = false
        live.clear()
        liveTick++
        return true
    }

    fun dragTo(p: Pt) {
        val last = lastDragPt ?: return
        val dx = p.x - last.x
        val dy = p.y - last.y
        lastDragPt = p
        if (dx == 0f && dy == 0f) return
        dragMoved = true
        val ids = selection
        for (i in page.strokes.indices) {
            val s = page.strokes[i]
            if (s.id in ids) page.strokes[i] = StrokeTransform.translate(s, dx, dy)
        }
        for (i in page.images.indices) {
            val im = page.images[i]
            if (im.id in ids) page.images[i] = ImageTransform.translate(im, dx, dy)
        }
        revision++
    }

    private fun endDrag() {
        val beforeS = dragStrokes ?: return
        val beforeI = dragImages
        dragStrokes = null
        dragImages = emptyList()
        lastDragPt = null
        if (!dragMoved) return
        val parts = ArrayList<Command>()
        if (beforeS.isNotEmpty()) {
            val ids = beforeS.map { it.id }.toSet()
            parts.add(ReplaceStrokesCommand(beforeS, page.strokes.filter { it.id in ids }))
        }
        if (beforeI.isNotEmpty()) {
            val ids = beforeI.map { it.id }.toSet()
            parts.add(ReplaceImagesCommand(beforeI, page.images.filter { it.id in ids }))
        }
        if (parts.isNotEmpty()) execute(CompositeCommand(parts))
    }

    private fun abortDrag() {
        val beforeS = dragStrokes ?: return
        val sById = beforeS.associateBy { it.id }
        val iById = dragImages.associateBy { it.id }
        dragStrokes = null
        dragImages = emptyList()
        lastDragPt = null
        for (i in page.strokes.indices) sById[page.strokes[i].id]?.let { page.strokes[i] = it }
        for (i in page.images.indices) iById[page.images[i].id]?.let { page.images[i] = it }
        revision++
    }

    private fun finishLasso(raw: List<Pt>) {
        val polygon = if (tool == ToolType.LASSO_RECT) Lasso.rect(raw) else raw
        val bigEnough = polygon.size >= 3 && Bounds.of(polygon).diagonal >= TAP_SIZE
        var sel: Set<String> = Lasso.select(page.strokes, polygon)
        if (bigEnough) {
            sel = sel + page.images.filter { Lasso.contains(polygon, it.cx, it.cy) }.map { it.id }
        } else if (sel.isEmpty() && raw.isNotEmpty()) {
            // A tap on a picture selects it.
            val tap = raw.last()
            page.images.lastOrNull { it.contains(tap.x, tap.y) }?.let { sel = setOf(it.id) }
        }
        selection = sel
    }

    private fun removalCommand(ss: List<InkStroke>, si: List<ImageObject>): Command? {
        val parts = ArrayList<Command>()
        if (ss.isNotEmpty()) parts.add(EditStrokesCommand(ss, emptyList()))
        if (si.isNotEmpty()) parts.add(EditImagesCommand(si, emptyList()))
        return if (parts.isEmpty()) null else CompositeCommand(parts)
    }

    fun deleteSelection() {
        val cmd = removalCommand(selectedStrokes(), selectedImages()) ?: return
        selection = emptySet()
        execute(cmd)
    }

    fun copySelection() {
        val ss = selectedStrokes()
        val si = selectedImages()
        if (ss.isEmpty() && si.isEmpty()) return
        clipStrokes = ss
        clipImages = si
        clipboardSize = ss.size + si.size
    }

    fun cutSelection() { copySelection(); deleteSelection() }

    fun pasteClipboard() {
        if (clipStrokes.isEmpty() && clipImages.isEmpty()) return
        val ns = StrokeTransform.clone(clipStrokes, PASTE_OFFSET, PASTE_OFFSET)
        val ni = ImageTransform.clone(clipImages, PASTE_OFFSET, PASTE_OFFSET)
        val parts = ArrayList<Command>()
        if (ns.isNotEmpty()) parts.add(EditStrokesCommand(emptyList(), ns))
        if (ni.isNotEmpty()) parts.add(EditImagesCommand(emptyList(), ni))
        execute(CompositeCommand(parts))
        selection = (ns.map { it.id } + ni.map { it.id }).toSet()
    }

    fun duplicateSelection() { copySelection(); pasteClipboard() }

    fun scaleSelection(factor: Float) = transformSelection(
        { s, cx, cy -> StrokeTransform.scale(s, factor, cx, cy) },
        { i, cx, cy -> ImageTransform.scale(i, factor, cx, cy) },
    )

    fun rotateSelection(degrees: Float) {
        val rad = Math.toRadians(degrees.toDouble()).toFloat()
        transformSelection(
            { s, cx, cy -> StrokeTransform.rotate(s, rad, cx, cy) },
            { i, cx, cy -> ImageTransform.rotate(i, rad, cx, cy) },
        )
    }

    private fun transformSelection(
        fs: (InkStroke, Float, Float) -> InkStroke,
        fi: (ImageObject, Float, Float) -> ImageObject,
    ) {
        val ss = selectedStrokes()
        val si = selectedImages()
        val b = selectionBounds() ?: return
        val cx = (b.left + b.right) / 2f
        val cy = (b.top + b.bottom) / 2f
        val parts = ArrayList<Command>()
        if (ss.isNotEmpty()) parts.add(ReplaceStrokesCommand(ss, ss.map { fs(it, cx, cy) }))
        if (si.isNotEmpty()) parts.add(ReplaceImagesCommand(si, si.map { fi(it, cx, cy) }))
        execute(CompositeCommand(parts))
    }

    // ---- pictures ----

    /** Centre of what the user currently sees, in page units. */
    fun viewCenterPage(): Offset {
        val x = ((viewW / 2f - offsetX) / scale).coerceIn(0f, pageW)
        val y = ((viewH / 2f - offsetY) / scale).coerceIn(0f, pageH)
        return Offset(x, y)
    }

    /** Puts a stored picture in the middle of the view and selects it, so it can be moved right away. */
    fun addImage(file: String, pxW: Int, pxH: Int) {
        if (pxW <= 0 || pxH <= 0) return
        var w = pageW * IMAGE_START_FRACTION
        var h = w * pxH / pxW
        if (h > pageH * 0.6f) { h = pageH * 0.6f; w = h * pxW / pxH }
        val c = viewCenterPage()
        val img = ImageObject(file = file, cx = c.x, cy = c.y, w = w, h = h)
        tool = ToolType.LASSO
        execute(EditImagesCommand(emptyList(), listOf(img)))
        selection = setOf(img.id)
    }

    private fun ensureImages() {
        for (i in page.images) if (i.file !in imageCache) imageLoader?.invoke(i.file)
    }

    // ---- page content ----

    fun snapshot(): PageContent = PageContent(page.strokes.toList(), page.images.toList())

    /** Replaces the page content (used when switching pages). Does not trigger autosave. */
    fun loadPage(content: PageContent) {
        live.clear()
        dragStrokes = null
        dragImages = emptyList()
        selection = emptySet()
        liveTick++
        page.strokes.clear()
        page.strokes.addAll(content.strokes)
        page.images.clear()
        page.images.addAll(content.images)
        history = History(page)
        val keep = content.images.map { it.file }.toSet()
        imageCache.keys.filter { it !in keep }.forEach { imageCache.remove(it) }
        revision++
        ensureImages()
    }

    fun beginLive(p: Pt) { dragStrokes = null; snapped = false; live.clear(); live.add(p); liveTick++ }
    fun extendLive(p: Pt) { live.add(p); liveTick++ }
    fun cancelLive() { abortDrag(); snapped = false; live.clear(); liveTick++ }

    fun finishLive() {
        if (dragStrokes != null) {
            endDrag()
            live.clear()
            liveTick++
            return
        }
        val raw = ArrayList(live)
        val wasSnapped = snapped
        snapped = false
        live.clear()
        liveTick++
        if (raw.isEmpty()) return
        when (tool) {
            ToolType.PEN, ToolType.HIGHLIGHTER -> finishInk(raw, wasSnapped)
            ToolType.ERASER_STROKE -> run(Eraser.eraseStrokes(page.strokes, raw, eraserRadius))
            ToolType.ERASER_SEGMENT -> run(Eraser.eraseSegments(page.strokes, raw, eraserRadius))
            ToolType.LASSO, ToolType.LASSO_RECT -> finishLasso(raw)
        }
    }

    private fun finishInk(raw: List<Pt>, perfectShape: Boolean) {
        if (!perfectShape && tool == ToolType.PEN && scribbleEnabled) {
            val result = detector.analyze(raw)
            if (result.isScribble) {
                val targets = detector.findTargets(page.strokes, raw)
                if (targets.isNotEmpty()) {
                    // Real scribble over ink: erase what is underneath, do not keep the scribble itself.
                    execute(EditStrokesCommand(targets, emptyList()))
                    return
                }
            }
        }
        val highlighter = tool == ToolType.HIGHLIGHTER
        val stroke = InkStroke(
            points = if (perfectShape) raw else Smoothing.smooth(raw, smoothing),
            color = color,
            width = if (highlighter) width * 3f else width,
            tool = tool,
            opacity = if (highlighter) 0.35f else 1f,
        )
        execute(EditStrokesCommand(emptyList(), listOf(stroke)))
    }

    private fun run(r: EraseResult) {
        if (!r.isEmpty) execute(EditStrokesCommand(r.removed, r.added))
    }

    private fun execute(cmd: Command) {
        history.execute(cmd)
        changed()
    }

    private fun changed() {
        revision++
        ensureImages()
        onChanged?.invoke()
    }

    fun undo() { if (history.undo()) changed() }
    fun redo() { if (history.redo()) changed() }

    fun clearPage() {
        val cmd = removalCommand(page.strokes.toList(), page.images.toList()) ?: return
        selection = emptySet()
        execute(cmd)
    }

    private companion object {
        const val MIN_SCALE = 0.25f
        const val MAX_SCALE = 8f
        const val HIT_PAD = 14f
        const val PASTE_OFFSET = 40f
        const val TAP_SIZE = 12f
        const val IMAGE_START_FRACTION = 0.45f
    }
}
