package com.example.handnotes.data

/**
 * Guide lines and dots of a paper template, in page units.
 * Pure geometry, so the screen and the PDF export draw exactly the same paper.
 */
object PaperPattern {
    data class Seg(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val strong: Boolean)

    class Shape(val segments: List<Seg>, val dots: List<Pair<Float, Float>>)

    private const val DOT_GAP = 48f
    private const val NARROW_TOP = 100f
    private const val NARROW_GAP = 34f
    private const val WIDE_TOP = 110f
    private const val WIDE_GAP = 56f
    private const val GRID_GAP = 40f
    private const val BOTTOM_MARGIN = 40f

    fun build(type: PaperType, w: Float, h: Float): Shape {
        val segs = ArrayList<Seg>()
        val dots = ArrayList<Pair<Float, Float>>()

        fun rules(top: Float, gap: Float) {
            var y = top
            while (y <= h - BOTTOM_MARGIN) {
                segs.add(Seg(0f, y, w, y, false))
                y += gap
            }
        }

        when (type) {
            PaperType.BLANK -> Unit
            PaperType.DOTTED -> {
                var y = DOT_GAP
                while (y < h) {
                    var x = DOT_GAP
                    while (x < w) { dots.add(Pair(x, y)); x += DOT_GAP }
                    y += DOT_GAP
                }
            }
            PaperType.RULED_NARROW -> rules(NARROW_TOP, NARROW_GAP)
            PaperType.RULED -> rules(WIDE_TOP, WIDE_GAP)
            PaperType.GRID -> {
                var y = GRID_GAP
                while (y < h) { segs.add(Seg(0f, y, w, y, false)); y += GRID_GAP }
                var x = GRID_GAP
                while (x < w) { segs.add(Seg(x, 0f, x, h, false)); x += GRID_GAP }
            }
            PaperType.CORNELL -> {
                val header = 130f
                val cue = w * 0.28f
                val summary = h * 0.84f
                segs.add(Seg(0f, header, w, header, true))
                segs.add(Seg(cue, header, cue, summary, true))
                segs.add(Seg(0f, summary, w, summary, true))
            }
            PaperType.LEGAL -> {
                rules(WIDE_TOP, WIDE_GAP)
                val margin = w * 0.12f
                segs.add(Seg(margin, 0f, margin, h, true))
                segs.add(Seg(margin + 10f, 0f, margin + 10f, h, true))
            }
        }
        return Shape(segs, dots)
    }
}
