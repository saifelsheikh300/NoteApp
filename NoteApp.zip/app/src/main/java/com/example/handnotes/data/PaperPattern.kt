package com.example.handnotes.data

/**
 * Guide lines and dots of a paper template, in page units.
 * Pure geometry, so the screen, the thumbnails and the PDF export draw exactly the same paper.
 * With [rtl] the margin, the cue column and the check boxes move to the right (Arabic layouts).
 */
object PaperPattern {
    data class Seg(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val strong: Boolean)

    class Shape(val segments: List<Seg>, val dots: List<Pair<Float, Float>>)

    private const val DOT_GAP = 48f
    private const val NARROW_TOP = 100f
    private const val NARROW_GAP = 34f
    private const val WIDE_TOP = 110f
    private const val WIDE_GAP = 56f
    private const val GRID_GAP = 40f
    private const val BOTTOM_MARGIN = 40f

    fun build(type: PaperType, w: Float, h: Float, rtl: Boolean = false): Shape {
        val segs = ArrayList<Seg>()
        val dots = ArrayList<Pair<Float, Float>>()

        fun line(x1: Float, y1: Float, x2: Float, y2: Float, strong: Boolean = false) {
            segs.add(Seg(x1, y1, x2, y2, strong))
        }
        fun rect(l: Float, t: Float, r: Float, b: Float) {
            line(l, t, r, t, true); line(r, t, r, b, true); line(r, b, l, b, true); line(l, b, l, t, true)
        }
        fun rules(top: Float, gap: Float, left: Float = 0f, right: Float = w, bottom: Float = h - BOTTOM_MARGIN) {
            var y = top
            while (y <= bottom) { line(left, y, right, y); y += gap }
        }

        when (type) {
            PaperType.BLANK -> Unit
            PaperType.DOTTED -> {
                var y = DOT_GAP
                while (y < h) {
                    var x = DOT_GAP
                    while (x < w) { dots.add(Pair(x, y)); x += DOT_GAP }
                    y += DOT_GAP
                }
            }
            PaperType.RULED_NARROW -> rules(NARROW_TOP, NARROW_GAP)
            PaperType.RULED -> rules(WIDE_TOP, WIDE_GAP)
            PaperType.GRID -> {
                var y = GRID_GAP
                while (y < h) { line(0f, y, w, y); y += GRID_GAP }
                var x = GRID_GAP
                while (x < w) { line(x, 0f, x, h); x += GRID_GAP }
            }
            PaperType.CORNELL -> {
                val header = 130f
                val cue = if (rtl) w * 0.72f else w * 0.28f
                val summary = h * 0.84f
                line(0f, header, w, header, true)
                line(cue, header, cue, summary, true)
                line(0f, summary, w, summary, true)
            }
            PaperType.LEGAL -> {
                rules(WIDE_TOP, WIDE_GAP)
                val margin = if (rtl) w * 0.88f else w * 0.12f
                line(margin, 0f, margin, h, true)
                line(margin + 10f, 0f, margin + 10f, h, true)
            }
            PaperType.GRAPH -> {
                var y = 24f
                var k = 0
                while (y < h) { line(0f, y, w, y, k % 5 == 4); y += 24f; k++ }
                var x = 24f
                k = 0
                while (x < w) { line(x, 0f, x, h, k % 5 == 4); x += 24f; k++ }
            }
            PaperType.TODO -> {
                line(60f, 110f, w - 60f, 110f, true)
                val side = 30f
                var y = 170f
                while (y <= h - 80f) {
                    val bx = if (rtl) w - 60f - side else 60f
                    rect(bx, y - side, bx + side, y)
                    val from = if (rtl) 60f else 60f + side + 24f
                    val to = if (rtl) w - 60f - side - 24f else w - 60f
                    line(from, y, to, y)
                    y += 72f
                }
            }
            PaperType.WEEKLY -> {
                val top = 130f
                val bottom = h - 60f
                val rows = 4
                val cellH = (bottom - top) / rows
                val mid = w / 2f
                for (r in 0..rows) line(40f, top + r * cellH, w - 40f, top + r * cellH, true)
                line(40f, top, 40f, bottom, true)
                line(w - 40f, top, w - 40f, bottom, true)
                line(mid, top, mid, bottom, true)
                for (r in 0 until rows) {
                    line(40f, top + r * cellH + 56f, mid, top + r * cellH + 56f)
                    line(mid, top + r * cellH + 56f, w - 40f, top + r * cellH + 56f)
                }
            }
            PaperType.MONTHLY -> {
                val top = 170f
                val bottom = h - 60f
                val left = 40f
                val right = w - 40f
                val cw = (right - left) / 7f
                val rh = (bottom - top) / 6f
                for (c in 0..7) line(left + c * cw, top - 50f, left + c * cw, bottom, true)
                line(left, top - 50f, right, top - 50f, true)
                for (r in 0..6) line(left, top + r * rh, right, top + r * rh, true)
            }
            PaperType.LECTURE -> {
                val cue = if (rtl) w * 0.7f else w * 0.3f
                val end = h * 0.9f
                line(0f, 170f, w, 170f, true)
                line(cue, 170f, cue, end, true)
                line(0f, end, w, end, true)
                val l = if (rtl) 0f else cue
                val r = if (rtl) cue else w
                var y = 170f + WIDE_GAP
                while (y < end) { line(l, y, r, y); y += WIDE_GAP }
            }
            PaperType.MUSIC -> {
                var top = 110f
                while (top + 64f <= h - 80f) {
                    for (k in 0..4) line(60f, top + k * 16f, w - 60f, top + k * 16f)
                    line(60f, top, 60f, top + 64f, true)
                    line(w - 60f, top, w - 60f, top + 64f, true)
                    top += 150f
                }
            }
        }
        return Shape(segs, dots)
    }
}
