package com.example.handnotes.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.data.PageSize
import com.example.handnotes.data.PaperColor
import com.example.handnotes.data.PaperPattern
import com.example.handnotes.data.PaperType
import com.example.handnotes.data.dims

@Composable
fun NewNotebookDialog(app: AppModel, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var cover by remember { mutableStateOf("simple") }
    var paper by remember { mutableStateOf(PaperType.GRID) }
    var color by remember { mutableStateOf(PaperColor.YELLOW) }
    var size by remember { mutableStateOf(PageSize.A4) }
    var landscape by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val untitled = stringResource(R.string.untitled_notebook)

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Surface(Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.92f), shape = RoundedCornerShape(18.dp), color = Pal.dialog) {
                Column {
                    Row(Modifier.weight(1f)) {
                        Column(
                            Modifier.width(300.dp).fillMaxHeight().verticalScroll(rememberScrollState()).padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Text(stringResource(R.string.title_label), fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it },
                                singleLine = true,
                                placeholder = { Text(untitled) },
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Text(stringResource(R.string.cover_label), fontWeight = FontWeight.SemiBold)
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .border(if (tab == 0) 2.dp else 0.dp, if (tab == 0) Pal.accent else Color.Transparent, RoundedCornerShape(12.dp))
                                    .clickable { tab = 0 }.padding(14.dp),
                                contentAlignment = Alignment.Center,
                            ) { CoverArt(cover, Modifier.size(width = 150.dp, height = 200.dp), Color(color.bg)) }
                            Text(stringResource(R.string.paper_label), fontWeight = FontWeight.SemiBold)
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .border(if (tab == 1) 2.dp else 0.dp, if (tab == 1) Pal.accent else Color.Transparent, RoundedCornerShape(12.dp))
                                    .clickable { tab = 1 }.padding(14.dp),
                                contentAlignment = Alignment.Center,
                            ) { PaperThumb(paper, color, size, landscape, Modifier.width(150.dp)) }
                        }
                        Column(Modifier.weight(1f).fillMaxHeight()) {
                            Row(
                                Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                DropPill(sizeLabel(size)) { close ->
                                    for (s in PageSize.entries) DropdownMenuItem(text = { Text(sizeLabel(s)) }, onClick = { size = s; close() })
                                }
                                DropPill(colorLabel(color)) { close ->
                                    for (c in PaperColor.entries) DropdownMenuItem(text = { Text(colorLabel(c)) }, onClick = { color = c; close() })
                                }
                                Spacer(Modifier.weight(1f))
                                OrientationToggle(landscape) { landscape = it }
                            }
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                            if (tab == 0) CoverChoices(cover) { cover = it }
                            else PaperChoices(paper, color, size, landscape) { paper = it }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = {
                            app.createNotebook(title.trim().ifEmpty { untitled }, cover, paper, color, size, landscape)
                            onDismiss()
                        }) { Text(stringResource(R.string.create_notebook)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DropPill(label: String, content: @Composable (close: () -> Unit) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Pal.pill).clickable { open = true }.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label)
            Spacer(Modifier.width(6.dp))
            GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) { content { open = false } }
    }
}

@Composable
private fun OrientationToggle(landscape: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(20.dp)).background(Pal.pill)) {
        for ((value, res) in listOf(false to R.string.portrait, true to R.string.landscape)) {
            Box(
                Modifier.background(if (landscape == value) Color(0xFF555555) else Color.Transparent)
                    .clickable { onChange(value) }.padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text(stringResource(res), fontSize = 13.sp) }
        }
    }
}

@Composable
private fun CoverCell(id: String, label: String, selected: Boolean, onPick: () -> Unit) {
    Column(Modifier.padding(8.dp).clickable(onClick = onPick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(width = 104.dp, height = 138.dp).padding(2.dp)
                .border(if (selected) 3.dp else 0.dp, if (selected) Pal.accent else Color.Transparent, RoundedCornerShape(12.dp))
                .padding(4.dp),
        ) { CoverArt(id, Modifier.fillMaxSize()) }
        Text(label, fontSize = 12.sp, color = if (selected) Pal.accent else Color.White)
    }
}

@Composable
private fun CoverChoices(selected: String, onPick: (String) -> Unit) {
    LazyVerticalGrid(GridCells.Adaptive(120.dp), Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) { Text(stringResource(R.string.section_simple), fontSize = 18.sp, modifier = Modifier.padding(8.dp)) }
        item { CoverCell("none", stringResource(R.string.cover_none), selected == "none") { onPick("none") } }
        items(Covers.simple, key = { it.id }) { c -> CoverCell(c.id, stringResource(c.label), selected == c.id) { onPick(c.id) } }
        item(span = { GridItemSpan(maxLineSpan) }) { Text(stringResource(R.string.section_solid), fontSize = 18.sp, modifier = Modifier.padding(8.dp)) }
        items(Covers.solid, key = { it.id }) { c -> CoverCell(c.id, stringResource(c.label), selected == c.id) { onPick(c.id) } }
    }
}

/** Paper templates, grouped. Reused by "Change Template" inside a notebook. */
@Composable
fun PaperChoices(selected: PaperType, color: PaperColor, size: PageSize, landscape: Boolean, onPick: (PaperType) -> Unit) {
    val essentials = listOf(PaperType.BLANK, PaperType.DOTTED, PaperType.RULED_NARROW, PaperType.RULED, PaperType.GRID)
    val writing = listOf(PaperType.CORNELL, PaperType.LEGAL)
    LazyVerticalGrid(GridCells.Adaptive(130.dp), Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) { Text(stringResource(R.string.section_essentials), fontSize = 18.sp, modifier = Modifier.padding(8.dp)) }
        items(essentials, key = { it.name }) { t -> PaperCell(t, color, size, landscape, selected == t) { onPick(t) } }
        item(span = { GridItemSpan(maxLineSpan) }) { Text(stringResource(R.string.section_writing), fontSize = 18.sp, modifier = Modifier.padding(8.dp)) }
        items(writing, key = { it.name }) { t -> PaperCell(t, color, size, landscape, selected == t) { onPick(t) } }
    }
}

@Composable
private fun PaperCell(type: PaperType, color: PaperColor, size: PageSize, landscape: Boolean, selected: Boolean, onPick: () -> Unit) {
    Column(Modifier.padding(8.dp).clickable(onClick = onPick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.width(110.dp)
                .border(if (selected) 3.dp else 1.dp, if (selected) Pal.accent else Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                .padding(3.dp),
        ) { PaperThumb(type, color, size, landscape, Modifier.fillMaxWidth()) }
        Text(paperLabel(type), fontSize = 12.sp, color = if (selected) Pal.accent else Color.White)
    }
}

/** A small preview of a paper template. */
@Composable
fun PaperThumb(type: PaperType, color: PaperColor, size: PageSize, landscape: Boolean, modifier: Modifier = Modifier) {
    val (pw, ph) = size.dims(landscape)
    val shape = remember(type, pw, ph) { PaperPattern.build(type, pw, ph) }
    Canvas(modifier.aspectRatio(pw / ph)) {
        drawRect(Color(color.bg))
        val sc = this.size.width / pw
        val thin = Color(color.line)
        val strong = Color(color.strong)
        for (s in shape.segments) {
            drawLine(if (s.strong) strong else thin, Offset(s.x1 * sc, s.y1 * sc), Offset(s.x2 * sc, s.y2 * sc), if (s.strong) 1.5f else 1f)
        }
        for (d in shape.dots) drawCircle(strong, 1.2f, Offset(d.first * sc, d.second * sc))
    }
}
