package com.example.handnotes.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.data.PageSize
import com.example.handnotes.data.PageTemplate
import com.example.handnotes.data.PaperColor
import com.example.handnotes.data.PaperPattern
import com.example.handnotes.data.PaperType
import com.example.handnotes.data.dims
import com.example.handnotes.engine.PageContent

private val essentials = listOf(PaperType.BLANK, PaperType.DOTTED, PaperType.RULED_NARROW, PaperType.RULED, PaperType.GRID, PaperType.GRAPH)
private val writingPapers = listOf(PaperType.CORNELL, PaperType.LEGAL, PaperType.LECTURE)
private val plannerPapers = listOf(PaperType.TODO, PaperType.WEEKLY, PaperType.MONTHLY)
private val musicPapers = listOf(PaperType.MUSIC)

/** New notebook: cover and paper side by side, a name, one big button. Tap a preview to change it. */
@Composable
fun NewNotebookDialog(app: AppModel, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var cover by remember { mutableStateOf("simple") }
    var paper by remember { mutableStateOf(PaperType.LEGAL) }
    var color by remember { mutableStateOf(PaperColor.YELLOW) }
    var size by remember { mutableStateOf(PageSize.A4) }
    var landscape by remember { mutableStateOf(false) }
    var rtl by remember { mutableStateOf(false) }
    var template by remember { mutableStateOf<PageTemplate?>(null) }
    var sheet by remember { mutableIntStateOf(0) }
    val untitled = stringResource(R.string.untitled_notebook)
    val templates = app.templateList()

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Surface(Modifier.fillMaxSize(), color = Pal.dialog) {
                Box(Modifier.fillMaxSize()) {
                    IconBtn(Ic.CLOSE, Modifier.align(Alignment.TopEnd).padding(16.dp)) { onDismiss() }
                    Column(
                        Modifier.align(Alignment.Center).widthIn(max = 640.dp).fillMaxWidth().padding(24.dp).verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(24.dp),
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(44.dp), verticalAlignment = Alignment.Bottom) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CoverArt(cover, Modifier.size(width = 170.dp, height = 226.dp).clickable { sheet = 1 }, Color(color.bg))
                                PreviewLabel(coverName(cover)) { sheet = 1 }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.width(260.dp).clickable { sheet = 2 }) {
                                    PaperThumb(paper, color, size, landscape, Modifier.fillMaxWidth(), rtl, template?.content)
                                }
                                PreviewLabel(template?.name ?: paperLabel(paper)) { sheet = 2 }
                            }
                        }
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            singleLine = true,
                            placeholder = { Text(untitled) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Button(
                            onClick = {
                                val name = title.trim().ifEmpty { untitled }
                                val t = template
                                if (t != null) app.newNotebookFromTemplate(t, name, cover)
                                else app.createNotebook(name, cover, paper, color, size, landscape, rtl)
                                onDismiss()
                            },
                            shape = RoundedCornerShape(28.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Pal.accent, contentColor = Color.White),
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                        ) { Text(stringResource(R.string.create_notebook), fontFamily = FontFamily.Serif, fontSize = 20.sp) }
                    }

                    if (sheet == 1) {
                        Sheet(R.string.choose_cover, { sheet = 0 }, Modifier.align(Alignment.BottomCenter)) {
                            Text(stringResource(R.string.section_simple), color = Pal.dim)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                item { CoverCell("none", stringResource(R.string.cover_none), cover == "none") { cover = "none" } }
                                items(Covers.simple, key = { it.id }) { c -> CoverCell(c.id, stringResource(c.label), cover == c.id) { cover = c.id } }
                            }
                            Text(stringResource(R.string.section_solid), color = Pal.dim, modifier = Modifier.padding(top = 12.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(Covers.solid, key = { it.id }) { c -> CoverCell(c.id, stringResource(c.label), cover == c.id) { cover = c.id } }
                            }
                        }
                    }
                    if (sheet == 2) {
                        Sheet(R.string.choose_paper, { sheet = 0 }, Modifier.align(Alignment.BottomCenter)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                for (c in PaperColor.entries) {
                                    Box(
                                        Modifier.size(38.dp).clip(CircleShape).background(Color(c.bg))
                                            .border(if (color == c) 3.dp else 1.dp, if (color == c) Pal.accent else Color(0x66FFFFFF), CircleShape)
                                            .clickable { color = c; template = null },
                                    )
                                }
                                Spacer(Modifier.weight(1f))
                                SizePill(size) { size = it; template = null }
                                OrientationToggle(landscape) { landscape = it; template = null }
                            }
                            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(stringResource(R.string.rtl_layout), modifier = Modifier.weight(1f))
                                Switch(checked = rtl, onCheckedChange = { rtl = it; template = null })
                            }
                            PaperRow(R.string.section_essentials, essentials, paper, template == null, color, size, landscape, rtl) { paper = it; template = null }
                            PaperRow(R.string.section_writing, writingPapers, paper, template == null, color, size, landscape, rtl) { paper = it; template = null }
                            PaperRow(R.string.section_planner, plannerPapers, paper, template == null, color, size, landscape, rtl) { paper = it; template = null }
                            PaperRow(R.string.section_music, musicPapers, paper, template == null, color, size, landscape, rtl) { paper = it; template = null }
                            if (templates.isNotEmpty()) {
                                Text(stringResource(R.string.my_templates), color = Pal.dim, modifier = Modifier.padding(top = 12.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(templates, key = { it.id }) { t ->
                                        Column(
                                            Modifier.clickable {
                                                paper = t.paper; color = t.paperColor; size = t.size; landscape = t.landscape; rtl = t.rtl; template = t
                                            },
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                        ) {
                                            Box(
                                                Modifier.width(96.dp)
                                                    .border(if (template?.id == t.id) 3.dp else 1.dp, if (template?.id == t.id) Pal.accent else Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                                                    .padding(3.dp),
                                            ) { PaperThumb(t.paper, t.paperColor, t.size, t.landscape, Modifier.fillMaxWidth(), t.rtl, t.content) }
                                            Text(t.name, fontSize = 12.sp, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun coverName(id: String): String = Covers.byId(id)?.let { stringResource(it.label) } ?: stringResource(R.string.cover_none)

@Composable
private fun PreviewLabel(text: String, onClick: () -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, fontSize = 17.sp)
        Spacer(Modifier.width(6.dp))
        GIcon(Ic.CHEVRON, Color.White, box = 14.dp)
    }
}

@Composable
private fun Sheet(title: Int, onDone: () -> Unit, modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onDone))
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), color = Pal.sidebar) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBtn(Ic.CLOSE, onClick = onDone)
                Text(stringResource(title), fontFamily = FontFamily.Serif, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
                TextButton(onClick = onDone) { Text(stringResource(R.string.done), color = Pal.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            }
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                content()
            }
        }
    }
}

@Composable
private fun SizePill(size: PageSize, onPick: (PageSize) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Pal.pill).clickable { open = true }.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(sizeLabel(size))
            Spacer(Modifier.width(6.dp))
            GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            for (s in PageSize.entries) DropdownMenuItem(text = { Text(sizeLabel(s)) }, onClick = { onPick(s); open = false })
        }
    }
}

@Composable
private fun OrientationToggle(landscape: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.clip(RoundedCornerShape(20.dp)).background(Pal.pill)) {
        for ((value, res) in listOf(false to R.string.portrait, true to R.string.landscape)) {
            Box(
                Modifier.background(if (landscape == value) Color(0xFF555555) else Color.Transparent)
                    .clickable { onChange(value) }.padding(horizontal = 12.dp, vertical = 8.dp),
            ) { Text(stringResource(res), fontSize = 13.sp) }
        }
    }
}

@Composable
private fun CoverCell(id: String, label: String, selected: Boolean, onPick: () -> Unit) {
    Column(Modifier.clickable(onClick = onPick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(width = 96.dp, height = 128.dp)
                .border(if (selected) 3.dp else 0.dp, if (selected) Pal.accent else Color.Transparent, RoundedCornerShape(12.dp))
                .padding(4.dp),
        ) { CoverArt(id, Modifier.fillMaxSize()) }
        Text(label, fontSize = 12.sp, color = if (selected) Pal.accent else Color.White, maxLines = 1)
    }
}

@Composable
private fun PaperRow(
    title: Int,
    types: List<PaperType>,
    selected: PaperType,
    enabled: Boolean,
    color: PaperColor,
    size: PageSize,
    landscape: Boolean,
    rtl: Boolean,
    onPick: (PaperType) -> Unit,
) {
    Text(stringResource(title), color = Pal.dim, modifier = Modifier.padding(top = 12.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(types, key = { it.name }) { t ->
            val on = enabled && selected == t
            Column(Modifier.clickable { onPick(t) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.width(96.dp).border(if (on) 3.dp else 1.dp, if (on) Pal.accent else Color(0x33FFFFFF), RoundedCornerShape(6.dp)).padding(3.dp),
                ) { PaperThumb(t, color, size, landscape, Modifier.fillMaxWidth(), rtl) }
                Text(paperLabel(t), fontSize = 12.sp, color = if (on) Pal.accent else Color.White, maxLines = 1)
            }
        }
    }
}

/** Paper templates as a grid. Used by "Change Template" inside a notebook. */
@Composable
fun PaperChoices(selected: PaperType, color: PaperColor, size: PageSize, landscape: Boolean, rtl: Boolean = false, onPick: (PaperType) -> Unit) {
    val groups = listOf(
        R.string.section_essentials to essentials,
        R.string.section_writing to writingPapers,
        R.string.section_planner to plannerPapers,
        R.string.section_music to musicPapers,
    )
    LazyVerticalGrid(GridCells.Adaptive(120.dp), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
        for ((titleRes, types) in groups) {
            item(span = { GridItemSpan(maxLineSpan) }) { Text(stringResource(titleRes), fontSize = 17.sp, modifier = Modifier.padding(8.dp)) }
            items(types, key = { it.name }) { t ->
                Column(Modifier.padding(8.dp).clickable { onPick(t) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.width(100.dp)
                            .border(if (selected == t) 3.dp else 1.dp, if (selected == t) Pal.accent else Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                            .padding(3.dp),
                    ) { PaperThumb(t, color, size, landscape, Modifier.fillMaxWidth(), rtl) }
                    Text(paperLabel(t), fontSize = 12.sp, color = if (selected == t) Pal.accent else Color.White)
                }
            }
        }
    }
}

/** A small preview of a paper template, optionally with the content of a personal template. */
@Composable
fun PaperThumb(
    type: PaperType,
    color: PaperColor,
    size: PageSize,
    landscape: Boolean,
    modifier: Modifier = Modifier,
    rtl: Boolean = false,
    content: PageContent? = null,
) {
    val (pw, ph) = size.dims(landscape)
    val shape = remember(type, pw, ph, rtl) { PaperPattern.build(type, pw, ph, rtl) }
    Canvas(modifier.aspectRatio(pw / ph)) {
        drawRect(Color(color.bg))
        val sc = this.size.width / pw
        val thin = Color(color.line)
        val strong = Color(color.strong)
        for (s in shape.segments) {
            drawLine(if (s.strong) strong else thin, Offset(s.x1 * sc, s.y1 * sc), Offset(s.x2 * sc, s.y2 * sc), if (s.strong) 1.5f else 1f)
        }
        for (d in shape.dots) drawCircle(strong, 1.2f, Offset(d.first * sc, d.second * sc))
        if (content != null) {
            scale(sc, sc, Offset.Zero) {
                for (st in content.strokes) {
                    drawPath(
                        strokePath(st.points),
                        color = Color(st.color).copy(alpha = st.opacity),
                        style = Stroke(width = st.width, cap = StrokeCap.Round),
                    )
                }
            }
        }
    }
}
