package com.example.handnotes.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.data.LibraryNode
import com.example.handnotes.data.NodeType
import com.example.handnotes.data.PaperType
import kotlin.math.abs

@Composable
fun NoteApp(app: AppModel) {
    Column(Modifier.fillMaxSize()) {
        StatusBar(app)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (app.openNotebookId != null) {
                BackHandler { app.closeNotebook() }
                EditorScreen(app)
            } else {
                BackHandler(enabled = app.currentFolder != null || app.showTrash || app.query.isNotBlank()) { app.navigateUp() }
                LibraryScreen(app)
            }
        }
    }
}

@Composable
private fun StatusBar(app: AppModel) {
    val msg = app.message
    if (app.busy) {
        Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.working), modifier = Modifier.padding(12.dp))
        }
    } else if (msg != null) {
        Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth().clickable { app.message = null }) {
            Text(msg, modifier = Modifier.padding(12.dp))
        }
    }
}

// ---------------------------------------------------------------- editor

@Composable
private fun EditorScreen(app: AppModel) {
    val meta = app.meta ?: return
    Column(Modifier.fillMaxSize()) {
        EditorHeader(app, meta.pages.size)
        Toolbar(app.editor)
        if (app.editor.isLassoTool) SelectionBar(app.editor)
        DrawingSurface(app.editor, Modifier.weight(1f).fillMaxWidth())
    }
}

@Composable
private fun paperLabel(p: PaperType): String = stringResource(
    when (p) {
        PaperType.BLANK -> R.string.paper_blank
        PaperType.DOTTED -> R.string.paper_dotted
        PaperType.RULED_NARROW -> R.string.paper_ruled_narrow
        PaperType.RULED -> R.string.paper_ruled
        PaperType.GRID -> R.string.paper_grid
        PaperType.CORNELL -> R.string.paper_cornell
        PaperType.LEGAL -> R.string.paper_legal
    },
)

@Composable
private fun EditorHeader(app: AppModel, pageCount: Int) {
    var paperMenu by remember { mutableStateOf(false) }
    var showPalm by remember { mutableStateOf(false) }
    if (showPalm) PalmSettingsDialog(app) { showPalm = false }
    val name = app.openNotebookId?.let { app.repo.get(it)?.name } ?: ""
    val exportAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) app.exportPdf(uri, wholeNotebook = true)
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) app.insertImage(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) app.insertCameraPicture()
    }
    val exportOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) app.exportPdf(uri, wholeNotebook = false)
    }
    Surface(tonalElevation = 1.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            TextButton(onClick = { app.closeNotebook() }) { Text(stringResource(R.string.back)) }
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = { app.goToPage(app.pageIndex - 1) }, enabled = app.pageIndex > 0) {
                Text(stringResource(R.string.page_prev))
            }
            Text("${app.pageIndex + 1} / $pageCount")
            TextButton(onClick = { app.goToPage(app.pageIndex + 1) }, enabled = app.pageIndex < pageCount - 1) {
                Text(stringResource(R.string.page_next))
            }
            TextButton(onClick = { app.editor.toggleWritingLock(); app.savePrefs() }) {
                Text(stringResource(if (app.editor.palmConfig.writingLock) R.string.palm_lock_on else R.string.palm_lock_off))
            }
            TextButton(onClick = { app.editor.allowTouchNavigation() }) {
                Text(stringResource(if (app.editor.tempNavActive) R.string.palm_nav_active else R.string.palm_nav_short))
            }
            TextButton(onClick = { showPalm = true }) { Text(stringResource(R.string.palm_title)) }
            TextButton(onClick = { app.addPage() }) { Text(stringResource(R.string.page_add)) }
            TextButton(onClick = { app.deletePage() }) { Text(stringResource(R.string.page_delete)) }
            TextButton(onClick = { app.editor.zoomBy(0.8f) }) { Text("\u2212") }
            Text("${app.editor.zoomPercent}%")
            TextButton(onClick = { app.editor.zoomBy(1.25f) }) { Text("+") }
            TextButton(onClick = { app.editor.fitWidth() }) { Text(stringResource(R.string.fit_width)) }
            TextButton(onClick = { app.editor.fitPage() }) { Text(stringResource(R.string.fit_page)) }
            TextButton(onClick = { pickImage.launch(arrayOf("image/*")) }) { Text(stringResource(R.string.image_insert)) }
            TextButton(onClick = {
                try { takePhoto.launch(app.prepareCameraUri()) } catch (e: Exception) { app.message = null }
            }) { Text(stringResource(R.string.camera)) }
            TextButton(onClick = { exportAll.launch("$name.pdf") }) { Text(stringResource(R.string.pdf_export)) }
            TextButton(onClick = { exportOne.launch("$name-${app.pageIndex + 1}.pdf") }) { Text(stringResource(R.string.pdf_export_page)) }
            Box {
                TextButton(onClick = { paperMenu = true }) { Text(paperLabel(app.editor.paper)) }
                DropdownMenu(expanded = paperMenu, onDismissRequest = { paperMenu = false }) {
                    PaperType.entries.forEach { p ->
                        DropdownMenuItem(
                            text = { Text(paperLabel(p)) },
                            onClick = { app.setPaper(p); paperMenu = false },
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- library

private sealed interface LibDialog {
    data object NewFolder : LibDialog
    data object NewNotebook : LibDialog
    data class Rename(val node: LibraryNode) : LibDialog
    data class Move(val node: LibraryNode) : LibDialog
}

@Composable
private fun LibraryScreen(app: AppModel) {
    var dialog by remember { mutableStateOf<LibDialog?>(null) }
    val importPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) app.importPdf(uri)
    }
    val atRoot = app.currentFolder == null && !app.showTrash && app.query.isBlank()
    val list = if (app.showTrash) app.trashItems() else app.items()
    val title = when {
        app.showTrash -> stringResource(R.string.trash)
        app.currentFolder == null -> stringResource(R.string.root)
        else -> app.breadcrumb()
    }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!atRoot) TextButton(onClick = { app.navigateUp() }) { Text(stringResource(R.string.back)) }
            Text(title, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (!app.showTrash) {
                TextButton(onClick = { dialog = LibDialog.NewNotebook }) { Text(stringResource(R.string.notebook_new)) }
                TextButton(onClick = { dialog = LibDialog.NewFolder }) { Text(stringResource(R.string.folder_new)) }
                TextButton(onClick = { importPdf.launch(arrayOf("application/pdf")) }) { Text(stringResource(R.string.pdf_import)) }
                FilterChip(
                    selected = app.sortByName,
                    onClick = { app.sortByName = !app.sortByName },
                    label = { Text(stringResource(if (app.sortByName) R.string.sort_name else R.string.sort_modified)) },
                )
            } else {
                TextButton(onClick = { app.emptyTrash() }) { Text(stringResource(R.string.empty_trash)) }
            }
            FilterChip(
                selected = app.showTrash,
                onClick = { app.showTrash = !app.showTrash },
                label = { Text(stringResource(R.string.trash)) },
            )
        }
        if (!app.showTrash) {
            OutlinedTextField(
                value = app.query,
                onValueChange = { app.query = it },
                label = { Text(stringResource(R.string.search)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            )
        }
        if (list.isEmpty()) {
            Text(stringResource(R.string.empty), modifier = Modifier.padding(24.dp))
        } else {
            LazyVerticalGrid(columns = GridCells.Adaptive(170.dp), modifier = Modifier.weight(1f)) {
                items(list, key = { it.id }) { node ->
                    NodeCard(app, node, app.showTrash) { dialog = it }
                }
            }
        }
    }

    when (val d = dialog) {
        null -> {}
        LibDialog.NewFolder -> NameDialog(
            title = stringResource(R.string.folder_new),
            initial = stringResource(R.string.default_folder_name),
            onConfirm = { app.createFolder(it); dialog = null },
            onDismiss = { dialog = null },
        )
        LibDialog.NewNotebook -> NameDialog(
            title = stringResource(R.string.notebook_new),
            initial = stringResource(R.string.default_notebook_name),
            onConfirm = { dialog = null; app.createNotebook(it) },
            onDismiss = { dialog = null },
        )
        is LibDialog.Rename -> NameDialog(
            title = stringResource(R.string.rename),
            initial = d.node.name,
            onConfirm = { app.rename(d.node.id, it); dialog = null },
            onDismiss = { dialog = null },
        )
        is LibDialog.Move -> MoveDialog(app, d.node) { dialog = null }
    }
}

@Composable
private fun NodeCard(app: AppModel, node: LibraryNode, trashMode: Boolean, onDialog: (LibDialog) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val hue = (abs(node.id.hashCode()) % 360).toFloat()
    Surface(
        modifier = Modifier
            .padding(6.dp)
            .fillMaxWidth()
            .height(130.dp)
            .clickable(enabled = !trashMode) {
                if (node.type == NodeType.FOLDER) app.openFolder(node.id) else app.openNotebook(node.id)
            },
        shape = RoundedCornerShape(14.dp),
        color = Color.hsv(hue, 0.30f, 0.96f),
        contentColor = Color.Black,
        tonalElevation = 2.dp,
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (node.type == NodeType.FOLDER) "\uD83D\uDCC1" else "\uD83D\uDCD3", fontSize = 26.sp)
                Spacer(Modifier.weight(1f))
                if (node.favorite) Text("\u2605", fontSize = 20.sp)
            }
            Text(node.name, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Box(Modifier.align(Alignment.End)) {
                TextButton(onClick = { menu = true }) { Text("\u22EE", color = Color.Black) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (trashMode) {
                        MenuItem(R.string.restore) { app.restore(node.id); menu = false }
                        MenuItem(R.string.delete_forever) { app.deleteForever(node.id); menu = false }
                    } else {
                        MenuItem(R.string.rename) { onDialog(LibDialog.Rename(node)); menu = false }
                        MenuItem(if (node.favorite) R.string.unfavorite else R.string.favorite) { app.toggleFavorite(node); menu = false }
                        MenuItem(R.string.move) { onDialog(LibDialog.Move(node)); menu = false }
                        MenuItem(R.string.duplicate) { app.duplicate(node.id); menu = false }
                        MenuItem(R.string.move_to_trash) { app.trash(node.id); menu = false }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuItem(label: Int, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(stringResource(label)) }, onClick = onClick)
}

@Composable
private fun NameDialog(title: String, initial: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(stringResource(R.string.name)) },
                singleLine = true,
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun MoveDialog(app: AppModel, node: LibraryNode, onDismiss: () -> Unit) {
    val choices = app.folderChoices(node)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.move)) },
        text = {
            LazyColumn {
                item {
                    TextButton(onClick = { app.move(node.id, null); onDismiss() }) { Text(stringResource(R.string.root)) }
                }
                items(choices, key = { it.id }) { f ->
                    TextButton(onClick = { app.move(node.id, f.id); onDismiss() }) { Text(app.repo.pathName(f.id)) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
