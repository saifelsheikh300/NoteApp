package com.example.handnotes.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.Section
import com.example.handnotes.data.LibraryNode
import com.example.handnotes.data.PageSize
import com.example.handnotes.data.PaperColor
import com.example.handnotes.data.PaperType

@Composable
fun NoteApp(app: AppModel) {
    Column(Modifier.fillMaxSize()) {
        StatusBar(app)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (app.openNotebookId != null) {
                BackHandler { app.closeNotebook() }
                EditorScreen(app)
            } else {
                BackHandler(enabled = app.currentFolder != null || app.section != Section.DOCS || app.query.isNotBlank()) { app.navigateUp() }
                LibraryScreen(app)
            }
        }
    }
}

@Composable
private fun StatusBar(app: AppModel) {
    val msg = app.message
    if (app.busy) {
        Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.working), modifier = Modifier.padding(12.dp))
        }
    } else if (msg != null) {
        Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth().clickable { app.message = null }) {
            Text(msg, modifier = Modifier.padding(12.dp))
        }
    }
}

@Composable
fun paperLabel(p: PaperType): String = stringResource(
    when (p) {
        PaperType.BLANK -> R.string.paper_blank
        PaperType.DOTTED -> R.string.paper_dotted
        PaperType.RULED_NARROW -> R.string.paper_ruled_narrow
        PaperType.RULED -> R.string.paper_ruled
        PaperType.GRID -> R.string.paper_grid
        PaperType.CORNELL -> R.string.paper_cornell
        PaperType.LEGAL -> R.string.paper_legal
    },
)

@Composable
fun sizeLabel(s: PageSize): String = stringResource(
    when (s) {
        PageSize.STANDARD -> R.string.size_standard
        PageSize.A4 -> R.string.size_a4
        PageSize.LETTER -> R.string.size_letter
    },
)

@Composable
fun colorLabel(c: PaperColor): String = stringResource(
    when (c) {
        PaperColor.WHITE -> R.string.color_white
        PaperColor.YELLOW -> R.string.color_yellow
        PaperColor.DARK -> R.string.color_dark
    },
)

@Composable
internal fun NameDialog(title: String, initial: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(stringResource(R.string.name)) },
                singleLine = true,
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
internal fun MoveDialog(app: AppModel, node: LibraryNode, onDismiss: () -> Unit) {
    val choices = app.folderChoices(node)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.move)) },
        text = {
            LazyColumn {
                item {
                    TextButton(onClick = { app.move(node.id, null); onDismiss() }) { Text(stringResource(R.string.root)) }
                }
                items(choices, key = { it.id }) { f ->
                    TextButton(onClick = { app.move(node.id, f.id); onDismiss() }) { Text(app.repo.pathName(f.id)) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
