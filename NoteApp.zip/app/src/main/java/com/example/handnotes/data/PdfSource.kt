package com.example.handnotes.data

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

/**
 * Read-only access to a PDF. Pages are rendered one at a time, on demand, so a big PDF never sits in memory.
 * PdfRenderer allows one open page at a time, hence the synchronized methods.
 */
class PdfSource(file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = PdfRenderer(pfd)

    val pageCount: Int get() = renderer.pageCount

    /** Page sizes in PDF points. */
    @Synchronized
    fun pageSizes(): List<Pair<Float, Float>> =
        (0 until renderer.pageCount).map { i ->
            val page = renderer.openPage(i)
            try { Pair(page.width.toFloat(), page.height.toFloat()) } finally { page.close() }
        }

    @Synchronized
    fun render(index: Int, widthPx: Int): Bitmap {
        val page = renderer.openPage(index)
        try {
            val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            page.close()
        }
    }

    @Synchronized
    fun close() {
        try { renderer.close() } finally { pfd.close() }
    }
}
