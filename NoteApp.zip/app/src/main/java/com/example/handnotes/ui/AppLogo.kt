package com.example.handnotes.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The app logo: a page with handwriting and a pen nib. Same drawing as the launcher icon. */
@Composable
fun AppLogo(modifier: Modifier = Modifier, box: Dp = 44.dp) {
    Canvas(modifier.size(box)) {
        val u = size.minDimension / 108f
        fun path(vararg p: Float): Path {
            val path = Path()
            path.moveTo(p[0] * u, p[1] * u)
            var i = 2
            while (i + 1 < p.size) { path.lineTo(p[i] * u, p[i + 1] * u); i += 2 }
            path.close()
            return path
        }
        drawRoundRect(
            brush = Brush.linearGradient(listOf(Color(0xFF29C4E6), Color(0xFF1565C0)), start = Offset.Zero, end = Offset(size.width, size.height)),
            cornerRadius = CornerRadius(26f * u),
        )
        drawPath(path(40f, 30f, 60f, 30f, 70f, 40f, 70f, 78f, 40f, 78f), Color.White)
        drawPath(path(60f, 30f, 60f, 40f, 70f, 40f), Color(0xFFBFE6F3))
        for (y in floatArrayOf(50f, 58f, 66f)) {
            drawLine(Color(0xFF29C4E6), Offset(46f * u, y * u), Offset(64f * u, y * u), 3f * u, StrokeCap.Round)
        }
        drawPath(path(54f, 80f, 58f, 70f, 76f, 52f, 82f, 58f, 64f, 76f), Color(0xFF0D2B52))
        drawPath(path(54f, 80f, 58f, 70f, 64f, 76f), Color(0xFFFFB300))
    }
}
