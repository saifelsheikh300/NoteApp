package com.example.handnotes.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.Section
import com.example.handnotes.SortMode
import com.example.handnotes.data.LibraryNode
import com.example.handnotes.data.NodeType
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

sealed interface LibDialog {
    data object NewFolder : LibDialog
    data object NewNotebook : LibDialog
    data class Rename(val node: LibraryNode) : LibDialog
    data class Move(val node: LibraryNode) : LibDialog
}

/** A round tappable icon. Used across the library and the editor. */
@Composable
fun IconBtn(icon: Ic, modifier: Modifier = Modifier, tint: Color = Color.White, enabled: Boolean = true, box: Int = 44, onClick: () -> Unit) {
    Box(
        modifier
            .size(box.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { GIcon(icon, if (enabled) tint else tint.copy(alpha = 0.35f)) }
}

@Composable
fun LibraryScreen(app: AppModel) {
    var dialog by remember { mutableStateOf<LibDialog?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    val importPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) app.importPdf(uri)
    }
    val list = app.items()
    val docs = app.section == Section.DOCS

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(Modifier.fillMaxSize().background(Pal.libBg)) {
            Row(Modifier.fillMaxSize()) {
                Sidebar(app)
                Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 24.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                        if (docs && searchOpen) {
                            OutlinedTextField(
                                value = app.query,
                                onValueChange = { app.query = it },
                                singleLine = true,
                                placeholder = { Text(stringResource(R.string.search)) },
                                modifier = Modifier.width(320.dp),
                            )
                            IconBtn(Ic.CLOSE) { searchOpen = false; app.query = "" }
                        } else if (docs) {
                            IconBtn(Ic.SEARCH) { searchOpen = true }
                        }
                        IconBtn(Ic.GEAR) { settingsOpen = true }
                    }
                    TitleRow(
                        app = app,
                        onNotebook = { dialog = LibDialog.NewNotebook },
                        onFolder = { dialog = LibDialog.NewFolder },
                        onImport = { importPdf.launch(arrayOf("application/pdf")) },
                    )
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                    if (list.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                stringResource(
                                    when (app.section) {
                                        Section.FAVORITES -> R.string.favorites_empty
                                        Section.TRASH -> R.string.trash_empty
                                        Section.DOCS -> R.string.docs_empty
                                    },
                                ),
                                color = Pal.dim,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(32.dp),
                            )
                        }
                    } else {
                        LazyVerticalGrid(columns = GridCells.Adaptive(190.dp), modifier = Modifier.fillMaxSize()) {
                            items(list, key = { it.id }) { node -> LibraryItem(app, node) { dialog = it } }
                        }
                    }
                }
            }
            if (settingsOpen) SettingsPanel(app) { settingsOpen = false }
        }
    }

    when (val d = dialog) {
        null -> Unit
        LibDialog.NewFolder -> NameDialog(
            title = stringResource(R.string.folder_new),
            initial = stringResource(R.string.default_folder_name),
            onConfirm = { app.createFolder(it); dialog = null },
            onDismiss = { dialog = null },
        )
        LibDialog.NewNotebook -> NewNotebookDialog(app) { dialog = null }
        is LibDialog.Rename -> NameDialog(
            title = stringResource(R.string.rename),
            initial = d.node.name,
            onConfirm = { app.rename(d.node.id, it); dialog = null },
            onDismiss = { dialog = null },
        )
        is LibDialog.Move -> MoveDialog(app, d.node) { dialog = null }
    }
}

@Composable
private fun Sidebar(app: AppModel) {
    Column(Modifier.width(280.dp).fillMaxHeight().background(Pal.sidebar).padding(16.dp)) {
        Text(
            stringResource(R.string.app_name),
            fontSize = 28.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 28.dp),
        )
        NavItem(Ic.FOLDER, R.string.nav_documents, app.section == Section.DOCS) { app.selectSection(Section.DOCS) }
        NavItem(Ic.STAR, R.string.nav_favorites, app.section == Section.FAVORITES) { app.selectSection(Section.FAVORITES) }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
        Spacer(Modifier.height(12.dp))
        NavItem(Ic.TRASH, R.string.trash, app.section == Section.TRASH) { app.selectSection(Section.TRASH) }
    }
}

@Composable
private fun NavItem(icon: Ic, label: Int, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Pal.selected else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GIcon(icon, Color.White)
        Spacer(Modifier.width(12.dp))
        Text(stringResource(label), fontSize = 17.sp)
    }
}

@Composable
private fun TitleRow(app: AppModel, onNotebook: () -> Unit, onFolder: () -> Unit, onImport: () -> Unit) {
    val inFolder = app.section == Section.DOCS && (app.currentFolder != null || app.query.isNotBlank())
    val title = when {
        app.section == Section.FAVORITES -> stringResource(R.string.nav_favorites)
        app.section == Section.TRASH -> stringResource(R.string.trash)
        app.currentFolder != null -> app.repo.get(app.currentFolder!!)?.name ?: stringResource(R.string.nav_documents)
        else -> stringResource(R.string.nav_documents)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (inFolder) IconBtn(Ic.BACK) { app.navigateUp() }
        Text(title, fontSize = 38.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        when (app.section) {
            Section.DOCS -> {
                NewButton(onNotebook, { app.quickNote() }, onFolder, onImport)
                Spacer(Modifier.width(10.dp))
                SortPill(app)
            }
            Section.TRASH -> PillButton(stringResource(R.string.empty_trash)) { app.emptyTrash() }
            Section.FAVORITES -> Unit
        }
    }
}

@Composable
private fun PillButton(label: String, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Pal.pill).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(label)
    }
}

@Composable
private fun MenuRow(icon: Ic, label: Int, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(stringResource(label)) },
        leadingIcon = { GIcon(icon, LocalContentColor.current, box = 20.dp) },
        onClick = onClick,
    )
}

@Composable
private fun NewButton(onNotebook: () -> Unit, onQuick: () -> Unit, onFolder: () -> Unit, onImport: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(24.dp)).background(Pal.accent).clickable { open = true }.padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GIcon(Ic.PLUS, Color.White, box = 20.dp)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.new_label), color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(6.dp))
            GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            MenuRow(Ic.NOTE, R.string.menu_notebook) { open = false; onNotebook() }
            MenuRow(Ic.NOTE, R.string.quick_note) { open = false; onQuick() }
            MenuRow(Ic.FOLDER, R.string.menu_folder) { open = false; onFolder() }
            MenuRow(Ic.SHARE, R.string.pdf_import) { open = false; onImport() }
        }
    }
}

@Composable
private fun SortPill(app: AppModel) {
    var open by remember { mutableStateOf(false) }
    val label = when (app.sortMode) {
        SortMode.DATE -> R.string.sort_date
        SortMode.NAME -> R.string.sort_name_s
        SortMode.TYPE -> R.string.sort_type
    }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Pal.pill).clickable { open = true }.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(stringResource(label))
            Spacer(Modifier.width(6.dp))
            GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            for ((mode, res) in listOf(SortMode.DATE to R.string.sort_date, SortMode.NAME to R.string.sort_name_s, SortMode.TYPE to R.string.sort_type)) {
                DropdownMenuItem(
                    text = { Text(stringResource(res)) },
                    trailingIcon = { if (app.sortMode == mode) GIcon(Ic.CHECK, LocalContentColor.current, box = 18.dp) },
                    onClick = { app.sortMode = mode; open = false },
                )
            }
        }
    }
}

@Composable
private fun LibraryItem(app: AppModel, node: LibraryNode, onDialog: (LibDialog) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val trash = app.section == Section.TRASH
    val date = remember(node.modifiedAt) { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(node.modifiedAt)) }
    Column(
        Modifier
            .padding(10.dp)
            .fillMaxWidth()
            .clickable(enabled = !trash) {
                if (node.type == NodeType.FOLDER) app.openFolder(node.id) else app.openNotebook(node.id)
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(width = 150.dp, height = 200.dp), contentAlignment = Alignment.Center) {
            if (node.type == NodeType.FOLDER) FolderArt(Modifier.size(width = 160.dp, height = 130.dp))
            else CoverArt(node.cover, Modifier.fillMaxSize())
            if (!trash) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(30.dp).clip(CircleShape).clickable { app.toggleFavorite(node) },
                    contentAlignment = Alignment.Center,
                ) {
                    GIcon(if (node.favorite) Ic.STAR_FILLED else Ic.STAR, if (node.favorite) Pal.star else Color(0xCCDDDDDD), box = 20.dp)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(node.name, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.weight(1f, fill = false))
            Box {
                Box(Modifier.size(32.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                    GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (trash) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.restore)) }, onClick = { app.restore(node.id); menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.delete_forever)) }, onClick = { app.deleteForever(node.id); menu = false })
                    } else {
                        DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, onClick = { menu = false; onDialog(LibDialog.Rename(node)) })
                        DropdownMenuItem(
                            text = { Text(stringResource(if (node.favorite) R.string.unfavorite else R.string.favorite)) },
                            onClick = { app.toggleFavorite(node); menu = false },
                        )
                        DropdownMenuItem(text = { Text(stringResource(R.string.move)) }, onClick = { menu = false; onDialog(LibDialog.Move(node)) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.duplicate)) }, onClick = { app.duplicate(node.id); menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.move_to_trash)) }, onClick = { app.trash(node.id); menu = false })
                    }
                }
            }
        }
        Text(date, color = Pal.dim, fontSize = 12.sp)
    }
}

@Composable
private fun SettingsPanel(app: AppModel, onClose: () -> Unit) {
    var calibrating by remember { mutableStateOf(false) }
    val ed = app.editor
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onClose))
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterEnd) {
        Surface(Modifier.width(460.dp).fillMaxHeight(), color = Pal.sidebar, contentColor = Color.White) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.settings), fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconBtn(Ic.CLOSE, onClick = onClose)
                }
                Text(stringResource(R.string.pen_gestures), color = Pal.dim)
                SwitchRow(stringResource(R.string.scribble_erase), null, ed.scribbleEnabled) { ed.scribbleEnabled = it; app.savePrefs() }
                SwitchRow(stringResource(R.string.erase_shapes), stringResource(R.string.erase_shapes_desc), ed.scribbleErasesHighlighter) {
                    ed.scribbleErasesHighlighter = it; app.savePrefs()
                }
                SwitchRow(stringResource(R.string.draw_and_hold), null, ed.shapeSnap) { ed.shapeSnap = it; app.savePrefs() }
                Text(
                    stringResource(R.string.stabilization) + " " + (ed.smoothing / 0.9f * 100f).roundToInt() + "%",
                    color = Pal.dim,
                )
                Slider(
                    value = ed.smoothing,
                    onValueChange = { ed.smoothing = it },
                    onValueChangeFinished = { app.savePrefs() },
                    valueRange = 0f..0.9f,
                )
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                Text(stringResource(R.string.palm_title), color = Pal.dim)
                PalmSettingsContent(app) { calibrating = true }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                Text(stringResource(R.string.about), color = Pal.dim)
                Text(stringResource(R.string.about_text), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (calibrating) PalmCalibrationDialog(app) { calibrating = false }
}

@Composable
internal fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (desc != null) Text(desc, color = Pal.dim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
