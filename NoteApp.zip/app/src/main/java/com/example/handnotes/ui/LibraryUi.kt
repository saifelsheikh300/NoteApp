package com.example.handnotes.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.handnotes.AppModel
import com.example.handnotes.R
import com.example.handnotes.Section
import com.example.handnotes.SortMode
import com.example.handnotes.data.LibraryNode
import com.example.handnotes.data.NodeType
import com.example.handnotes.data.PageTemplate
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

sealed interface LibDialog {
    data object NewFolder : LibDialog
    data object NewNotebook : LibDialog
    data class Rename(val node: LibraryNode) : LibDialog
    data class Move(val node: LibraryNode) : LibDialog
    data class RenameTemplate(val t: PageTemplate) : LibDialog
    data class UseTemplate(val t: PageTemplate) : LibDialog
}

/** A round tappable icon. Used across the library and the editor. */
@Composable
fun IconBtn(icon: Ic, modifier: Modifier = Modifier, tint: Color = Color.White, enabled: Boolean = true, box: Int = 44, onClick: () -> Unit) {
    Box(
        modifier.size(box.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { GIcon(icon, if (enabled) tint else tint.copy(alpha = 0.35f)) }
}

@Composable
fun LibraryScreen(app: AppModel) {
    var dialog by remember { mutableStateOf<LibDialog?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var plusMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    val importPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) app.importPdf(uri)
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) app.quickNoteWithPhoto()
    }
    val list = app.items()
    val templates = app.templateList()
    val sec = app.section
    val title = when (sec) {
        Section.ALL -> stringResource(R.string.nav_all)
        Section.STARRED -> stringResource(R.string.nav_starred)
        Section.UNFILED -> stringResource(R.string.nav_unfiled)
        Section.TEMPLATES -> stringResource(R.string.nav_templates)
        Section.TRASH -> stringResource(R.string.trash)
        Section.FOLDER -> app.currentFolder?.let { app.repo.get(it)?.name } ?: stringResource(R.string.nav_all)
    }
    val canCreate = sec == Section.ALL || sec == Section.UNFILED || sec == Section.FOLDER

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(Modifier.fillMaxSize().background(Pal.libBg)) {
            Row(Modifier.fillMaxSize()) {
                Sidebar(app, onNewFolder = { dialog = LibDialog.NewFolder }, onRenameFolder = { dialog = LibDialog.Rename(it) })
                Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 24.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (sec == Section.FOLDER) IconBtn(Ic.BACK) { app.navigateUp() }
                        Text(
                            title,
                            fontFamily = FontFamily.Serif,
                            fontSize = 30.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        if (searchOpen) {
                            OutlinedTextField(
                                value = app.query,
                                onValueChange = { app.query = it },
                                singleLine = true,
                                placeholder = { Text(stringResource(R.string.search)) },
                                modifier = Modifier.width(260.dp),
                            )
                        }
                        if (canCreate) {
                            Box {
                                Box(
                                    Modifier.size(40.dp).clip(CircleShape).background(Pal.accent).clickable { plusMenu = true },
                                    contentAlignment = Alignment.Center,
                                ) { GIcon(Ic.PLUS, Color.White, box = 22.dp) }
                                PlusMenu(
                                    expanded = plusMenu,
                                    onDismiss = { plusMenu = false },
                                    onQuick = { app.quickNote() },
                                    onNotebook = { dialog = LibDialog.NewNotebook },
                                    onImport = { importPdf.launch(arrayOf("application/pdf")) },
                                    onFolder = { dialog = LibDialog.NewFolder },
                                    onTemplates = { app.selectSection(Section.TEMPLATES) },
                                    onPhoto = { try { takePhoto.launch(app.prepareCameraUri()) } catch (e: Exception) { /* no camera app */ } },
                                )
                            }
                        }
                        IconBtn(if (searchOpen) Ic.CLOSE else Ic.SEARCH) {
                            searchOpen = !searchOpen
                            if (!searchOpen) app.query = ""
                        }
                        Box {
                            IconBtn(Ic.MORE) { moreMenu = true }
                            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                                for ((mode, res) in listOf(SortMode.DATE to R.string.sort_date, SortMode.NAME to R.string.sort_name_s, SortMode.TYPE to R.string.sort_type)) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(res)) },
                                        trailingIcon = { if (app.sortMode == mode) GIcon(Ic.CHECK, LocalContentColor.current, box = 18.dp) },
                                        onClick = { app.sortMode = mode; moreMenu = false },
                                    )
                                }
                                DropdownMenuItem(text = { Text(stringResource(R.string.settings)) }, onClick = { moreMenu = false; settingsOpen = true })
                            }
                        }
                    }
                    if (canCreate && app.query.isBlank()) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            ActionTile(Ic.NOTE, Color(0xFFE8C547), R.string.quick_note, Modifier.weight(1f)) { app.quickNote() }
                            ActionTile(Ic.NOTE, Pal.teal, R.string.menu_notebook, Modifier.weight(1f)) { dialog = LibDialog.NewNotebook }
                            ActionTile(Ic.SHARE, Color(0xFF5AA0FF), R.string.import_file, Modifier.weight(1f)) {
                                importPdf.launch(arrayOf("application/pdf"))
                            }
                        }
                    }
                    when {
                        sec == Section.TEMPLATES -> TemplatesGrid(app, templates) { dialog = it }
                        list.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                stringResource(
                                    when (sec) {
                                        Section.STARRED -> R.string.favorites_empty
                                        Section.TRASH -> R.string.trash_empty
                                        else -> R.string.docs_empty
                                    },
                                ),
                                color = Pal.dim,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(32.dp),
                            )
                        }
                        else -> LazyVerticalGrid(columns = GridCells.Adaptive(190.dp), modifier = Modifier.fillMaxSize()) {
                            items(list, key = { it.id }) { node -> LibraryItem(app, node) { dialog = it } }
                        }
                    }
                }
            }
            if (settingsOpen) SettingsPanel(app) { settingsOpen = false }
        }
    }

    when (val d = dialog) {
        null -> Unit
        LibDialog.NewFolder -> NameDialog(
            title = stringResource(R.string.folder_new),
            initial = stringResource(R.string.default_folder_name),
            onConfirm = { app.createFolder(it); dialog = null },
            onDismiss = { dialog = null },
        )
        LibDialog.NewNotebook -> NewNotebookDialog(app) { dialog = null }
        is LibDialog.Rename -> NameDialog(
            title = stringResource(R.string.rename),
            initial = d.node.name,
            onConfirm = { app.rename(d.node.id, it); dialog = null },
            onDismiss = { dialog = null },
        )
        is LibDialog.Move -> MoveDialog(app, d.node) { dialog = null }
        is LibDialog.RenameTemplate -> NameDialog(
            title = stringResource(R.string.rename),
            initial = d.t.name,
            onConfirm = { app.renameTemplate(d.t.id, it); dialog = null },
            onDismiss = { dialog = null },
        )
        is LibDialog.UseTemplate -> NameDialog(
            title = stringResource(R.string.use_template),
            initial = d.t.name,
            onConfirm = { app.newNotebookFromTemplate(d.t, it); dialog = null },
            onDismiss = { dialog = null },
        )
    }
}

// ---------------------------------------------------------------- sidebar

@Composable
private fun Sidebar(app: AppModel, onNewFolder: () -> Unit, onRenameFolder: (LibraryNode) -> Unit) {
    var foldersOpen by remember { mutableStateOf(true) }
    Column(
        Modifier.width(280.dp).fillMaxHeight().background(Pal.sidebar).verticalScroll(rememberScrollState()).padding(16.dp),
    ) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            AppLogo(box = 40.dp)
            Spacer(Modifier.width(12.dp))
            Text(stringResource(R.string.app_name), fontFamily = FontFamily.Serif, fontSize = 26.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NavTile(Ic.HOME, Color(0xFFE07050), R.string.nav_all, app.section == Section.ALL, Modifier.weight(1f)) { app.selectSection(Section.ALL) }
            NavTile(Ic.STAR, Color(0xFFE0A030), R.string.nav_starred, app.section == Section.STARRED, Modifier.weight(1f)) { app.selectSection(Section.STARRED) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NavTile(Ic.INBOX, Pal.teal, R.string.nav_unfiled, app.section == Section.UNFILED, Modifier.weight(1f)) { app.selectSection(Section.UNFILED) }
            NavTile(Ic.TRASH, Color(0xFF9E9E9E), R.string.trash, app.section == Section.TRASH, Modifier.weight(1f)) { app.selectSection(Section.TRASH) }
        }
        Spacer(Modifier.height(10.dp))
        NavTile(Ic.TEMPLATE, Color(0xFFE0A030), R.string.nav_templates, app.section == Section.TEMPLATES, Modifier.fillMaxWidth()) {
            app.selectSection(Section.TEMPLATES)
        }
        Spacer(Modifier.height(24.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { foldersOpen = !foldersOpen }.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(stringResource(R.string.folders_title), fontFamily = FontFamily.Serif, fontSize = 22.sp, modifier = Modifier.weight(1f))
            GIcon(Ic.CHEVRON, Pal.teal, box = 18.dp)
        }
        if (foldersOpen) {
            for (f in app.topFolders()) FolderRow(app, f, onRenameFolder)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onNewFolder).padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(26.dp).border(2.dp, Pal.teal, CircleShape), contentAlignment = Alignment.Center) {
                    GIcon(Ic.PLUS, Pal.teal, box = 16.dp)
                }
                Spacer(Modifier.width(12.dp))
                Text(stringResource(R.string.folder_new), color = Pal.teal, fontSize = 17.sp)
            }
        }
    }
}

@Composable
private fun NavTile(icon: Ic, iconColor: Color, label: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape).background(Pal.tile).border(if (selected) 2.dp else 0.dp, if (selected) Pal.accent else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(14.dp),
    ) {
        GIcon(icon, iconColor)
        Spacer(Modifier.height(10.dp))
        Text(stringResource(label), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun FolderRow(app: AppModel, f: LibraryNode, onRename: (LibraryNode) -> Unit) {
    val selected = app.section == Section.FOLDER && app.currentFolder == f.id
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(26.dp))
            .background(if (selected) Pal.folderSel else Color.Transparent)
            .clickable { app.selectSection(Section.FOLDER, f.id) }
            .padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GIcon(Ic.FOLDER, Color.White, box = 22.dp)
        Spacer(Modifier.width(12.dp))
        Text(f.name, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        val count = app.notebookCount(f.id)
        if (count > 0) Text(count.toString(), fontSize = 15.sp, modifier = Modifier.padding(horizontal = 6.dp))
        if (selected) {
            Box {
                Box(Modifier.size(30.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                    GIcon(Ic.MORE, Color.White, box = 18.dp)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, onClick = { menu = false; onRename(f) })
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.move_to_trash)) },
                        onClick = { menu = false; app.trash(f.id); app.selectSection(Section.ALL) },
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- main area

@Composable
private fun ActionTile(icon: Ic, color: Color, label: Int, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(80.dp).clip(RoundedCornerShape(18.dp)).background(Pal.tile).clickable(onClick = onClick).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            GIcon(icon, color)
        }
        Spacer(Modifier.width(14.dp))
        Text(stringResource(label), fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun MenuTile(icon: Ic, color: Color, title: Int, desc: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Pal.tile).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            GIcon(icon, color)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(stringResource(title), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(stringResource(desc), color = Pal.dim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MenuLine(icon: Ic, label: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GIcon(icon, Pal.teal, box = 22.dp)
        Spacer(Modifier.width(16.dp))
        Text(stringResource(label), fontSize = 17.sp)
    }
}

@Composable
private fun PlusMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onQuick: () -> Unit,
    onNotebook: () -> Unit,
    onImport: () -> Unit,
    onFolder: () -> Unit,
    onTemplates: () -> Unit,
    onPhoto: () -> Unit,
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss, modifier = Modifier.width(360.dp).background(Pal.sidebar)) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            MenuTile(Ic.NOTE, Color(0xFFE8C547), R.string.quick_note, R.string.quick_note_desc) { onDismiss(); onQuick() }
            MenuTile(Ic.NOTE, Pal.teal, R.string.menu_new_notebook, R.string.new_notebook_desc) { onDismiss(); onNotebook() }
            MenuTile(Ic.SHARE, Color(0xFF5AA0FF), R.string.import_file, R.string.import_desc) { onDismiss(); onImport() }
            Box(Modifier.fillMaxWidth().padding(vertical = 4.dp).height(1.dp).background(Color(0x22FFFFFF)))
            MenuLine(Ic.FOLDER, R.string.folder_new) { onDismiss(); onFolder() }
            MenuLine(Ic.TEMPLATE, R.string.nav_templates) { onDismiss(); onTemplates() }
            MenuLine(Ic.CAMERA, R.string.take_photo) { onDismiss(); onPhoto() }
        }
    }
}

@Composable
private fun LibraryItem(app: AppModel, node: LibraryNode, onDialog: (LibDialog) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val trash = app.section == Section.TRASH
    val date = remember(node.modifiedAt) { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(node.modifiedAt)) }
    Column(
        Modifier.padding(10.dp).fillMaxWidth().clickable(enabled = !trash) {
            if (node.type == NodeType.FOLDER) app.openFolder(node.id) else app.openNotebook(node.id)
        },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(width = 150.dp, height = 200.dp), contentAlignment = Alignment.Center) {
            if (node.type == NodeType.FOLDER) FolderArt(Modifier.size(width = 160.dp, height = 130.dp))
            else CoverArt(node.cover, Modifier.fillMaxSize())
            if (!trash) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(30.dp).clip(CircleShape).clickable { app.toggleFavorite(node) },
                    contentAlignment = Alignment.Center,
                ) { GIcon(if (node.favorite) Ic.STAR_FILLED else Ic.STAR, if (node.favorite) Pal.star else Color(0xCCDDDDDD), box = 20.dp) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(node.name, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.weight(1f, fill = false))
            Box {
                Box(Modifier.size(32.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                    GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (trash) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.restore)) }, onClick = { app.restore(node.id); menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.delete_forever)) }, onClick = { app.deleteForever(node.id); menu = false })
                    } else {
                        DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, onClick = { menu = false; onDialog(LibDialog.Rename(node)) })
                        DropdownMenuItem(
                            text = { Text(stringResource(if (node.favorite) R.string.unfavorite else R.string.favorite)) },
                            onClick = { app.toggleFavorite(node); menu = false },
                        )
                        DropdownMenuItem(text = { Text(stringResource(R.string.move)) }, onClick = { menu = false; onDialog(LibDialog.Move(node)) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.duplicate)) }, onClick = { app.duplicate(node.id); menu = false })
                        DropdownMenuItem(text = { Text(stringResource(R.string.move_to_trash)) }, onClick = { app.trash(node.id); menu = false })
                    }
                }
            }
        }
        Text(date, color = Pal.dim, fontSize = 12.sp)
    }
}

@Composable
private fun TemplatesGrid(app: AppModel, templates: List<PageTemplate>, onDialog: (LibDialog) -> Unit) {
    if (templates.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.templates_empty), color = Pal.dim, textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
        }
        return
    }
    LazyVerticalGrid(columns = GridCells.Adaptive(190.dp), modifier = Modifier.fillMaxSize()) {
        items(templates, key = { it.id }) { t ->
            var menu by remember { mutableStateOf(false) }
            Column(Modifier.padding(10.dp).clickable { onDialog(LibDialog.UseTemplate(t)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(150.dp).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(6.dp)).padding(3.dp)) {
                    PaperThumb(t.paper, t.paperColor, t.size, t.landscape, Modifier.fillMaxWidth(), t.rtl, t.content)
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.name, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.weight(1f, fill = false))
                    Box {
                        Box(Modifier.size(32.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                            GIcon(Ic.CHEVRON, Color.White, box = 16.dp)
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text(stringResource(R.string.use_template)) }, onClick = { menu = false; onDialog(LibDialog.UseTemplate(t)) })
                            DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, onClick = { menu = false; onDialog(LibDialog.RenameTemplate(t)) })
                            DropdownMenuItem(text = { Text(stringResource(R.string.duplicate)) }, onClick = { menu = false; app.duplicateTemplate(t.id) })
                            DropdownMenuItem(text = { Text(stringResource(R.string.delete_forever)) }, onClick = { menu = false; app.deleteTemplate(t.id) })
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- settings

@Composable
private fun SettingsPanel(app: AppModel, onClose: () -> Unit) {
    var calibrating by remember { mutableStateOf(false) }
    val ed = app.editor
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onClose))
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterEnd) {
        Surface(Modifier.width(460.dp).fillMaxHeight(), color = Pal.sidebar, contentColor = Color.White) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.settings), fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconBtn(Ic.CLOSE, onClick = onClose)
                }
                Text(stringResource(R.string.pen_gestures), color = Pal.dim)
                SwitchRow(stringResource(R.string.scribble_erase), null, ed.scribbleEnabled) { ed.scribbleEnabled = it; app.savePrefs() }
                Text(stringResource(R.string.scribble_sensitivity) + " " + (ed.scribbleSensitivity * 100f).roundToInt() + "%", color = Pal.dim)
                Slider(value = ed.scribbleSensitivity, onValueChange = { ed.scribbleSensitivity = it }, onValueChangeFinished = { app.savePrefs() })
                Text(stringResource(R.string.scribble_sensitivity_desc), color = Pal.dim, fontSize = 12.sp)
                SwitchRow(stringResource(R.string.erase_shapes), stringResource(R.string.erase_shapes_desc), ed.scribbleErasesHighlighter) {
                    ed.scribbleErasesHighlighter = it; app.savePrefs()
                }
                SwitchRow(stringResource(R.string.draw_and_hold), null, ed.shapeSnap) { ed.shapeSnap = it; app.savePrefs() }
                SwitchRow(stringResource(R.string.swipe_flip), stringResource(R.string.swipe_flip_desc), ed.swipeFlip) { ed.swipeFlip = it; app.savePrefs() }
                Text(stringResource(R.string.stabilization) + " " + (ed.smoothing / 0.9f * 100f).roundToInt() + "%", color = Pal.dim)
                Slider(value = ed.smoothing, onValueChange = { ed.smoothing = it }, onValueChangeFinished = { app.savePrefs() }, valueRange = 0f..0.9f)
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                Text(stringResource(R.string.palm_title), color = Pal.dim)
                PalmSettingsContent(app) { calibrating = true }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x22FFFFFF)))
                Text(stringResource(R.string.about), color = Pal.dim)
                Text(stringResource(R.string.about_text), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (calibrating) PalmCalibrationDialog(app) { calibrating = false }
}

@Composable
internal fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (desc != null) Text(desc, color = Pal.dim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
