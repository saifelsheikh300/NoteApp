package com.example.handnotes.engine

/** The drawable content of one page. */
class PageDoc {
    val strokes: MutableList<InkStroke> = mutableListOf()
    val images: MutableList<ImageObject> = mutableListOf()
}

/** Undoable action. Commands store only what changed, never bitmap snapshots. */
interface Command {
    fun apply(doc: PageDoc)
    fun revert(doc: PageDoc)
}

/** Removes some strokes and adds others. Covers drawing, erasing, splitting and clearing. */
class EditStrokesCommand(
    private val removed: List<InkStroke>,
    private val added: List<InkStroke>,
) : Command {
    private var removedIndices: List<Int> = emptyList()
    private var removedInOrder: List<InkStroke> = emptyList()

    override fun apply(doc: PageDoc) {
        val ids = removed.mapTo(HashSet()) { it.id }
        val found = doc.strokes.withIndex().filter { it.value.id in ids }
        removedIndices = found.map { it.index }
        removedInOrder = found.map { it.value }
        doc.strokes.removeAll { it.id in ids }
        doc.strokes.addAll(added)
    }

    override fun revert(doc: PageDoc) {
        val ids = added.mapTo(HashSet()) { it.id }
        doc.strokes.removeAll { it.id in ids }
        for (k in removedIndices.indices) {
            doc.strokes.add(minOf(removedIndices[k], doc.strokes.size), removedInOrder[k])
        }
    }
}

/** Adds and/or removes pictures. */
class EditImagesCommand(
    private val removed: List<ImageObject>,
    private val added: List<ImageObject>,
) : Command {
    private var removedIndices: List<Int> = emptyList()
    private var removedInOrder: List<ImageObject> = emptyList()

    override fun apply(doc: PageDoc) {
        val ids = removed.mapTo(HashSet()) { it.id }
        val found = doc.images.withIndex().filter { it.value.id in ids }
        removedIndices = found.map { it.index }
        removedInOrder = found.map { it.value }
        doc.images.removeAll { it.id in ids }
        doc.images.addAll(added)
    }

    override fun revert(doc: PageDoc) {
        val ids = added.mapTo(HashSet()) { it.id }
        doc.images.removeAll { it.id in ids }
        for (k in removedIndices.indices) {
            doc.images.add(minOf(removedIndices[k], doc.images.size), removedInOrder[k])
        }
    }
}

/** Swaps pictures for changed versions (move, resize, rotate). */
class ReplaceImagesCommand(
    private val before: List<ImageObject>,
    private val after: List<ImageObject>,
) : Command {
    private fun swap(doc: PageDoc, to: List<ImageObject>) {
        val byId = to.associateBy { it.id }
        for (i in doc.images.indices) {
            val r = byId[doc.images[i].id]
            if (r != null) doc.images[i] = r
        }
    }

    override fun apply(doc: PageDoc) = swap(doc, after)
    override fun revert(doc: PageDoc) = swap(doc, before)
}

/** Several commands undone and redone as one step. */
class CompositeCommand(private val parts: List<Command>) : Command {
    override fun apply(doc: PageDoc) { for (c in parts) c.apply(doc) }
    override fun revert(doc: PageDoc) { for (c in parts.asReversed()) c.revert(doc) }
}

/** Swaps strokes for changed versions with the same ids (move, resize, rotate). Keeps drawing order. */
class ReplaceStrokesCommand(
    private val before: List<InkStroke>,
    private val after: List<InkStroke>,
) : Command {
    private fun swap(doc: PageDoc, to: List<InkStroke>) {
        val byId = to.associateBy { it.id }
        for (i in doc.strokes.indices) {
            val r = byId[doc.strokes[i].id]
            if (r != null) doc.strokes[i] = r
        }
    }

    override fun apply(doc: PageDoc) = swap(doc, after)
    override fun revert(doc: PageDoc) = swap(doc, before)
}

class History(private val doc: PageDoc, private val limit: Int = 100_000) {
    private val undoStack = ArrayDeque<Command>()
    private val redoStack = ArrayDeque<Command>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun execute(cmd: Command) {
        cmd.apply(doc)
        undoStack.addLast(cmd)
        if (undoStack.size > limit) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo(): Boolean {
        val cmd = undoStack.removeLastOrNull() ?: return false
        cmd.revert(doc)
        redoStack.addLast(cmd)
        return true
    }

    fun redo(): Boolean {
        val cmd = redoStack.removeLastOrNull() ?: return false
        cmd.apply(doc)
        undoStack.addLast(cmd)
        return true
    }
}
