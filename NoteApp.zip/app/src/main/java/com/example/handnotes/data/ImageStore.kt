package com.example.handnotes.data

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max

/**
 * Pictures used in notes. One shared folder, so copy/paste and duplicate never have to copy files.
 * Imported pictures are shrunk to [MAX_SIDE] pixels and rotated upright according to their EXIF data.
 */
class ImageStore(private val dir: File) {
    init { dir.mkdirs() }

    fun file(name: String): File = File(dir, name)

    fun load(name: String): Bitmap? = BitmapFactory.decodeFile(file(name).path)

    /** Returns (stored file name, width, height) or null if the picture cannot be read. */
    fun import(resolver: ContentResolver, uri: Uri): Triple<String, Int, Int>? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val s1 = resolver.openInputStream(uri) ?: return null
        s1.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val s2 = resolver.openInputStream(uri) ?: return null
        var bmp = s2.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val rotation = exifRotation(resolver, uri)
        val longest = max(bmp.width, bmp.height)
        val factor = if (longest > MAX_SIDE) MAX_SIDE.toFloat() / longest else 1f
        val m = Matrix()
        if (factor != 1f) m.postScale(factor, factor)
        if (rotation != 0f) m.postRotate(rotation)
        if (!m.isIdentity) {
            val fixed = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (fixed !== bmp) bmp.recycle()
            bmp = fixed
        }

        val png = bmp.hasAlpha()
        val name = UUID.randomUUID().toString() + if (png) ".png" else ".jpg"
        FileOutputStream(file(name)).use {
            bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 90, it)
        }
        val result = Triple(name, bmp.width, bmp.height)
        bmp.recycle()
        return result
    }

    private fun exifRotation(resolver: ContentResolver, uri: Uri): Float =
        try {
            resolver.openInputStream(uri)?.use { stream ->
                when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }

    companion object {
        const val MAX_SIDE = 1600
    }
}
