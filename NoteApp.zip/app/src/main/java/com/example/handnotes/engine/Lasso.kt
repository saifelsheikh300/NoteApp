package com.example.handnotes.engine

import java.util.UUID
import kotlin.math.cos
import kotlin.math.sin

/** Selection by polygon, and the transforms applied to selected strokes. Pure Kotlin. */
object Lasso {
    fun contains(poly: List<Pt>, x: Float, y: Float): Boolean {
        var inside = false
        var j = poly.size - 1
        for (i in poly.indices) {
            val pi = poly[i]
            val pj = poly[j]
            if ((pi.y > y) != (pj.y > y) && x < (pj.x - pi.x) * (y - pi.y) / (pj.y - pi.y) + pi.x) inside = !inside
            j = i
        }
        return inside
    }

    /** Strokes with at least [coverage] of their points inside [polygon]. Returns their ids. */
    fun select(strokes: List<InkStroke>, polygon: List<Pt>, coverage: Float = 0.5f): Set<String> {
        if (polygon.size < 3) return emptySet()
        val area = Bounds.of(polygon)
        if (area.diagonal < MIN_LASSO_SIZE) return emptySet()
        val out = HashSet<String>()
        for (s in strokes) {
            if (s.points.isEmpty() || !s.bounds.intersects(area)) continue
            val inside = s.points.count { contains(polygon, it.x, it.y) }
            if (inside.toFloat() / s.points.size >= coverage) out.add(s.id)
        }
        return out
    }

    /** Rectangle spanning the first and last point of a drag. */
    fun rect(points: List<Pt>): List<Pt> {
        if (points.size < 2) return emptyList()
        val a = points.first()
        val b = points.last()
        return listOf(Pt(a.x, a.y), Pt(b.x, a.y), Pt(b.x, b.y), Pt(a.x, b.y))
    }

    private const val MIN_LASSO_SIZE = 12f
}

/** Geometry changes for strokes. The stroke id is kept, so undo can swap them back. */
object StrokeTransform {
    fun translate(s: InkStroke, dx: Float, dy: Float): InkStroke =
        s.copy(points = s.points.map { it.copy(x = it.x + dx, y = it.y + dy) })

    fun scale(s: InkStroke, f: Float, cx: Float, cy: Float): InkStroke =
        s.copy(
            points = s.points.map { it.copy(x = cx + (it.x - cx) * f, y = cy + (it.y - cy) * f) },
            width = s.width * f,
        )

    fun rotate(s: InkStroke, radians: Float, cx: Float, cy: Float): InkStroke {
        val c = cos(radians)
        val sn = sin(radians)
        return s.copy(
            points = s.points.map {
                val x = it.x - cx
                val y = it.y - cy
                it.copy(x = cx + x * c - y * sn, y = cy + x * sn + y * c)
            },
        )
    }

    /** Same strokes with new ids, shifted by (dx, dy). Used by paste and duplicate. */
    fun clone(strokes: List<InkStroke>, dx: Float, dy: Float): List<InkStroke> =
        strokes.map { translate(it, dx, dy).copy(id = UUID.randomUUID().toString()) }
}
