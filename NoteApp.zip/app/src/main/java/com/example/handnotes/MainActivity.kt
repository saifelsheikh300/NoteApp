package com.example.handnotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import com.example.handnotes.ui.NoteApp

class MainActivity : ComponentActivity() {
    private lateinit var app: AppModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = AppModel(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                NoteApp(app)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        app.flushAndWait()
    }
}
