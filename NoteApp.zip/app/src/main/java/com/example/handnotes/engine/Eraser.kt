package com.example.handnotes.engine

import kotlin.math.hypot
import kotlin.math.max

/** What an erase action changes: strokes to remove and replacement pieces to add. */
data class EraseResult(val removed: List<InkStroke>, val added: List<InkStroke>) {
    val isEmpty: Boolean get() = removed.isEmpty() && added.isEmpty()
}

object Eraser {
    private fun nearPath(x: Float, y: Float, path: List<Pt>, r: Float): Boolean {
        if (path.size == 1) return hypot(x - path[0].x, y - path[0].y) <= r
        for (i in 1 until path.size) {
            if (Geometry.distToSegment(x, y, path[i - 1], path[i]) <= r) return true
        }
        return false
    }

    /** Stroke eraser: removes every stroke touched by [path]. */
    fun eraseStrokes(
        strokes: List<InkStroke>,
        path: List<Pt>,
        radius: Float,
        filter: (InkStroke) -> Boolean = { true },
    ): EraseResult {
        if (path.isEmpty()) return EraseResult(emptyList(), emptyList())
        val area = Bounds.of(path).inflate(radius)
        val hit = strokes.filter { s ->
            filter(s) &&
                s.bounds.inflate(s.width / 2f).intersects(area) &&
                Geometry.densify(s.points, max(radius / 2f, 1f))
                    .any { p -> nearPath(p.x, p.y, path, radius + s.width / 2f) }
        }
        return EraseResult(hit, emptyList())
    }

    /** Segment eraser: cuts away only the touched parts, splitting strokes where needed. */
    fun eraseSegments(
        strokes: List<InkStroke>,
        path: List<Pt>,
        radius: Float,
        filter: (InkStroke) -> Boolean = { true },
    ): EraseResult {
        if (path.isEmpty()) return EraseResult(emptyList(), emptyList())
        val area = Bounds.of(path).inflate(radius)
        val removed = ArrayList<InkStroke>()
        val added = ArrayList<InkStroke>()
        for (s in strokes) {
            if (!filter(s) || !s.bounds.inflate(s.width / 2f).intersects(area)) continue
            val dense = Geometry.densify(s.points, max(radius / 2f, 1f))
            val pieces = ArrayList<List<Pt>>()
            var current = ArrayList<Pt>()
            var touched = false
            for (p in dense) {
                if (nearPath(p.x, p.y, path, radius + s.width / 2f)) {
                    touched = true
                    if (current.isNotEmpty()) { pieces.add(current); current = ArrayList() }
                } else {
                    current.add(p)
                }
            }
            if (current.isNotEmpty()) pieces.add(current)
            if (!touched) continue
            removed.add(s)
            for (piece in pieces) added.add(s.copy(id = java.util.UUID.randomUUID().toString(), points = piece))
        }
        return EraseResult(removed, added)
    }
}
