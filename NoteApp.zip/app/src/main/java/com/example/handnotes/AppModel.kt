package com.example.handnotes

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import com.example.handnotes.data.ImageStore
import com.example.handnotes.data.LibraryNode
import com.example.handnotes.data.LibraryRepository
import com.example.handnotes.data.NodeType
import com.example.handnotes.data.NotebookMeta
import com.example.handnotes.data.PageInfo
import com.example.handnotes.data.PageSize
import com.example.handnotes.data.PaperColor
import com.example.handnotes.data.PaperType
import com.example.handnotes.data.dims
import com.example.handnotes.engine.Calibration
import com.example.handnotes.engine.CalibrationQuality
import com.example.handnotes.engine.PalmConfig
import com.example.handnotes.engine.SizeUnit
import com.example.handnotes.data.PdfExporter
import com.example.handnotes.data.PdfSource
import com.example.handnotes.engine.PageContent
import com.example.handnotes.engine.PageSpec
import com.example.handnotes.ui.NoteState
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.Executors

enum class Section { DOCS, FAVORITES, TRASH }

enum class SortMode { DATE, NAME, TYPE }

/** Screen-level state: which folder/notebook/page is open, PDF import/export, and autosave. */
class AppModel(context: Context) {
    private val appContext = context.applicationContext
    val repo = LibraryRepository(File(appContext.filesDir, "notes"))
    val images = ImageStore(File(appContext.filesDir, "images"))
    val editor = NoteState()
    private val requestedImages = HashSet<String>()
    private var cameraUri: Uri? = null

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "notes-work").apply { isDaemon = true } }
    private val saveRunnable = Runnable { flush() }
    private var dirty = false

    private var pdf: PdfSource? = null
    private var renderToken = 0

    var currentFolder by mutableStateOf<String?>(null)
    var section by mutableStateOf(Section.DOCS)
    var query by mutableStateOf("")
    var sortMode by mutableStateOf(SortMode.DATE)

    /** True while a PDF import or export is running. */
    var busy by mutableStateOf(false)
        private set

    /** Result text for the user (success or failure). */
    var message by mutableStateOf<String?>(null)

    /** Bumped after any library change so lists recompose. */
    var libraryRevision by mutableIntStateOf(0)
        private set

    var openNotebookId by mutableStateOf<String?>(null)
        private set
    var meta by mutableStateOf<NotebookMeta?>(null)
        private set
    var pageIndex by mutableIntStateOf(0)
        private set

    /** Page thumbnails panel in the editor. */
    var pagesOpen by mutableStateOf(false)

    init {
        editor.onChanged = { scheduleSave() }
        editor.imageLoader = { name -> loadImage(name) }
        loadPrefs()
    }

    // ---------- library ----------

    fun items(): List<LibraryNode> {
        if (libraryRevision < 0) return emptyList()
        val base = when {
            section == Section.TRASH -> repo.trashedRoots()
            section == Section.FAVORITES -> repo.liveNodes().filter { it.favorite }
            query.isNotBlank() -> repo.liveNodes().filter { it.name.contains(query.trim(), ignoreCase = true) }
            else -> repo.children(currentFolder)
        }
        val cmp: Comparator<LibraryNode> = when (sortMode) {
            SortMode.DATE -> compareByDescending<LibraryNode> { it.modifiedAt }
            SortMode.NAME -> compareBy<LibraryNode> { it.name.lowercase() }
            SortMode.TYPE -> compareBy<LibraryNode>({ it.type != NodeType.FOLDER }, { it.name.lowercase() })
        }
        return base.sortedWith(cmp)
    }

    fun selectSection(s: Section) {
        section = s
        query = ""
        currentFolder = null
    }

    fun folderChoices(exclude: LibraryNode): List<LibraryNode> {
        val banned = repo.descendantIds(exclude.id) + exclude.id
        return repo.liveNodes().filter { it.type == NodeType.FOLDER && it.id !in banned }.sortedBy { repo.pathName(it.id).lowercase() }
    }

    fun breadcrumb(): String = repo.pathName(currentFolder)

    private fun changedLibrary() { libraryRevision++ }

    fun openFolder(id: String) { query = ""; currentFolder = id }

    fun navigateUp() {
        when {
            section != Section.DOCS -> section = Section.DOCS
            query.isNotBlank() -> query = ""
            else -> currentFolder = currentFolder?.let { repo.get(it)?.parentId }
        }
    }

    fun createFolder(name: String) { repo.createFolder(currentFolder, name); changedLibrary() }

    fun createNotebook(
        name: String,
        cover: String,
        paper: PaperType,
        color: PaperColor,
        size: PageSize,
        landscape: Boolean,
    ) {
        val n = repo.createNotebook(currentFolder, name, paper, cover, color, size, landscape)
        changedLibrary()
        openNotebook(n.id)
    }

    /** A notebook created instantly with default settings. */
    fun quickNote() {
        createNotebook(appContext.getString(R.string.quick_note), "none", PaperType.RULED, PaperColor.WHITE, PageSize.A4, false)
    }

    fun rename(id: String, name: String) { repo.rename(id, name); changedLibrary() }
    fun toggleFavorite(n: LibraryNode) { repo.setFavorite(n.id, !n.favorite); changedLibrary() }
    fun move(id: String, parent: String?) { repo.move(id, parent); changedLibrary() }
    fun duplicate(id: String) { repo.duplicate(id); changedLibrary() }
    fun trash(id: String) { repo.trash(id); changedLibrary() }
    fun restore(id: String) { repo.restore(id); changedLibrary() }
    fun deleteForever(id: String) { repo.deleteForever(id); changedLibrary() }
    fun emptyTrash() { repo.emptyTrash(); changedLibrary() }

    // ---------- PDF import ----------

    private fun displayName(uri: Uri): String? =
        try {
            appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }

    /** Copies the PDF into app storage (the original file is never changed) and opens it as a notebook. */
    fun importPdf(uri: Uri) {
        busy = true
        message = null
        val folder = currentFolder
        val name = (displayName(uri) ?: "PDF").removeSuffix(".pdf").removeSuffix(".PDF")
        val id = repo.newNotebookId()
        val dest = repo.pdfFile(id)
        worker.execute {
            try {
                dest.parentFile?.mkdirs()
                val input = appContext.contentResolver.openInputStream(uri) ?: throw IOException("cannot open")
                input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                val src = PdfSource(dest)
                val sizes = try { src.pageSizes() } finally { src.close() }
                if (sizes.isEmpty()) throw IOException("empty pdf")
                val pages = sizes.mapIndexed { i, wh -> PageInfo(UUID.randomUUID().toString(), "", i, wh.first, wh.second) }
                handler.post {
                    repo.registerPdfNotebook(id, folder, name, pages)
                    busy = false
                    changedLibrary()
                    openNotebook(id)
                }
            } catch (e: Exception) {
                dest.parentFile?.deleteRecursively()
                handler.post {
                    busy = false
                    message = appContext.getString(R.string.pdf_import_failed)
                }
            }
        }
    }

    // ---------- pictures ----------

    private fun loadImage(name: String) {
        if (!requestedImages.add(name)) return
        worker.execute {
            val bmp = try { images.load(name) } catch (e: Exception) { null }
            handler.post {
                requestedImages.remove(name)
                if (bmp != null) editor.imageCache[name] = bmp.asImageBitmap()
            }
        }
    }

    /** Adds a picture (gallery or camera) to the current page. */
    fun insertImage(uri: Uri) {
        if (openNotebookId == null) return
        busy = true
        message = null
        worker.execute {
            val res = try { images.import(appContext.contentResolver, uri) } catch (e: Exception) { null }
            handler.post {
                busy = false
                if (res == null) {
                    message = appContext.getString(R.string.image_failed)
                } else {
                    editor.addImage(res.first, res.second, res.third)
                }
            }
        }
    }

    /** A private file the camera app can write to. */
    fun prepareCameraUri(): Uri {
        val dir = File(appContext.cacheDir, "camera").apply { mkdirs() }
        val f = File(dir, "shot_" + UUID.randomUUID() + ".jpg")
        val u = FileProvider.getUriForFile(appContext, appContext.packageName + ".fileprovider", f)
        cameraUri = u
        return u
    }

    fun insertCameraPicture() { cameraUri?.let { insertImage(it) } }

    // ---------- PDF export ----------

    /** Writes the whole notebook, or just the current page, to a new PDF at [uri]. */
    fun exportPdf(uri: Uri, wholeNotebook: Boolean) {
        val m = meta ?: return
        flush()
        val indices = if (wholeNotebook) m.pages.indices.toList() else listOf(pageIndex)
        val src = pdf
        busy = true
        message = null
        worker.execute {
            val ok = try {
                val out = appContext.contentResolver.openOutputStream(uri) ?: throw IOException("cannot write")
                out.use { PdfExporter.write(repo, m, src, images, indices, it) }
                true
            } catch (e: Exception) {
                false
            }
            handler.post {
                busy = false
                message = appContext.getString(if (ok) R.string.export_done else R.string.export_failed)
            }
        }
    }

    // ---------- notebook editing ----------

    fun openNotebook(id: String) {
        val m = repo.loadMeta(id)
        meta = m
        openNotebookId = id
        closePdf()
        val f = repo.pdfFile(id)
        if (f.exists()) pdf = try { PdfSource(f) } catch (e: Exception) { null }
        editor.setPaperStyle(m.paper, m.paperColor)
        editor.resetView()
        showPage(0)
    }

    private fun closePdf() {
        renderToken++
        editor.pdfImage = null
        editor.pdfPage = false
        pdf?.let { try { it.close() } catch (e: Exception) { /* already closed */ } }
        pdf = null
    }

    private fun showPage(i: Int) {
        val m = meta ?: return
        val idx = i.coerceIn(0, m.pages.size - 1)
        val info = m.pages[idx]
        pageIndex = idx
        val fromPdf = info.pdfPage >= 0 && info.pdfW > 0f && pdf != null
        if (fromPdf) {
            editor.setPageSize(PageSpec.WIDTH, PageSpec.WIDTH * info.pdfH / info.pdfW)
        } else {
            val (dw, dh) = m.size.dims(m.landscape)
            editor.setPageSize(dw, dh)
        }
        editor.pdfPage = fromPdf
        editor.pdfImage = null
        editor.loadPage(repo.loadPage(m.id, info.id))
        editor.scrollToTop()
        if (fromPdf) renderPdfBackground(info.pdfPage)
    }

    private fun renderPdfBackground(pageNo: Int) {
        val src = pdf ?: return
        val token = ++renderToken
        worker.execute {
            val bmp = try { src.render(pageNo, PDF_RENDER_WIDTH) } catch (e: Exception) { null }
            handler.post {
                if (bmp != null && token == renderToken) editor.pdfImage = bmp.asImageBitmap()
            }
        }
    }

    fun goToPage(i: Int) { flush(); showPage(i) }

    fun addPage() {
        val m = meta ?: return
        flush()
        val p = PageInfo(UUID.randomUUID().toString())
        val pages = m.pages.toMutableList().apply { add(pageIndex + 1, p) }
        updateMeta(m.copy(pages = pages))
        repo.savePage(m.id, p.id, PageContent(emptyList()))
        showPage(pageIndex + 1)
    }

    fun deletePage() {
        val m = meta ?: return
        if (m.pages.size == 1) { editor.clearPage(); return }
        flush()
        val removed = m.pages[pageIndex]
        updateMeta(m.copy(pages = m.pages.filter { it.id != removed.id }))
        repo.deletePage(m.id, removed.id)
        showPage(minOf(pageIndex, m.pages.size - 2))
    }

    /** Copies the current page (ink, pictures, and PDF background if any) right after it. */
    fun duplicatePage() {
        val m = meta ?: return
        flush()
        val src = m.pages[pageIndex]
        val p = PageInfo(UUID.randomUUID().toString(), src.title, src.pdfPage, src.pdfW, src.pdfH)
        repo.savePage(m.id, p.id, editor.snapshot())
        val pages = m.pages.toMutableList().apply { add(pageIndex + 1, p) }
        updateMeta(m.copy(pages = pages))
        showPage(pageIndex + 1)
    }

    fun setTemplate(p: PaperType, c: PaperColor) {
        val m = meta ?: return
        updateMeta(m.copy(paper = p, paperColor = c))
        editor.setPaperStyle(p, c)
    }

    fun setPaper(p: PaperType) {
        val m = meta ?: return
        updateMeta(m.copy(paper = p))
        editor.setPaperStyle(p, m.paperColor)
    }

    private fun updateMeta(m: NotebookMeta) {
        meta = m
        repo.saveMeta(m)
    }

    fun closeNotebook() {
        flush()
        closePdf()
        openNotebookId = null
        meta = null
        changedLibrary()
    }

    // ---------- settings ----------

    private fun prefs() = appContext.getSharedPreferences("handnotes_prefs", Context.MODE_PRIVATE)

    private fun loadPrefs() {
        val p = prefs()
        editor.scribbleEnabled = p.getBoolean("scribble", true)
        editor.scribbleErasesHighlighter = p.getBoolean("scribble_hl", true)
        editor.shapeSnap = p.getBoolean("snap", false)
        editor.smoothing = p.getFloat("smooth", 0f)
        val cal = if (p.getBoolean("cal_has", false)) {
            Calibration(
                unit = SizeUnit.entries.getOrElse(p.getInt("cal_unit", 0)) { SizeUnit.MAJOR_PX },
                narrowMax = p.getFloat("cal_narrow", 0f),
                palmMin = p.getFloat("cal_palm", 0f),
                narrowReliable = p.getBoolean("cal_nr", false),
                palmReliable = p.getBoolean("cal_pr", false),
                stylusIsToolType = p.getBoolean("cal_tt", false),
                quality = CalibrationQuality.entries.getOrElse(p.getInt("cal_q", 0)) { CalibrationQuality.NO_SIZE_DATA },
            )
        } else {
            null
        }
        editor.palmConfig = PalmConfig(
            enabled = p.getBoolean("palm_on", true),
            writingLock = p.getBoolean("palm_lock", false),
            sensitivity = p.getFloat("palm_sens", 0.5f),
            calibration = cal,
        )
    }

    /** Saves the writing and palm-rejection settings. Call after the user changes one. */
    fun savePrefs() {
        val c = editor.palmConfig
        val cal = c.calibration
        prefs().edit()
            .putBoolean("scribble", editor.scribbleEnabled)
            .putBoolean("scribble_hl", editor.scribbleErasesHighlighter)
            .putBoolean("snap", editor.shapeSnap)
            .putFloat("smooth", editor.smoothing)
            .putBoolean("palm_on", c.enabled)
            .putBoolean("palm_lock", c.writingLock)
            .putFloat("palm_sens", c.sensitivity)
            .putBoolean("cal_has", cal != null)
            .putInt("cal_unit", cal?.unit?.ordinal ?: 0)
            .putFloat("cal_narrow", cal?.narrowMax ?: 0f)
            .putFloat("cal_palm", cal?.palmMin ?: 0f)
            .putBoolean("cal_nr", cal?.narrowReliable ?: false)
            .putBoolean("cal_pr", cal?.palmReliable ?: false)
            .putBoolean("cal_tt", cal?.stylusIsToolType ?: false)
            .putInt("cal_q", cal?.quality?.ordinal ?: 0)
            .apply()
    }

    // ---------- autosave ----------

    private fun scheduleSave() {
        dirty = true
        handler.removeCallbacks(saveRunnable)
        handler.postDelayed(saveRunnable, SAVE_DELAY_MS)
    }

    /** Queues the current page for a background write. Cheap: it only copies a list. */
    fun flush() {
        handler.removeCallbacks(saveRunnable)
        val id = openNotebookId ?: return
        val m = meta ?: return
        if (!dirty) return
        dirty = false
        repo.savePage(id, m.pages[pageIndex].id, editor.snapshot())
        repo.touch(id)
    }

    /** Used when the app goes to the background: also waits for the disk write to finish. */
    fun flushAndWait() {
        flush()
        repo.awaitIdle()
    }

    private companion object {
        const val SAVE_DELAY_MS = 700L
        const val PDF_RENDER_WIDTH = 1800
    }
}
