package com.example.handnotes.engine

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ShapeRecognizerTest {
    private fun path(vararg xy: Float): List<Pt> {
        val corners = (xy.indices step 2).map { Pt(xy[it], xy[it + 1]) }
        return Geometry.densify(corners, 5f)
    }

    @Test fun wobblyLineBecomesStraightLine() {
        val pts = (0..40).map { i -> Pt(5f * i, 0.05f * 5f * i + 3f * sin(i.toFloat())) }
        val r = ShapeRecognizer.recognize(pts)
        assertNotNull(r)
        assertEquals(2, r!!.size)
    }

    @Test fun roughCircleBecomesCircle() {
        val pts = (0 until 60).map { i ->
            val th = (2.0 * PI * i / 60.0).toFloat()
            val r = 100f * (1f + 0.04f * sin(3f * th))
            Pt(200f + r * cos(th), 200f + r * sin(th))
        }
        val r = ShapeRecognizer.recognize(pts)
        assertNotNull(r)
        assertEquals(73, r!!.size)
        val radii = r.map { hypot(it.x - 200f, it.y - 200f) }
        assertTrue(radii.max() - radii.min() < 2f)
    }

    @Test fun roughRectangleBecomesRectangle() {
        val pts = path(150f, 0f, 300f, 0f, 300f, 150f, 0f, 150f, 0f, 0f, 150f, 0f)
        val r = ShapeRecognizer.recognize(pts)
        assertNotNull(r)
        assertEquals(5, r!!.size)
        assertEquals(r.first().x, r.last().x, 0.01f)
        assertEquals(r.first().y, r.last().y, 0.01f)
    }

    @Test fun roughTriangleBecomesTriangle() {
        val pts = path(0f, 0f, 200f, 0f, 100f, 170f, 0f, 0f)
        val r = ShapeRecognizer.recognize(pts)
        assertNotNull(r)
        assertEquals(4, r!!.size)
    }

    @Test fun zigzagIsNotAShape() {
        assertNull(ShapeRecognizer.recognize(path(0f, 0f, 100f, 60f, 20f, 90f, 120f, 150f, 40f, 200f)))
    }

    @Test fun tinyStrokeIsIgnored() {
        assertNull(ShapeRecognizer.recognize(path(0f, 0f, 10f, 2f)))
    }
}
