package com.example.handnotes.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LassoTest {
    private fun line(x0: Float, y: Float, x1: Float) =
        InkStroke(points = (0..10).map { Pt(x0 + (x1 - x0) * it / 10f, y) }, color = 0, width = 4f)

    private val square = listOf(Pt(0f, 0f), Pt(100f, 0f), Pt(100f, 100f), Pt(0f, 100f))

    @Test fun pointInPolygon() {
        assertTrue(Lasso.contains(square, 50f, 50f))
        assertTrue(!Lasso.contains(square, 150f, 50f))
    }

    @Test fun selectsOnlyStrokesInsideLasso() {
        val inside = line(10f, 50f, 90f)
        val outside = line(200f, 50f, 300f)
        assertEquals(setOf(inside.id), Lasso.select(listOf(inside, outside), square))
    }

    @Test fun mostlyInsideStrokeIsSelectedMostlyOutsideIsNot() {
        val mostlyIn = line(20f, 50f, 120f)    // 8 of 11 points inside
        val mostlyOut = line(80f, 50f, 300f)   // only a few points inside
        val sel = Lasso.select(listOf(mostlyIn, mostlyOut), square)
        assertTrue(mostlyIn.id in sel)
        assertTrue(mostlyOut.id !in sel)
    }

    @Test fun tinyLassoSelectsNothing() {
        val tiny = listOf(Pt(0f, 0f), Pt(3f, 0f), Pt(3f, 3f))
        assertTrue(Lasso.select(listOf(line(0f, 1f, 2f)), tiny).isEmpty())
    }

    @Test fun rectangleLassoUsesDragCorners() {
        val r = Lasso.rect(listOf(Pt(10f, 10f), Pt(40f, 30f), Pt(90f, 80f)))
        assertEquals(4, r.size)
        assertTrue(Lasso.contains(r, 50f, 40f))
    }

    @Test fun moveUndoRestoresOriginalAndKeepsOrder() {
        val doc = PageDoc()
        val h = History(doc)
        val a = line(0f, 0f, 10f); val b = line(0f, 20f, 10f)
        listOf(a, b).forEach { h.execute(EditStrokesCommand(emptyList(), listOf(it))) }
        h.execute(ReplaceStrokesCommand(listOf(a), listOf(StrokeTransform.translate(a, 50f, 60f))))
        assertEquals(listOf(a.id, b.id), doc.strokes.map { it.id })
        assertEquals(50f, doc.strokes[0].points.first().x, 0.001f)
        h.undo()
        assertEquals(0f, doc.strokes[0].points.first().x, 0.001f)
        h.redo()
        assertEquals(60f, doc.strokes[0].points.first().y, 0.001f)
    }

    @Test fun scaleAndRotateAboutCenter() {
        val s = InkStroke(points = listOf(Pt(10f, 0f), Pt(20f, 0f)), color = 0, width = 2f)
        val big = StrokeTransform.scale(s, 2f, 0f, 0f)
        assertEquals(20f, big.points[0].x, 0.001f)
        assertEquals(4f, big.width, 0.001f)
        val rot = StrokeTransform.rotate(s, (Math.PI / 2).toFloat(), 0f, 0f)
        assertEquals(0f, rot.points[0].x, 0.001f)
        assertEquals(10f, rot.points[0].y, 0.001f)
    }

    @Test fun cloneGivesNewIdsAndOffset() {
        val s = line(0f, 0f, 10f)
        val c = StrokeTransform.clone(listOf(s), 40f, 40f).single()
        assertTrue(c.id != s.id)
        assertEquals(40f, c.points.first().x, 0.001f)
    }
}
