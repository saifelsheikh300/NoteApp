package com.example.handnotes.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImageObjectTest {
    private val img = ImageObject(file = "a.jpg", cx = 100f, cy = 100f, w = 100f, h = 40f)

    @Test fun containsRespectsRotation() {
        assertTrue(img.contains(140f, 100f))
        assertFalse(img.contains(100f, 140f))
        val turned = img.copy(rotationDeg = 90f)
        assertTrue(turned.contains(100f, 140f))
        assertFalse(turned.contains(140f, 100f))
    }

    @Test fun boundsOfRotatedImage() {
        val b = img.copy(rotationDeg = 90f).bounds()
        assertEquals(40f, b.width, 0.01f)
        assertEquals(100f, b.height, 0.01f)
    }

    @Test fun scaleAndRotateMoveCentre() {
        val big = ImageTransform.scale(img, 2f, 0f, 0f)
        assertEquals(200f, big.cx, 0.01f)
        assertEquals(200f, big.w, 0.01f)
        val rot = ImageTransform.rotate(img.copy(cx = 10f, cy = 0f), (Math.PI / 2).toFloat(), 0f, 0f)
        assertEquals(0f, rot.cx, 0.01f)
        assertEquals(10f, rot.cy, 0.01f)
        assertEquals(90f, rot.rotationDeg, 0.01f)
    }

    @Test fun imageCommandsUndoRedo() {
        val doc = PageDoc()
        val h = History(doc)
        h.execute(EditImagesCommand(emptyList(), listOf(img)))
        h.execute(ReplaceImagesCommand(listOf(img), listOf(ImageTransform.translate(img, 50f, 0f))))
        assertEquals(150f, doc.images.single().cx, 0.01f)
        h.undo()
        assertEquals(100f, doc.images.single().cx, 0.01f)
        h.undo()
        assertTrue(doc.images.isEmpty())
    }

    @Test fun compositeCommandIsOneUndoStep() {
        val doc = PageDoc()
        val h = History(doc)
        val s = InkStroke(points = listOf(Pt(0f, 0f), Pt(5f, 5f)), color = 0, width = 2f)
        h.execute(CompositeCommand(listOf(EditStrokesCommand(emptyList(), listOf(s)), EditImagesCommand(emptyList(), listOf(img)))))
        h.undo()
        assertTrue(doc.strokes.isEmpty() && doc.images.isEmpty())
        h.redo()
        assertEquals(1, doc.strokes.size)
        assertEquals(1, doc.images.size)
    }
}
