package com.example.handnotes.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryAndEraserTest {
    private fun line(x0: Float, y: Float, x1: Float): InkStroke =
        InkStroke(points = (0..10).map { Pt(x0 + (x1 - x0) * it / 10f, y) }, color = 0, width = 4f)

    @Test fun addUndoRedo() {
        val doc = PageDoc()
        val h = History(doc)
        val s = line(0f, 0f, 100f)
        h.execute(EditStrokesCommand(emptyList(), listOf(s)))
        assertEquals(1, doc.strokes.size)
        assertTrue(h.undo())
        assertEquals(0, doc.strokes.size)
        assertTrue(h.redo())
        assertEquals(listOf(s.id), doc.strokes.map { it.id })
        assertFalse(h.redo())
    }

    @Test fun newActionClearsRedo() {
        val doc = PageDoc()
        val h = History(doc)
        h.execute(EditStrokesCommand(emptyList(), listOf(line(0f, 0f, 10f))))
        h.undo()
        h.execute(EditStrokesCommand(emptyList(), listOf(line(0f, 5f, 10f))))
        assertFalse(h.canRedo)
    }

    @Test fun undoingDeletionRestoresOriginalOrder() {
        val doc = PageDoc()
        val h = History(doc)
        val a = line(0f, 0f, 10f); val b = line(0f, 20f, 10f); val c = line(0f, 40f, 10f)
        listOf(a, b, c).forEach { h.execute(EditStrokesCommand(emptyList(), listOf(it))) }
        h.execute(EditStrokesCommand(listOf(a, c), emptyList()))
        assertEquals(listOf(b.id), doc.strokes.map { it.id })
        h.undo()
        assertEquals(listOf(a.id, b.id, c.id), doc.strokes.map { it.id })
    }

    @Test fun strokeEraserRemovesOnlyTouchedStroke() {
        val a = line(0f, 0f, 100f); val b = line(0f, 100f, 100f)
        val r = Eraser.eraseStrokes(listOf(a, b), listOf(Pt(50f, 2f), Pt(60f, 2f)), 10f)
        assertEquals(listOf(a.id), r.removed.map { it.id })
    }

    @Test fun segmentEraserSplitsStroke() {
        val a = line(0f, 0f, 100f)
        val r = Eraser.eraseSegments(listOf(a), listOf(Pt(50f, 0f)), 8f)
        assertEquals(1, r.removed.size)
        assertEquals(2, r.added.size)
    }

    @Test fun eraserMissLeavesEverythingAlone() {
        val a = line(0f, 0f, 100f)
        assertTrue(Eraser.eraseSegments(listOf(a), listOf(Pt(50f, 80f)), 8f).isEmpty)
    }
}
