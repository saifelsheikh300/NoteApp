package com.example.handnotes.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Replays touch sequences and records which strokes were started, finished and cancelled. */
private class Sim(cfg: PalmConfig = PalmConfig()) {
    val f = PalmFilter(cfg, 160f)
    var t = 0L
    val started = mutableListOf<Int>()
    val finished = mutableListOf<Int>()
    val cancelled = mutableListOf<Int>()
    private var cur: GestureMode = GestureMode.None

    val mode: GestureMode get() = f.mode

    private fun apply(next: GestureMode, upId: Int? = null) {
        if (next == cur) return
        val old = cur
        if (old is GestureMode.Draw) {
            if (upId != null && upId == old.id) finished.add(old.id) else cancelled.add(old.id)
        }
        if (next is GestureMode.Draw) started.add(next.id)
        cur = next
    }

    fun down(id: Int, x: Float = 0f, y: Float = 0f, major: Float = 0f, kind: ToolKind = ToolKind.FINGER) =
        apply(f.onDown(Contact(id, x, y, t, kind, major)))

    fun move(id: Int, x: Float, y: Float, major: Float = 0f, kind: ToolKind = ToolKind.FINGER) =
        apply(f.onMove(Contact(id, x, y, t, kind, major)))

    fun up(id: Int) = apply(f.onUp(id, t), id)
    fun wait(ms: Long) { t += ms }
}

private const val PEN = 20f      // ~3 mm at 160 dpi: a narrow tip
private const val FINGER = 60f   // ~9.5 mm
private const val PALM = 200f    // ~32 mm

class PalmRejectionTest {

    // ---------- false negatives: palm must not write ----------

    @Test fun palmDownBeforePenNeverWrites() {
        val s = Sim()
        s.down(9, major = PALM); s.wait(300)
        s.down(1, 100f, 100f, PEN)
        assertEquals(GestureMode.Draw(1), s.mode)
        s.up(1)
        assertEquals(listOf(1), s.started)
        assertEquals(listOf(1), s.finished)
    }

    @Test fun palmLandingAfterPenDoesNotInterrupt() {
        val s = Sim()
        s.down(1, 0f, 0f, PEN)
        for (i in 1..10) { s.wait(8); s.move(1, i * 5f, 0f, PEN) }
        s.down(2, 300f, 300f, PALM)
        assertEquals(GestureMode.Draw(1), s.mode)
        s.up(1)
        assertTrue(s.cancelled.isEmpty())
        assertEquals(listOf(1), s.finished)
    }

    @Test fun contactThatSpreadsIntoAPalmIsCancelled() {
        val s = Sim()
        s.down(1, 0f, 0f, PEN)            // lands narrow
        s.wait(30); s.move(1, 2f, 2f, 160f) // then spreads: it was a palm
        assertEquals(GestureMode.None, s.mode)
        assertEquals(listOf(1), s.cancelled)
        s.up(1)
        assertTrue(s.finished.isEmpty())
    }

    @Test fun stylusToolTypeBeatsFingerContact() {
        val s = Sim()
        s.down(1, major = FINGER); s.wait(200)
        s.down(2, kind = ToolKind.STYLUS)
        assertEquals(GestureMode.Draw(2), s.mode)
        assertEquals(listOf(1), s.cancelled)
    }

    @Test fun secondFingerAfterWritingStartedIsIgnoredEvenAfterFirstLifts() {
        val s = Sim()
        s.down(1, 0f, 0f, FINGER)
        for (i in 1..10) { s.wait(30); s.move(1, i * 5f, 0f, FINGER) }
        s.down(2, 200f, 200f, FINGER)
        assertEquals(GestureMode.Draw(1), s.mode)
        s.up(1)
        assertEquals(GestureMode.None, s.mode)   // the resting second contact does not start writing
        assertEquals(listOf(1), s.started)
    }

    @Test fun restingMediumContactDoesNotStopLaterPenStrokes() {
        // Pen and palm both look finger-sized: rely on timing. The one that rests is ignored.
        val s = Sim()
        s.down(9, major = FINGER); s.wait(300)
        repeat(4) { n ->
            s.down(n + 1, major = FINGER); s.wait(20); s.up(n + 1); s.wait(100)
        }
        // The resting contact first looks like a lone finger (a stroke is begun), then it is dropped when the pen lands.
        assertEquals(listOf(9, 1, 2, 3, 4), s.started)
        assertEquals(listOf(1, 2, 3, 4), s.finished)
        assertEquals(listOf(9), s.cancelled)
    }

    // ---------- false positives: real writing must survive ----------

    @Test fun shortTapIsKept() {
        val s = Sim()
        s.down(1, major = PEN); s.wait(15); s.up(1)
        assertEquals(listOf(1), s.started)
        assertEquals(listOf(1), s.finished)
    }

    @Test fun fingerWritingAloneIsNeverRejected() {
        val s = Sim()
        s.down(1, major = FINGER)
        for (i in 1..20) { s.wait(10); s.move(1, i * 3f, i * 2f, FINGER) }
        s.up(1)
        assertEquals(listOf(1), s.finished)
        assertTrue(s.cancelled.isEmpty())
    }

    @Test fun dotsAndDiacriticsSurviveARestingPalm() {
        val s = Sim()
        s.down(9, major = PALM); s.wait(500)
        // three dots (ب ت ث style) and a tiny fatha: very short, very quick contacts
        repeat(4) { n ->
            s.down(n + 1, 50f + n * 10f, 40f, 15f)
            s.wait(12)
            s.move(n + 1, 51f + n * 10f, 41f, 15f)
            s.wait(12)
            s.up(n + 1)
            s.wait(90)
        }
        assertEquals(listOf(1, 2, 3, 4), s.started)
        assertEquals(listOf(1, 2, 3, 4), s.finished)
        assertTrue(s.cancelled.isEmpty())
        assertFalse(9 in s.started)
    }

    @Test fun arabicWordKeepsEveryStroke() {
        // A word made of one long body stroke, a vertical alef, three dots and two small marks, written with a palm resting.
        val s = Sim()
        s.down(99, major = 230f)
        for (i in 1..5) { s.wait(40); s.move(99, 400f + i, 400f, 230f + i) }  // palm jitters
        var written = 0
        fun stroke(id: Int, points: Int, step: Float, major: Float) {
            s.wait(110)
            s.down(id, 200f, 100f, major)
            for (k in 1..points) { s.wait(8); s.move(id, 200f - k * step, 100f + (k % 3), major) }
            s.wait(8)
            s.up(id)
            written++
        }
        stroke(1, 60, 4f, 24f)   // body
        stroke(2, 25, 1f, 20f)   // alef
        stroke(3, 1, 1f, 16f)    // dot
        stroke(4, 1, 1f, 16f)    // dot
        stroke(5, 1, 1f, 16f)    // dot
        stroke(6, 2, 1f, 18f)    // tiny diacritic
        stroke(7, 3, 1f, 18f)    // tiny diacritic
        assertEquals(7, written)
        assertEquals((1..7).toList(), s.started)
        assertEquals((1..7).toList(), s.finished)
        assertTrue(s.cancelled.isEmpty())
    }

    // ---------- navigation ----------

    @Test fun twoFingersTogetherPanAndZoom() {
        val s = Sim()
        s.down(1, major = FINGER); s.wait(30)
        s.down(2, 200f, 0f, FINGER)
        assertEquals(GestureMode.Navigate(1, 2), s.mode)
        assertEquals(listOf(1), s.cancelled)       // the tiny stroke the first finger began is dropped
        s.up(1)
        assertEquals(GestureMode.None, s.mode)     // the remaining finger must not start writing
        s.up(2)
        assertEquals(listOf(1), s.started)
    }

    @Test fun writingLockTurnsNavigationOff() {
        val s = Sim(PalmConfig(writingLock = true))
        s.down(1, major = FINGER); s.wait(30)
        s.down(2, major = FINGER)
        assertEquals(GestureMode.Draw(1), s.mode)
        assertTrue(s.cancelled.isEmpty())
    }

    @Test fun temporaryAllowOverridesTheLock() {
        val s = Sim(PalmConfig(writingLock = true))
        s.f.tempNavUntil = 10_000L
        s.down(1, major = FINGER); s.wait(500)
        s.down(2, major = FINGER)
        assertEquals(GestureMode.Navigate(1, 2), s.mode)
    }

    // ---------- no size data ----------

    @Test fun withoutSizeDataSimultaneousContactsNavigate() {
        val s = Sim()
        s.down(1); s.wait(40); s.down(2)
        assertEquals(GestureMode.Navigate(1, 2), s.mode)
    }

    @Test fun withoutSizeDataWritingContactWinsOverLateOne() {
        val s = Sim()
        s.down(1, 0f, 0f)
        for (i in 1..10) { s.wait(30); s.move(1, i * 5f, 0f) }
        s.down(2, 200f, 200f)
        assertEquals(GestureMode.Draw(1), s.mode)
        assertEquals(listOf(1), s.started)
    }

    @Test fun unknownSizeIsReportedAsUnknownNotGuessed() {
        val th = PalmMath.resolve(PalmConfig(), 160f)
        assertEquals(TouchClass.UNKNOWN, PalmMath.classify(Contact(1, 0f, 0f, 0), th))
    }

    // ---------- switches ----------

    @Test fun disabledKeepsTheOldBehaviour() {
        val s = Sim(PalmConfig(enabled = false))
        s.down(1, major = PALM)
        assertEquals(GestureMode.Draw(1), s.mode)  // nothing is rejected
        s.down(2, major = FINGER)
        assertEquals(GestureMode.Navigate(1, 2), s.mode)
    }

    @Test fun manualLockWorksEvenWithRejectionOff() {
        val s = Sim(PalmConfig(enabled = false, writingLock = true))
        s.down(1, major = FINGER); s.wait(20); s.down(2, major = FINGER)
        assertEquals(GestureMode.Draw(1), s.mode)
    }

    @Test fun sensitivityMovesThePalmThreshold() {
        val c = Contact(1, 0f, 0f, 0, ToolKind.FINGER, major = 88f)   // ~14 mm
        assertEquals(TouchClass.FINGER, PalmMath.classify(c, PalmMath.resolve(PalmConfig(sensitivity = 0f), 160f)))
        assertEquals(TouchClass.FINGER, PalmMath.classify(c, PalmMath.resolve(PalmConfig(sensitivity = 0.5f), 160f)))
        assertEquals(TouchClass.PALM, PalmMath.classify(c, PalmMath.resolve(PalmConfig(sensitivity = 1f), 160f)))
    }
}

class PalmCalibrationTest {
    private fun c(kind: ToolKind, major: Float, size: Float = 0f) = Contact(1, 0f, 0f, 0, kind, major, 0f, size)
    private fun many(kind: ToolKind, vararg majors: Float) = majors.map { c(kind, it) }

    @Test fun clearlySeparatedSizesGiveAGoodCalibration() {
        val cal = PalmCalibrator.fit(
            many(ToolKind.FINGER, 15f, 20f, 25f, 30f, 22f),
            many(ToolKind.FINGER, 70f, 90f, 100f, 110f, 85f),
            many(ToolKind.FINGER, 220f, 300f, 400f, 280f, 350f),
        )
        assertEquals(CalibrationQuality.GOOD, cal.quality)
        val th = PalmMath.resolve(PalmConfig(calibration = cal), 160f)
        assertEquals(TouchClass.PEN, PalmMath.classify(c(ToolKind.FINGER, 25f), th))
        assertEquals(TouchClass.FINGER, PalmMath.classify(c(ToolKind.FINGER, 95f), th))
        assertEquals(TouchClass.PALM, PalmMath.classify(c(ToolKind.FINGER, 300f), th))
    }

    @Test fun similarStylusAndFingerAreNotSeparated() {
        val cal = PalmCalibrator.fit(
            many(ToolKind.FINGER, 60f, 75f, 90f, 80f, 70f),
            many(ToolKind.FINGER, 70f, 90f, 100f, 110f, 85f),
            many(ToolKind.FINGER, 220f, 300f, 400f),
        )
        assertEquals(CalibrationQuality.STYLUS_FINGER_SIMILAR, cal.quality)
        assertFalse(cal.narrowReliable)
        val th = PalmMath.resolve(PalmConfig(calibration = cal), 160f)
        // it must not pretend: a stylus-sized contact is simply a finger-sized one
        assertEquals(TouchClass.FINGER, PalmMath.classify(c(ToolKind.FINGER, 65f), th))
        assertEquals(TouchClass.PALM, PalmMath.classify(c(ToolKind.FINGER, 300f), th))
    }

    @Test fun similarPalmAndFingerAreNotSeparated() {
        val cal = PalmCalibrator.fit(
            many(ToolKind.FINGER, 15f, 20f, 25f),
            many(ToolKind.FINGER, 70f, 90f, 110f),
            many(ToolKind.FINGER, 80f, 100f, 120f),
        )
        assertEquals(CalibrationQuality.PALM_FINGER_SIMILAR, cal.quality)
        assertFalse(cal.palmReliable)
    }

    @Test fun noSizeDataIsReportedHonestly() {
        val cal = PalmCalibrator.fit(many(ToolKind.FINGER, 0f, 0f), many(ToolKind.FINGER, 0f, 0f), many(ToolKind.FINGER, 0f, 0f))
        assertEquals(CalibrationQuality.NO_SIZE_DATA, cal.quality)
        val th = PalmMath.resolve(PalmConfig(calibration = cal), 160f)
        assertEquals(TouchClass.UNKNOWN, PalmMath.classify(c(ToolKind.FINGER, 0f), th))
    }

    @Test fun stylusReportedAsStylusIsTrusted() {
        val cal = PalmCalibrator.fit(
            many(ToolKind.STYLUS, 10f, 12f, 11f),
            many(ToolKind.FINGER, 80f, 90f),
            many(ToolKind.FINGER, 300f, 320f),
        )
        assertEquals(CalibrationQuality.TOOL_TYPE, cal.quality)
        assertTrue(cal.stylusIsToolType)
        val th = PalmMath.resolve(PalmConfig(calibration = cal), 160f)
        assertEquals(TouchClass.PEN, PalmMath.classify(c(ToolKind.STYLUS, 0f), th))
    }

    @Test fun missingStepsAreIncomplete() {
        val cal = PalmCalibrator.fit(many(ToolKind.FINGER, 20f, 25f), emptyList(), emptyList())
        assertEquals(CalibrationQuality.INCOMPLETE, cal.quality)
        assertNull(PalmCalibrator.stats(listOf(0f, 0f)))
    }

    @Test fun sizeFallbackIsUsedWhenMajorIsMissing() {
        val cal = PalmCalibrator.fit(
            listOf(c(ToolKind.FINGER, 0f, 0.02f), c(ToolKind.FINGER, 0f, 0.03f)),
            listOf(c(ToolKind.FINGER, 0f, 0.10f), c(ToolKind.FINGER, 0f, 0.12f)),
            listOf(c(ToolKind.FINGER, 0f, 0.30f), c(ToolKind.FINGER, 0f, 0.35f)),
        )
        assertEquals(SizeUnit.SIZE_NORM, cal.unit)
        assertEquals(CalibrationQuality.GOOD, cal.quality)
    }
}
