package com.example.handnotes.engine

import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScribbleDetectorTest {
    private val detector = ScribbleDetector()

    /** Back-and-forth scribble: [passes] horizontal sweeps of [width], drifting down by [drift] per pass. */
    private fun scribble(x0: Float, y0: Float, width: Float, passes: Int, drift: Float, stepMs: Long = 8L): List<Pt> {
        val out = ArrayList<Pt>()
        var t = 0L
        val n = 12
        for (i in 0 until passes) {
            for (k in 0..n) {
                val f = k / n.toFloat()
                val x = if (i % 2 == 0) x0 + width * f else x0 + width * (1f - f)
                out.add(Pt(x, y0 + drift * (i + f), t))
                t += stepMs
            }
        }
        return out
    }

    /** A word written in one wavy stroke between x0 and x0+width. */
    private fun word(x0: Float, y0: Float, width: Float): InkStroke {
        val pts = (0..80).map { i -> Pt(x0 + width * i / 80f, y0 + 12f * sin(i * 0.35f), i * 12L) }
        return InkStroke(points = pts, color = 0xFF000000.toInt(), width = 4f)
    }

    @Test fun a_normalHandwritingIsNotAScribble() {
        val w = word(0f, 100f, 240f)
        assertFalse(detector.analyze(w.points).isScribble)
    }

    @Test fun b_shortRandomStrokeIsNotAScribble() {
        val pts = listOf(Pt(0f, 0f, 0), Pt(10f, 4f, 20), Pt(25f, 2f, 40), Pt(40f, 9f, 60), Pt(60f, 5f, 80))
        assertFalse(detector.analyze(pts).isScribble)
    }

    @Test fun c_scribbleOverOneWordErasesIt() {
        val w = word(0f, 100f, 100f)
        val s = scribble(-10f, 90f, 120f, 10, 3f)
        assertTrue(detector.analyze(s).isScribble)
        assertEquals(listOf(w.id), detector.findTargets(listOf(w), s).map { it.id })
    }

    @Test fun d_scribbleOverMultipleWordsErasesAll() {
        val w1 = word(0f, 100f, 100f)
        val w2 = word(130f, 100f, 100f)
        val s = scribble(-10f, 90f, 260f, 10, 3f)
        assertTrue(detector.analyze(s).isScribble)
        assertEquals(2, detector.findTargets(listOf(w1, w2), s).size)
    }

    @Test fun e_scribbleOverEmptyPageErasesNothing() {
        val s = scribble(0f, 0f, 120f, 10, 3f)
        assertTrue(detector.findTargets(emptyList(), s).isEmpty())
    }

    @Test fun f_scribbleNearTextButNotTouchingKeepsText() {
        val w = word(0f, 100f, 100f)
        val s = scribble(0f, 300f, 120f, 10, 3f)
        assertTrue(detector.findTargets(listOf(w), s).isEmpty())
    }

    @Test fun g_fastScribbleIsDetected() {
        assertTrue(detector.analyze(scribble(0f, 0f, 120f, 10, 3f, stepMs = 3L)).isScribble)
    }

    @Test fun h_slowScribbleIsDetected() {
        assertTrue(detector.analyze(scribble(0f, 0f, 120f, 10, 3f, stepMs = 40L)).isScribble)
    }

    @Test fun i_largeScribbleIsDetected() {
        assertTrue(detector.analyze(scribble(0f, 0f, 900f, 10, 60f)).isScribble)
    }

    @Test fun j_tinyScribbleIsIgnored() {
        assertFalse(detector.analyze(scribble(0f, 0f, 15f, 10, 1f)).isScribble)
    }

    @Test fun disabledDetectorNeverFires() {
        val off = ScribbleDetector(ScribbleConfig(enabled = false))
        assertFalse(off.analyze(scribble(0f, 0f, 120f, 10, 3f)).isScribble)
    }
}
