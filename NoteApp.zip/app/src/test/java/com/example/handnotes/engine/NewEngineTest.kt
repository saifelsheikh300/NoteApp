package com.example.handnotes.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ShapeFactoryTest {
    private val a = Pt(10f, 10f)
    private val b = Pt(110f, 60f)

    @Test fun rectangleIsClosedAndAxisAligned() {
        val r = ShapeFactory.build(ShapeKind.RECT, a, b)
        assertEquals(5, r.size)
        assertEquals(r.first().x, r.last().x, 0.001f)
        assertEquals(10f, r.minOf { it.x }, 0.001f)
        assertEquals(110f, r.maxOf { it.x }, 0.001f)
    }

    @Test fun rectangleWorksWhenDraggedBackwards() {
        val r = ShapeFactory.build(ShapeKind.RECT, b, a)
        assertEquals(10f, r.minOf { it.y }, 0.001f)
        assertEquals(60f, r.maxOf { it.y }, 0.001f)
    }

    @Test fun arrowEndsAtTheDragEndWithAHead() {
        val p = ShapeFactory.build(ShapeKind.ARROW, a, b)
        assertEquals(5, p.size)
        assertEquals(b.x, p[1].x, 0.001f)
        assertEquals(b.y, p[3].y, 0.001f)
    }

    @Test fun ellipseFillsTheBox() {
        val p = ShapeFactory.build(ShapeKind.ELLIPSE, a, b)
        assertEquals(73, p.size)
        assertEquals(10f, p.minOf { it.x }, 0.5f)
        assertEquals(110f, p.maxOf { it.x }, 0.5f)
    }

    @Test fun triangleAndStarAreClosed() {
        val t = ShapeFactory.build(ShapeKind.TRIANGLE, a, b)
        assertEquals(t.first().x, t.last().x, 0.001f)
        val s = ShapeFactory.build(ShapeKind.STAR, a, b)
        assertEquals(11, s.size)
    }

    @Test fun tinyDragDoesNotCrash() {
        assertEquals(2, ShapeFactory.build(ShapeKind.ARROW, a, a).size)
    }
}

class ScribbleSensitivityTest {
    private fun scribble(passes: Int, width: Float = 120f): List<Pt> {
        val out = ArrayList<Pt>()
        var t = 0L
        for (i in 0 until passes) for (k in 0..12) {
            val f = k / 12f
            out.add(Pt(if (i % 2 == 0) width * f else width * (1f - f), 3f * (i + f), t)); t += 8L
        }
        return out
    }

    @Test fun lightSettingAcceptsAShortScribbleThatStrictRejects() {
        val short = scribble(5)
        assertTrue(ScribbleDetector(scribbleConfigFor(1f)).analyze(short).isScribble)
        assertFalse(ScribbleDetector(scribbleConfigFor(0f)).analyze(short).isScribble)
    }

    @Test fun onlyStrokesTheScribbleTouchesAreErased() {
        val under = InkStroke(points = (0..20).map { Pt(10f + it * 5f, 10f) }, color = 0, width = 4f)
        val farInsideBox = InkStroke(points = (0..20).map { Pt(10f + it * 5f, 400f) }, color = 0, width = 4f)
        // a loose scribble: wide gaps between passes, so it passes over the first stroke only
        val loose = ArrayList<Pt>()
        var t = 0L
        for (i in 0 until 6) for (k in 0..12) {
            val f = k / 12f
            loose.add(Pt(if (i % 2 == 0) 120f * f else 120f * (1f - f), if (i < 3) 5f + 3f * i + f else 400f + 3f * (i - 3) + f, t)); t += 8L
        }
        val d = ScribbleDetector(scribbleConfigFor(1f))
        val hit = d.findTargets(listOf(under, farInsideBox), loose).map { it.id }
        assertTrue(under.id in hit)
        assertTrue(farInsideBox.id in hit)
        val middle = InkStroke(points = (0..20).map { Pt(10f + it * 5f, 200f) }, color = 0, width = 4f)
        assertFalse(middle.id in d.findTargets(listOf(middle), loose).map { it.id })
    }
}

class WideTipTest {
    private fun c(m: Float) = Contact(1, 0f, 0f, 0, ToolKind.FINGER, m)
    private fun many(vararg m: Float) = m.map { c(it) }

    private val cal = PalmCalibrator.fit(
        stylus = many(15f, 20f, 25f, 22f),
        finger = many(90f, 100f, 110f, 95f),
        palm = many(250f, 300f, 320f),
        wide = many(45f, 50f, 55f, 48f),
    )
    private val cfg = PalmConfig(wideTip = WideTipAction.ERASER, calibration = cal)

    @Test fun wideTipIsSeparatedFromThinTipAndFinger() {
        assertTrue(cal.wideReliable)
        val th = PalmMath.resolve(cfg, 160f)
        assertEquals(TouchClass.PEN, PalmMath.classify(c(20f), th))
        assertEquals(TouchClass.WIDE, PalmMath.classify(c(50f), th))
        assertEquals(TouchClass.FINGER, PalmMath.classify(c(100f), th))
        assertEquals(TouchClass.PALM, PalmMath.classify(c(300f), th))
    }

    @Test fun wideTipOffMeansNoWideClass() {
        val th = PalmMath.resolve(cfg.copy(wideTip = WideTipAction.OFF), 160f)
        assertTrue(PalmMath.classify(c(50f), th) != TouchClass.WIDE)
    }

    @Test fun wideTipLookingLikeAFingerIsNotTrusted() {
        val bad = PalmCalibrator.fit(many(15f, 20f), many(90f, 100f), many(250f, 300f), many(85f, 95f))
        assertFalse(bad.wideReliable)
    }

    @Test fun wideTipWritesWithPriorityOverAPalm() {
        val f = PalmFilter(cfg, 160f)
        f.onDown(Contact(9, 300f, 300f, 0, ToolKind.FINGER, 300f))
        f.onDown(Contact(1, 0f, 0f, 20, ToolKind.FINGER, 50f))
        assertEquals(TouchClass.WIDE, f.classOf(1))
        assertEquals(GestureMode.Draw(1), f.mode)
    }
}
