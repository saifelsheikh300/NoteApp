package com.example.handnotes.data

import com.example.handnotes.engine.ImageObject
import com.example.handnotes.engine.InkStroke
import com.example.handnotes.engine.PageContent
import com.example.handnotes.engine.Pt
import com.example.handnotes.engine.ToolType
import java.io.File
import java.nio.file.Files
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DataLayerTest {
    private fun tmp(): File = Files.createTempDirectory("notes").toFile()
    private fun repo(dir: File) = LibraryRepository(dir, IoQueue(null))

    private fun stroke(n: Int = 5) = InkStroke(
        points = (0 until n).map { Pt(it * 1.5f, it * 2.25f, it * 10L, 1f) },
        color = 0xFF1565C0.toInt(), width = 4.5f, tool = ToolType.HIGHLIGHTER, opacity = 0.35f,
    )

    @Test fun pageFormatRoundTrip() {
        val s = stroke()
        val back = NoteFormat.pageFromJson(NoteFormat.pageToJson("p1", PageContent(listOf(s)))).strokes.single()
        assertEquals(s.id, back.id)
        assertEquals(s.color, back.color)
        assertEquals(ToolType.HIGHLIGHTER, back.tool)
        assertEquals(s.points.size, back.points.size)
        assertEquals(s.points[3].x, back.points[3].x, 0.01f)
        assertEquals(s.points[3].t, back.points[3].t)
    }

    @Test fun imagesSurviveSaveAndReload() {
        val dir = tmp()
        val r1 = repo(dir)
        val nb = r1.createNotebook(null, "Pics")
        val page = r1.loadMeta(nb.id).pages.first().id
        val img = ImageObject(file = "a.jpg", cx = 300f, cy = 400f, w = 200f, h = 100f, rotationDeg = 30f)
        r1.savePage(nb.id, page, PageContent(listOf(stroke()), listOf(img)))
        val back = repo(dir).loadPage(nb.id, page)
        assertEquals(1, back.images.size)
        assertEquals("a.jpg", back.images[0].file)
        assertEquals(30f, back.images[0].rotationDeg, 0.01f)
        assertEquals(img.id, back.images[0].id)
    }

    @Test fun safeFileSurvivesCorruptionOfMainFile() {
        val f = File(tmp(), "a.json")
        SafeFile.write(f, "one")
        SafeFile.write(f, "two")
        assertEquals("two", SafeFile.read(f))
        f.writeText("garbage")
        assertEquals("one", SafeFile.read(f)) // falls back to the backup copy
    }

    @Test fun safeFileIgnoresHalfWrittenTempFile() {
        val f = File(tmp(), "a.json")
        SafeFile.write(f, "good")
        File(f.path + ".tmp").writeText("0000 incomplete")
        assertEquals("good", SafeFile.read(f))
    }

    @Test fun safeFileReturnsNullWhenNothingValid() {
        assertNull(SafeFile.read(File(tmp(), "missing.json")))
    }

    @Test fun notebooksAndPagesSurviveRestart() {
        val dir = tmp()
        val r1 = repo(dir)
        val folder = r1.createFolder(null, "University")
        val nb = r1.createNotebook(folder.id, "Biology")
        val page = r1.loadMeta(nb.id).pages.first().id
        r1.savePage(nb.id, page, PageContent(listOf(stroke(8))))

        val r2 = repo(dir) // simulates restarting the app
        assertEquals("University / Biology", r2.pathName(nb.id))
        assertEquals(1, r2.loadPage(nb.id, page).strokes.size)
        assertEquals(8, r2.loadPage(nb.id, page).strokes.first().points.size)
    }

    @Test fun noArtificialLimits() {
        val r = repo(tmp())
        repeat(300) { r.createNotebook(null, "N$it") }
        assertEquals(300, r.children(null).size)
        val nb = r.createNotebook(null, "Big")
        var meta = r.loadMeta(nb.id)
        repeat(200) { meta = meta.copy(pages = meta.pages + PageInfo("p$it")) }
        r.saveMeta(meta)
        assertEquals(201, r.loadMeta(nb.id).pages.size)
    }

    @Test fun trashRestoreAndDeleteForever() {
        val dir = tmp()
        val r = repo(dir)
        val nb = r.createNotebook(null, "A")
        r.trash(nb.id)
        assertTrue(r.children(null).isEmpty())
        assertEquals(1, r.trashedRoots().size)
        r.restore(nb.id)
        assertEquals(1, r.children(null).size)
        r.trash(nb.id)
        r.emptyTrash()
        assertNull(r.get(nb.id))
        assertFalse(File(dir, "notebooks/${nb.id}").exists())
    }

    @Test fun cannotMoveFolderIntoItself() {
        val r = repo(tmp())
        val a = r.createFolder(null, "A")
        val b = r.createFolder(a.id, "B")
        assertFalse(r.move(a.id, b.id))
        assertFalse(r.move(a.id, a.id))
        assertTrue(r.move(b.id, null))
    }

    @Test fun duplicateCopiesPages() {
        val r = repo(tmp())
        val nb = r.createNotebook(null, "Orig")
        val page = r.loadMeta(nb.id).pages.first().id
        r.savePage(nb.id, page, PageContent(listOf(stroke())))
        val copy = r.duplicate(nb.id)
        assertNotNull(copy)
        assertEquals(1, r.loadPage(copy!!.id, r.loadMeta(copy.id).pages.first().id).strokes.size)
        assertEquals(2, r.children(null).size)
    }

    @Test fun indexSurvivesCorruption() {
        val dir = tmp()
        val r = repo(dir)
        r.createNotebook(null, "One")
        r.createNotebook(null, "Two")
        File(dir, "index.json").writeText("broken")
        assertEquals(1, repo(dir).children(null).size) // recovered the previous valid index
    }
}
