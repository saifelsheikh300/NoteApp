package com.example.handnotes.data

import java.nio.file.Files
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PdfMetaTest {
    @Test fun pdfPageInfoRoundTrips() {
        val meta = NotebookMeta(
            "nb",
            listOf(PageInfo("a", "", 0, 595f, 842f), PageInfo("b", "Notes"), PageInfo("c", "", 2, 612f, 792f)),
            PaperType.BLANK,
        )
        val back = LibraryFormat.metaFromJson(LibraryFormat.metaToJson(meta))
        assertEquals(3, back.pages.size)
        assertEquals(0, back.pages[0].pdfPage)
        assertEquals(842f, back.pages[0].pdfH, 0.01f)
        assertEquals(-1, back.pages[1].pdfPage)
        assertEquals("Notes", back.pages[1].title)
        assertEquals(2, back.pages[2].pdfPage)
    }

    @Test fun registerPdfNotebookKeepsPagesAndSource() {
        val dir = Files.createTempDirectory("pdfnotes").toFile()
        val repo = LibraryRepository(dir, IoQueue(null))
        val id = repo.newNotebookId()
        repo.pdfFile(id).apply { parentFile!!.mkdirs(); writeText("%PDF-1.4 fake") }
        val pages = (0 until 120).map { PageInfo("p$it", "", it, 595f, 842f) }
        val node = repo.registerPdfNotebook(id, null, "Lecture slides", pages)
        assertEquals("Lecture slides", repo.get(node.id)?.name)
        assertEquals(120, repo.loadMeta(id).pages.size)
        assertTrue(repo.pdfFile(id).exists())
        assertEquals("%PDF-1.4 fake", repo.pdfFile(id).readText()) // the source is stored untouched
    }
}

class PaperAndStyleTest {
    @Test fun blankHasNothingAndGridHasBothDirections() {
        val blank = PaperPattern.build(PaperType.BLANK, 1200f, 1700f)
        assertTrue(blank.segments.isEmpty() && blank.dots.isEmpty())
        val grid = PaperPattern.build(PaperType.GRID, 1200f, 1700f)
        assertTrue(grid.segments.any { it.x1 == it.x2 } && grid.segments.any { it.y1 == it.y2 })
    }

    @Test fun legalAndCornellHaveStrongLinesDottedHasDots() {
        assertTrue(PaperPattern.build(PaperType.LEGAL, 1200f, 1700f).segments.any { it.strong })
        assertTrue(PaperPattern.build(PaperType.CORNELL, 1200f, 1700f).segments.count { it.strong } == 3)
        assertTrue(PaperPattern.build(PaperType.DOTTED, 1200f, 1700f).dots.size > 500)
    }

    @Test fun narrowRulingHasMoreLinesThanWide() {
        val n = PaperPattern.build(PaperType.RULED_NARROW, 1200f, 1700f).segments.size
        val w = PaperPattern.build(PaperType.RULED, 1200f, 1700f).segments.size
        assertTrue(n > w)
    }

    @Test fun landscapeSwapsPageSides() {
        val (pw, ph) = PageSize.A4.dims(false)
        val (lw, lh) = PageSize.A4.dims(true)
        assertEquals(pw, lh, 0.01f)
        assertEquals(ph, lw, 0.01f)
    }

    @Test fun notebookStyleAndCoverRoundTrip() {
        val dir = Files.createTempDirectory("style").toFile()
        val repo = LibraryRepository(dir, IoQueue(null))
        val n = repo.createNotebook(null, "Bio", PaperType.CORNELL, "solid_blue", PaperColor.YELLOW, PageSize.LETTER, true)
        val again = LibraryRepository(dir, IoQueue(null))
        assertEquals("solid_blue", again.get(n.id)?.cover)
        val m = again.loadMeta(n.id)
        assertEquals(PaperType.CORNELL, m.paper)
        assertEquals(PaperColor.YELLOW, m.paperColor)
        assertEquals(PageSize.LETTER, m.size)
        assertTrue(m.landscape)
    }
}
