package com.example.handnotes.data

import java.nio.file.Files
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PdfMetaTest {
    @Test fun pdfPageInfoRoundTrips() {
        val meta = NotebookMeta(
            "nb",
            listOf(PageInfo("a", "", 0, 595f, 842f), PageInfo("b", "Notes"), PageInfo("c", "", 2, 612f, 792f)),
            PaperType.BLANK,
        )
        val back = LibraryFormat.metaFromJson(LibraryFormat.metaToJson(meta))
        assertEquals(3, back.pages.size)
        assertEquals(0, back.pages[0].pdfPage)
        assertEquals(842f, back.pages[0].pdfH, 0.01f)
        assertEquals(-1, back.pages[1].pdfPage)
        assertEquals("Notes", back.pages[1].title)
        assertEquals(2, back.pages[2].pdfPage)
    }

    @Test fun registerPdfNotebookKeepsPagesAndSource() {
        val dir = Files.createTempDirectory("pdfnotes").toFile()
        val repo = LibraryRepository(dir, IoQueue(null))
        val id = repo.newNotebookId()
        repo.pdfFile(id).apply { parentFile!!.mkdirs(); writeText("%PDF-1.4 fake") }
        val pages = (0 until 120).map { PageInfo("p$it", "", it, 595f, 842f) }
        val node = repo.registerPdfNotebook(id, null, "Lecture slides", pages)
        assertEquals("Lecture slides", repo.get(node.id)?.name)
        assertEquals(120, repo.loadMeta(id).pages.size)
        assertTrue(repo.pdfFile(id).exists())
        assertEquals("%PDF-1.4 fake", repo.pdfFile(id).readText()) // the source is stored untouched
    }
}
