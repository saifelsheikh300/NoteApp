# Feature-gap report (Phase 1 audit)

Audited from the repository itself: about 5,000 lines of app code (engine 1,000, data 870, UI 2,640, app 500), 80 unit-test functions, 0 TODO markers, 18 leftover strings from the old UI, 2 unused AppModel functions. A static check found no button without an action.

## Verification status (read this first)
- The first version (writing, erasing, scribble, undo, notebooks, PDF, images) was built on GitHub: **the APK compiled**. One unit-test step failed and the failing test was never identified.
- Everything added after that (Goodnotes-style UI, paper templates, palm rejection, calibration, covers, new library) has **never been compiled or run**. Nothing below is "tested" until a build passes.

Status key: 1 = implemented and tested, 2 = implemented but incomplete, 3 = in the UI but not functional, 4 = missing, 5 = blocked by Android/hardware.
"Implemented" below means code and unit tests exist, not that it was verified on a device.

| Area | Item | Status |
|---|---|---|
| A Library | folders (nested), notebooks, rename, duplicate, move, trash, restore, empty trash, favorites, covers, sort, search by name, unlimited count | 2 (not compiled) |
| A Library | grid only; list view, bulk select, tags, archive, filters, recents, custom cover image | 4 |
| B Pages | add, duplicate, delete, go to page, thumbnails panel, 7 paper types, 3 colours, 3 sizes, portrait/landscape, change template | 2 |
| B Pages | reorder/move pages, rename pages, bookmarks, index, page numbers, margins, continuous scroll, custom paper | 4 |
| C Ink | pen, highlighter, 2 erasers, colours, 3 widths, undo/redo, lasso (free/rect) with move/resize/rotate/copy/cut/paste/duplicate, scribble-to-erase, stabilization slider, lossless stroke storage, uses every batched touch sample | 2 |
| C Ink | pencil, pen presets, opacity, ink-latency measurement, handwriting calibration profiles | 4 |
| D Touch | palm rejection (size, tool type, timing), writing lock, temporary touch navigation, calibration with live test | 2 |
| D Touch | mode selector (stylus-only / finger nav / normal), two- and three-finger tap gestures, gesture practice area, keyboard shortcuts | 4 |
| D Touch | pressure, tilt, hover, stylus button on a generic capacitive stylus | 5 |
| E Editing | images (gallery, camera, move, scale, rotate), draw-and-hold shapes | 2 |
| E Editing | text boxes, shape tool, arrows, layers, grouping, alignment, z-order controls, stickers | 4 |
| F PDF | import (original untouched), annotate, flattened export (page or all), lazy page rendering | 2 |
| F PDF | PDF page in thumbnails, bookmarks, text annotations, text search, selected-range export | 4 |
| F PDF | extracting PDF text needs a PDF library (not available offline in the current build) | 5 |
| G Study | flashcards, tests, planner, tasks, audio, links, backlinks | 4 |
| H Search | notebook/folder names only | 2 |
| H Search | typed text search, OCR / handwriting recognition (offline Arabic needs a model download) | 4/5 |
| I Workflow | Quick note (creates a notebook) | 2 |
| I Workflow | zoom window, replay, reference panel, focus mode, tool palette, layers, comparison, version history, shortcut profiles, open export format | 4 |
| J Reliability | debounced autosave, atomic write with checksum and backup copy, recovery from a damaged file, save on leaving the app | 2 |
| J Reliability | backup/restore screen, version restore, integrity checker, storage-full handling, save-status indicator, migrations (format is versioned, no migration yet) | 4 |
| K Design | Goodnotes-style library, new-notebook dialog and editor, original icons/covers drawn in code | 2 |
| K Design | light theme (dark only), compact/phone layout (fixed 280 dp sidebar), customizable toolbar, content descriptions on icons, tested right-to-left layout | 4 |

## Plan
1. **Gate: make the build green.** Build, fix compile errors, find and fix the failing test(s). No new features until this passes.
2. Cleanup: remove the 18 unused strings and 2 unused functions; add content descriptions to icons.
3. Core: page reorder/rename, bookmarks, list view, PDF thumbnails, save-status indicator.
4. Handwriting: pencil, pen presets, opacity, ink-latency test on the device.
5. Text box, shapes, layers.
6. Search and study: typed-text search, flashcards, planner, audio.
7. Backup, version history, integrity checker, open export format.
8. Advanced: zoom window, replay, reference panel, focus mode, shortcuts.
